from __future__ import annotations

from pathlib import Path
import re
import time
from typing import Any, Mapping

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, HTMLResponse
from ottomate_core.auth import dev_mode_enabled, firebase_config, google_client_id
from ottomate_core.models import ConfigResponse

CORE_STATIC_DIR = (Path(__file__).resolve().parent.parent / "static").resolve()
_MAINTENANCE_CACHE_TTL_SECONDS = 60.0
_maintenance_cache: dict[str, tuple[float, dict[str, Any] | None]] = {}


def clear_maintenance_cache() -> None:
    """Clears the in-process `/api/config` maintenance status TTL cache."""
    _maintenance_cache.clear()


def _get_maintenance_info(service_id: str) -> dict[str, Any] | None:
    if service_id == "hub":
        return None
    from ottomate_core import db as db_module

    # Bypass cache when a test double provider is registered so tests see immediate writes
    use_cache = (
        db_module._users_database_provider is None
        and db_module._database_provider is None
    )
    now_mono = time.monotonic()
    if use_cache:
        cached = _maintenance_cache.get(service_id)
        if cached and (now_mono - cached[0]) < _MAINTENANCE_CACHE_TTL_SECONDS:
            return cached[1]

    info: dict[str, Any] | None = None
    try:
        db = db_module.users_database()
        snap = db.collection("services").document(service_id).get()
        if snap.exists:
            sd = snap.to_dict() or {}
            if sd.get("is_denylisted"):
                info = {
                    "active": True,
                    "admin_note": sd.get("admin_note") or "Service is undergoing scheduled maintenance.",
                }
        if use_cache:
            _maintenance_cache[service_id] = (now_mono, info)
    except Exception:
        pass
    return info


def create_system_router(service_version: str = "0.1.0", service_name: str = "ottomate-service") -> APIRouter:
    router = APIRouter(tags=["System"])

    @router.get("/health", include_in_schema=False)
    @router.get("/healthz", include_in_schema=False)
    @router.get("/api/healthz", include_in_schema=False)
    def healthz():
        import ottomate_core

        return {
            "status": "ok",
            "service": service_name,
            "version": service_version,
            "core_version": ottomate_core.__version__,
        }

    @router.get("/api/config", response_model=ConfigResponse)
    def get_config():
        import ottomate_core
        from ottomate_core.config import get_service_metadata

        s_id = service_name.removeprefix("ottomate-")
        maintenance_info = _get_maintenance_info(s_id)

        from ottomate_core.cron import get_cron_config

        cron_cfg = get_cron_config()
        fb_cfg = firebase_config()
        return ConfigResponse(
            google_client_id=google_client_id(),
            dev_mode=dev_mode_enabled(),
            version=service_version,
            core_version=ottomate_core.__version__,
            service_metadata=get_service_metadata(),
            maintenance=maintenance_info,
            cron=cron_cfg.to_dict() if cron_cfg else None,
            firebase=fb_cfg,
            firebase_config=fb_cfg,
        )

    @router.get("/api/service-card", include_in_schema=False)
    def get_service_card():
        from ottomate_core.config import get_service_metadata

        metadata = get_service_metadata()
        if not metadata:
            raise HTTPException(status_code=404, detail="Service metadata not registered.")
        return metadata

    @router.get("/core-static/{asset_path:path}", include_in_schema=False)
    def get_core_static(asset_path: str):
        candidate = (CORE_STATIC_DIR / asset_path).resolve()
        if not candidate.is_relative_to(CORE_STATIC_DIR) or not candidate.is_file():
            raise HTTPException(status_code=404, detail="Static asset not found.")
        return FileResponse(candidate)

    return router


def render_index_html(
    index_file_path: Path | str,
    version: str,
    extra_replacements: Mapping[str, str] | None = None,
) -> HTMLResponse:
    """Reads index.html, performs dynamic cache-busting regex replacements, and returns HTMLResponse with security & no-cache headers."""
    path = Path(index_file_path)
    if not path.exists():
        return HTMLResponse("<h1>Ottomate Application</h1><p>Starting up...</p>", status_code=200)

    html_content = path.read_text(encoding="utf-8")
    # Dynamically ensure all /static/ and /core-static/ asset links have current VERSION query string
    html_content = re.sub(
        r'((?:/static/|/core-static/)[^"\']+\?v=)[a-zA-Z0-9\.\-]+',
        rf"\g<1>{version}",
        html_content,
    )
    # Ensure app-version text reflects current VERSION
    html_content = re.sub(
        r'<span id="app-version" class="version-tag">.*?</span>',
        f'<span id="app-version" class="version-tag">v{version}</span>',
        html_content,
    )
    if extra_replacements:
        for k, v in extra_replacements.items():
            html_content = html_content.replace(k, v)

    return HTMLResponse(
        content=html_content,
        headers={
            "Cache-Control": "no-cache, no-store, must-revalidate",
            "Pragma": "no-cache",
            "Expires": "0",
            "Cross-Origin-Opener-Policy": "same-origin-allow-popups",
        },
    )
