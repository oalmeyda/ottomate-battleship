/**
 * Ottomate Platform Web Audio API Synthesizer (Zero External Assets)
 * Provides arcade and card game synthetic audio using native browser AudioContext.
 */
(function (root) {
  root.Ottomate = root.Ottomate || {};

  let audioCtx = null;
  let masterGain = null;
  const STORAGE_KEY_ENABLED = "ottomate_audio_enabled";
  const STORAGE_KEY_VOLUME = "ottomate_audio_volume";

  function getAudioContext() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    if (audioCtx && audioCtx.state === "suspended") {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function isEnabled() {
    try {
      if (typeof localStorage !== "undefined") {
        const val = localStorage.getItem(STORAGE_KEY_ENABLED);
        if (val === "0" || val === "false") return false;
      }
    } catch (e) {}
    return true;
  }

  function setEnabled(enabled) {
    const val = !!enabled;
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem(STORAGE_KEY_ENABLED, val ? "true" : "false");
      }
    } catch (e) {}
    if (typeof window !== "undefined" && typeof window.dispatchEvent === "function") {
      window.dispatchEvent(new CustomEvent("ottomate:audio-toggle", { detail: { enabled: val } }));
    }
    return val;
  }

  function toggle() {
    return setEnabled(!isEnabled());
  }

  function getVolume() {
    try {
      if (typeof localStorage !== "undefined") {
        const val = localStorage.getItem(STORAGE_KEY_VOLUME);
        if (val !== null) {
          const num = parseFloat(val);
          if (!isNaN(num) && num >= 0 && num <= 1) return num;
        }
      }
    } catch (e) {}
    return 1.0;
  }

  function setVolume(volume) {
    const vol = Math.max(0, Math.min(1, Number(volume) || 0));
    try {
      if (typeof localStorage !== "undefined") {
        localStorage.setItem(STORAGE_KEY_VOLUME, String(vol));
      }
    } catch (e) {}
    if (masterGain && audioCtx) {
      masterGain.gain.setValueAtTime(vol, audioCtx.currentTime);
    }
    return vol;
  }

  function getMasterGain(ctx) {
    if (!masterGain || masterGain.context !== ctx) {
      masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(getVolume(), ctx.currentTime);
      masterGain.connect(ctx.destination);
    }
    return masterGain;
  }

  function playClick() {
    if (!isEnabled()) return;
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(440, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.05);
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
    osc.connect(gain);
    gain.connect(getMasterGain(ctx));
    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  }

  function playFlag() {
    if (!isEnabled()) return;
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(600, ctx.currentTime);
    osc.frequency.setValueAtTime(800, ctx.currentTime + 0.04);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(getMasterGain(ctx));
    osc.start();
    osc.stop(ctx.currentTime + 0.08);
  }

  function playExplosion() {
    if (!isEnabled()) return;
    const ctx = getAudioContext();
    if (!ctx) return;
    const bufferSize = ctx.sampleRate * 0.5;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.setValueAtTime(800, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.45);
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.4, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.45);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(getMasterGain(ctx));
    noise.start();
    noise.stop(ctx.currentTime + 0.5);
  }

  function playCardDeal() {
    if (!isEnabled()) return;
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(300, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.06);
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.005, ctx.currentTime + 0.06);
    osc.connect(gain);
    gain.connect(getMasterGain(ctx));
    osc.start();
    osc.stop(ctx.currentTime + 0.06);
  }

  function playChipClick() {
    if (!isEnabled()) return;
    const ctx = getAudioContext();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(1200, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(600, ctx.currentTime + 0.04);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.04);
    osc.connect(gain);
    gain.connect(getMasterGain(ctx));
    osc.start();
    osc.stop(ctx.currentTime + 0.04);
  }

  function playWinFanfare() {
    if (!isEnabled()) return;
    const ctx = getAudioContext();
    if (!ctx) return;
    const notes = [261.63, 329.63, 392.0, 523.25]; // C4, E4, G4, C5
    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "square";
      osc.frequency.value = freq;
      const startTime = ctx.currentTime + idx * 0.1;
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(0.18, startTime + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.25);
      osc.connect(gain);
      gain.connect(getMasterGain(ctx));
      osc.start(startTime);
      osc.stop(startTime + 0.25);
    });
  }

  root.Ottomate.audio = {
    getContext: getAudioContext,
    isEnabled,
    setEnabled,
    toggle,
    getVolume,
    setVolume,
    playClick,
    playFlag,
    playExplosion,
    playCardDeal,
    playChipClick,
    playWinFanfare,
  };
})(typeof window !== "undefined" ? window : globalThis);
