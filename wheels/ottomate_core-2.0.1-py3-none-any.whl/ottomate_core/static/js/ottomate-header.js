/**
 * Ottomate Core Header & Auth Controller (UMD / Dual-Mode)
 * Standardizes the top bar header, version sync, profile pill, and auth state across all Ottomate applications.
 */

(function (root, factory) {
  if (typeof define === "function" && define.amd) {
    define([], factory);
  } else if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.Ottomate = root.Ottomate || {};
    Object.assign(root.Ottomate, factory());
  }
})(typeof self !== "undefined" ? self : this, function () {
  const state = {
    idToken: "",
    currentUser: null,
    config: null,
  };

  function formatErrorDetail(detail, fallback = "Request failed") {
    if (!detail) return fallback;
    if (typeof detail === "string") return detail;
    if (Array.isArray(detail)) {
      return detail
        .map((item) => (typeof item === "string" ? item : item?.msg || JSON.stringify(item)))
        .join("; ");
    }
    if (typeof detail === "object") {
      return detail.message || detail.msg || JSON.stringify(detail);
    }
    return String(detail);
  }

  async function api(path, options = {}) {
    const token = state.idToken || localStorage.getItem("ottomate_auth_token") || localStorage.getItem("auth_token") || "";
    const isPlainBody =
      options.body !== undefined &&
      options.body !== null &&
      typeof options.body !== "string" &&
      !(typeof FormData !== "undefined" && options.body instanceof FormData) &&
      !(typeof URLSearchParams !== "undefined" && options.body instanceof URLSearchParams) &&
      !(typeof Blob !== "undefined" && options.body instanceof Blob);
    const body = isPlainBody ? JSON.stringify(options.body) : options.body;
    const headers = {
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    };
    const response = await fetch(path, { ...options, body, headers });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      const detail = formatErrorDetail(err.detail, response.statusText || `HTTP ${response.status}`);
      if (response.status === 401 && typeof window.ottomateSignOut === "function") {
        window.ottomateSignOut();
      }
      const error = new Error(detail);
      error.status = response.status;
      error.detail = err.detail;
      throw error;
    }
    return response.status === 204 ? null : response.json();
  }

  function getInitials(name) {
    if (!name) return "??";
    const clean = String(name).trim();
    if (!clean) return "??";
    const digitMatch = clean.match(/^(\d{1,2})/);
    if (digitMatch && digitMatch[1].length === 2) {
      return digitMatch[1];
    }
    const words = clean.split(/\s+/).filter(Boolean);
    if (words.length >= 2) {
      const first = words[0].charAt(0).toUpperCase();
      const second = words[words.length - 1].charAt(0).toUpperCase();
      return `${first}${second}`;
    }
    const caps = clean.match(/[A-Z]/g);
    if (caps && caps.length >= 2) {
      return `${caps[0]}${caps[1]}`;
    }
    return clean.substring(0, 2).toUpperCase();
  }

  function updateProfilePill(user, prefix = "profile") {
    if (!user) {
      state.currentUser = null;
      toggleAuthButtons(false);
      return;
    }
    state.currentUser = user;
    const rawName = user.nickname || user.display_name || user.email || "Profile";
    const shortName = rawName.includes("@") ? rawName.split("@")[0] : rawName;
    const initials = getInitials(shortName);

    // Name label elements
    const label = document.getElementById(`${prefix}-name`) || document.getElementById(`${prefix}-btn-label`);
    if (label) label.textContent = shortName;

    // Avatar elements
    const avatar = document.getElementById(`${prefix}-avatar`);
    if (avatar) avatar.textContent = initials;

    // Profile pill container (button or div)
    const pill = document.getElementById(`${prefix}-pill`) || document.getElementById(`${prefix}-btn`);
    if (pill) {
      if (pill.classList.contains("hidden")) pill.classList.remove("hidden");
      if (pill.style.display !== "inline-flex") pill.style.display = "inline-flex";
    }

    // Automatically remove/hide any other auth methods (Google, Email link, Dev) and show Sign Out
    toggleAuthButtons(true);
  }

  function toggleAuthButtons(isSignedIn) {
    // 1. Logout button(s)
    document.querySelectorAll("#btn-logout, #signout, #btn-signout").forEach((el) => {
      if (isSignedIn) {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-flex") el.style.display = "inline-flex";
      } else {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      }
    });

    // 2. Directory button(s)
    document.querySelectorAll("#btn-directory, #admin-settings-btn").forEach((el) => {
      if (isSignedIn) {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-flex") el.style.display = "inline-flex";
      } else {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      }
    });

    // 3. Google Sign-In elements (roots, buttons, wrappers, iframes)
    document.querySelectorAll("#g-signin-root, #google-button, .g-signin-root, .g_id_signin").forEach((el) => {
      if (isSignedIn) {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      } else {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-flex") el.style.display = "inline-flex";
      }
    });

    // 4. Email Sign-In elements (roots, buttons, wrappers)
    document.querySelectorAll(
      "#otto-email-signin-root, #email-signin-root, .otto-email-signin-wrap, #btn-email-signin, .otto-email-signin-btn"
    ).forEach((el) => {
      if (isSignedIn) {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      } else {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-flex") el.style.display = "inline-flex";
      }
    });

    // 4b. Auth group container (keeps Google & Email sign-in buttons unified on one row)
    document.querySelectorAll("#otto-auth-group, .otto-auth-group").forEach((el) => {
      if (isSignedIn) {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      } else {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-flex") el.style.display = "inline-flex";
      }
    });

    // 5. Dev Sign-In elements
    document.querySelectorAll("#dev-signin-root, #dev-signin-btn, #btn-dev-login").forEach((el) => {
      if (!isSignedIn && state.config?.dev_mode) {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-block") el.style.display = "inline-block";
      } else {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      }
    });

    // 6. Profile pill container (button or div)
    if (!isSignedIn) {
      document.querySelectorAll("#profile-pill, #profile-btn").forEach((el) => {
        if (!el.classList.contains("hidden")) el.classList.add("hidden");
        if (el.style.display !== "none") el.style.display = "none";
      });
    } else if (state.currentUser) {
      document.querySelectorAll("#profile-pill, #profile-btn").forEach((el) => {
        if (el.classList.contains("hidden")) el.classList.remove("hidden");
        if (el.style.display !== "inline-flex") el.style.display = "inline-flex";
      });
    }
  }

  const AUTH_TOKEN_KEYS = ["ottomate_auth_token", "auth_token", "yuquer_auth_token", "poker_auth_token"];
  let firebaseRefreshTimer = null;
  let firebaseTokenUnsubscribe = null;

  function storeAuthToken(token, provider = null) {
    AUTH_TOKEN_KEYS.forEach((k) => localStorage.setItem(k, token));
    if (provider) {
      localStorage.setItem("ottomate_auth_provider", provider);
    }
    state.idToken = token;
    if (token) {
      toggleAuthButtons(true);
    }
  }

  function clearAuthToken() {
    AUTH_TOKEN_KEYS.forEach((k) => localStorage.removeItem(k));
    localStorage.removeItem("ottomate_auth_provider");
    state.idToken = "";
    state.currentUser = null;
    toggleAuthButtons(false);
    if (firebaseRefreshTimer) {
      clearInterval(firebaseRefreshTimer);
      firebaseRefreshTimer = null;
    }
    if (typeof firebaseTokenUnsubscribe === "function") {
      try { firebaseTokenUnsubscribe(); } catch (_) {}
      firebaseTokenUnsubscribe = null;
    }
    try {
      if (typeof window !== "undefined") {
        if (window.firebase && typeof window.firebase.auth === "function" && window.firebase.apps?.length) {
          window.firebase.auth().signOut().catch(() => {});
        }
        if (window.google?.accounts?.id) {
          window.google.accounts.id.disableAutoSelect();
        }
      }
    } catch (_) {}
  }

  function getStoredAuthToken() {
    return state.idToken || AUTH_TOKEN_KEYS.map((k) => localStorage.getItem(k)).find(Boolean) || "";
  }

  /**
   * Robustly loads the Google Sign-In SDK and renders the button into `rootId`.
   * Handles an already-loaded SDK, a pre-existing <script> tag, late SDK load (polling),
   * unregistered-origin and blocked-SDK diagnostics.
   */
  function renderGoogleSignIn({ clientId, rootId = "g-signin-root", onCredential, width, size = "medium" }) {
    const gRoot = document.getElementById(rootId) || document.getElementById("google-button");
    if (!gRoot || !clientId) return;

    const isCurrentlySignedIn = Boolean(
      state.currentUser ||
      getStoredAuthToken() ||
      (document.getElementById("profile-pill") &&
       document.getElementById("profile-pill").style.display !== "none" &&
       !document.getElementById("profile-pill").classList.contains("hidden"))
    );
    if (isCurrentlySignedIn) {
      gRoot.classList.add("hidden");
      gRoot.style.display = "none";
    }

    function renderGsi() {
      if (!window.google || !window.google.accounts || !window.google.accounts.id) return false;
      try {
        window.google.accounts.id.initialize({
          client_id: clientId,
          callback: async (response) => {
            if (response && response.credential) {
              storeAuthToken(response.credential, "google");
              if (onCredential) await onCredential(response.credential);
            }
          },
        });
        gRoot.innerHTML = "";
        const buttonOpts = { theme: "outline", size, shape: "pill" };
        if (width) buttonOpts.width = width;
        window.google.accounts.id.renderButton(gRoot, buttonOpts);
        setTimeout(() => {
          if (!gRoot.querySelector("iframe") && (!gRoot.hasChildNodes() || gRoot.innerHTML.trim() === "")) {
            gRoot.innerHTML = `
              <div style="max-width: 440px; margin: 0 auto; padding: 0.85rem 1rem; background: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; border-radius: 10px; color: #fecaca; font-size: 0.85rem; line-height: 1.45; text-align: left;">
                <strong>\u26A0\uFE0F Google Sign-In Origin Registration Required</strong><br>
                Origin <code>${escapeHtml(window.location.origin)}</code> is not yet registered under <strong>Authorized JavaScript origins</strong> for this app's Google OAuth Client ID.<br>
                Ask an administrator to register it in the Google Cloud Console (APIs &amp; Services &rarr; Credentials).
              </div>`;
          }
        }, 1500);
        return true;
      } catch (err) {
        console.error("Failed to render Google Sign-In button:", err);
        return false;
      }
    }

    if (renderGsi()) return;

    if (!gRoot.hasChildNodes() || gRoot.textContent.trim() === "") {
      gRoot.innerHTML = '<div style="color: #94a3b8; font-size: 0.88rem; padding: 0.5rem 0;">\u23F3 Loading Google Sign-In...</div>';
    }

    const existingScript = document.querySelector('script[src*="accounts.google.com/gsi/client"]');
    if (existingScript) {
      existingScript.addEventListener("load", () => renderGsi());
    } else {
      const script = document.createElement("script");
      script.src = "https://accounts.google.com/gsi/client";
      script.async = true;
      script.defer = true;
      script.onload = () => renderGsi();
      document.head.appendChild(script);
    }

    let attempts = 0;
    const pollTimer = setInterval(() => {
      attempts++;
      if (renderGsi() || attempts >= 80) {
        clearInterval(pollTimer);
        if (attempts >= 80 && (!window.google || !window.google.accounts)) {
          gRoot.innerHTML =
            '<div style="color: #f87171; font-size: 0.85rem; text-align: center;">Unable to load Google Sign-In SDK.<br><small style="color: #94a3b8;">Please check your connection or disable ad-blockers, then refresh.</small></div>';
        }
      }
    }, 60);
  }

  let firebaseSdkLoadingPromise = null;

  function loadFirebaseSdk() {
    if (window.firebase && window.firebase.auth) {
      return Promise.resolve(window.firebase);
    }
    if (firebaseSdkLoadingPromise) return firebaseSdkLoadingPromise;

    firebaseSdkLoadingPromise = new Promise((resolve, reject) => {
      function loadScript(src) {
        return new Promise((res, rej) => {
          const existing = document.querySelector(`script[src="${src}"]`);
          if (existing) {
            if (window.firebase && (src.includes("firebase-app") || window.firebase.auth)) return res();
            existing.addEventListener("load", () => res());
            existing.addEventListener("error", () => rej(new Error(`Failed to load ${src}`)));
            return;
          }
          const s = document.createElement("script");
          s.src = src;
          s.async = true;
          s.onload = () => res();
          s.onerror = (e) => rej(new Error(`Failed to load ${src}`));
          document.head.appendChild(s);
        });
      }

      loadScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js")
        .then(() => loadScript("https://www.gstatic.com/firebasejs/10.8.0/firebase-auth-compat.js"))
        .then(() => resolve(window.firebase))
        .catch((err) => {
          firebaseSdkLoadingPromise = null;
          reject(err);
        });
    });

    return firebaseSdkLoadingPromise;
  }

  function isEmailSignInUrl() {
    if (typeof window === "undefined" || !window.location) return false;
    const url = window.location.href;
    return url.includes("apiKey=") && (url.includes("mode=signIn") || url.includes("oobCode="));
  }

  let emailModalBuilt = false;

  function ensureEmailSignInModal(firebaseConfig, onToken) {
    if (emailModalBuilt) return;
    emailModalBuilt = true;

    const modalId = "otto-email-signin-modal";
    if (document.getElementById(modalId)) return;

    const wrap = document.createElement("div");
    wrap.innerHTML = `
      <div id="${modalId}" class="otto-modal-overlay otto-hidden" role="dialog" aria-modal="true" aria-labelledby="${modalId}-title" style="position: fixed; inset: 0; z-index: 10000; display: none; align-items: center; justify-content: center; padding: 0.75rem; box-sizing: border-box; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(2px);">
        <div class="otto-modal-card" style="width: 100%; max-width: min(380px, calc(100vw - 1.5rem)); margin: auto; padding: 1.15rem 1.25rem; border-radius: 14px; background: #ffffff; color: #0f172a; border: 1px solid #cbd5e1; box-shadow: 0 20px 40px rgba(0, 0, 0, 0.35); box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.4rem; border-bottom: 1px solid #e2e8f0; padding-bottom: 0.45rem;">
            <h3 id="${modalId}-title" style="margin: 0; font-size: 1.05rem; font-weight: 700; color: #0f172a;">✉️ Sign in with Email Link</h3>
            <button type="button" class="otto-modal-close" data-otto-close aria-label="Close" style="background: transparent; border: none; font-size: 1.4rem; line-height: 1; cursor: pointer; color: #64748b; padding: 0.2rem 0.4rem; border-radius: 6px;">&times;</button>
          </div>
          <p style="margin: 0 0 0.85rem; font-size: 0.82rem; line-height: 1.4; color: #475569;">
            Enter your email address. We'll send you a passwordless magic sign-in link.
          </p>
          <form id="${modalId}-form" style="display: flex; flex-direction: column; gap: 0.75rem; margin: 0;">
            <input
              type="email"
              id="${modalId}-email-input"
              class="otto-input"
              placeholder="you@example.com"
              required
              autocomplete="email"
              inputmode="email"
              style="width: 100%; box-sizing: border-box; padding: 0.6rem 0.75rem; border-radius: 8px; border: 1px solid #cbd5e1; font-size: 16px; background: #f8fafc; color: #0f172a;"
            />
            <div id="${modalId}-feedback" class="otto-feedback" style="font-size: 0.82rem; line-height: 1.4;"></div>
            <div style="display: flex; justify-content: flex-end; gap: 0.5rem; margin-top: 0.2rem;">
              <button type="button" class="otto-btn" data-otto-close style="padding: 0.4rem 0.85rem; border-radius: 8px; border: 1px solid #cbd5e1; background: #f1f5f9; color: #334155; font-size: 0.82rem; font-weight: 500; cursor: pointer;">Cancel</button>
              <button type="submit" id="${modalId}-submit-btn" class="otto-btn otto-btn-primary" style="padding: 0.4rem 0.95rem; border-radius: 8px; border: none; background: #2563eb; color: #ffffff; font-size: 0.82rem; font-weight: 600; cursor: pointer;">Send Magic Link</button>
            </div>
          </form>
        </div>
      </div>
    `;
    while (wrap.firstChild) document.body.appendChild(wrap.firstChild);

    const modal = document.getElementById(modalId);
    modal.addEventListener("click", (e) => {
      if (e.target === modal || e.target.closest("[data-otto-close]")) {
        modal.classList.add("otto-hidden");
        modal.style.display = "none";
      }
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && modal && !modal.classList.contains("otto-hidden")) {
        modal.classList.add("otto-hidden");
        modal.style.display = "none";
      }
    });

    const form = document.getElementById(`${modalId}-form`);
    const emailInput = document.getElementById(`${modalId}-email-input`);
    const feedback = document.getElementById(`${modalId}-feedback`);
    const submitBtn = document.getElementById(`${modalId}-submit-btn`);

    emailInput.addEventListener("input", () => {
      if (submitBtn.disabled && submitBtn.textContent === "Link Sent!") {
        submitBtn.disabled = false;
        submitBtn.textContent = "Send Magic Link";
      }
    });

    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = (emailInput.value || "").trim().toLowerCase();
      if (!email) return;

      submitBtn.disabled = true;
      submitBtn.textContent = "Sending link...";
      feedback.className = "otto-feedback";
      feedback.textContent = "";

      try {
        // Verify pre-approval before dispatching Firebase email link (prevents quota exhaustion)
        const preRes = await fetch("/api/auth/check-email", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email }),
        });
        if (!preRes.ok) {
          const preErr = await preRes.json().catch(() => ({}));
          throw new Error(formatErrorDetail(preErr.detail, "Registration is restricted."));
        }

        await loadFirebaseSdk();
        if (!window.firebase.apps.length) {
          window.firebase.initializeApp(firebaseConfig);
        }
        const auth = window.firebase.auth();
        const cleanContinueUrl = `${window.location.origin}${window.location.pathname}${window.location.hash || ""}`;
        const actionCodeSettings = {
          url: cleanContinueUrl,
          handleCodeInApp: true,
        };
        await auth.sendSignInLinkToEmail(email, actionCodeSettings);
        window.localStorage.setItem("emailForSignIn", email);
        feedback.className = "otto-feedback otto-feedback-ok";
        feedback.innerHTML = `✅ Magic link sent to <strong>${escapeHtml(email)}</strong>!<br>Check your inbox and click the link to sign in.`;
        submitBtn.textContent = "Link Sent!";
      } catch (err) {
        feedback.className = "otto-feedback otto-feedback-err";
        feedback.textContent = err.message || "Failed to send sign-in link.";
        submitBtn.disabled = false;
        submitBtn.textContent = "Send Magic Link";
      }
    });
  }

  function stripFirebaseAuthQueryParams() {
    if (typeof window === "undefined" || !window.location || !window.history?.replaceState) return;
    try {
      const urlObj = new URL(window.location.href);
      ["apiKey", "oobCode", "mode", "lang", "continueUrl"].forEach((p) => urlObj.searchParams.delete(p));
      const nextUrl = `${urlObj.pathname}${urlObj.search}${urlObj.hash}`;
      window.history.replaceState({}, document.title, nextUrl);
    } catch (_) {
      window.history.replaceState({}, document.title, `${window.location.pathname}${window.location.hash || ""}`);
    }
  }

  async function startFirebaseTokenAutoRefresh(firebaseConfig) {
    if (!firebaseConfig || !firebaseConfig.apiKey || firebaseTokenUnsubscribe) return;
    try {
      await loadFirebaseSdk();
      if (!window.firebase.apps.length) {
        window.firebase.initializeApp(firebaseConfig);
      }
      const auth = window.firebase.auth();
      firebaseTokenUnsubscribe = auth.onIdTokenChanged(async (fbUser) => {
        if (fbUser && localStorage.getItem("ottomate_auth_provider") === "firebase") {
          try {
            const freshToken = await fbUser.getIdToken();
            if (freshToken) storeAuthToken(freshToken, "firebase");
          } catch (_) {}
        }
      });
      if (!firebaseRefreshTimer) {
        firebaseRefreshTimer = setInterval(async () => {
          if (localStorage.getItem("ottomate_auth_provider") !== "firebase") return;
          const fbUser = auth.currentUser;
          if (fbUser) {
            try {
              const refreshed = await fbUser.getIdToken(true);
              if (refreshed) storeAuthToken(refreshed, "firebase");
            } catch (_) {}
          }
        }, 45 * 60 * 1000);
      }
    } catch (_) {}
  }

  let emailLinkHandlingPromise = null;

  async function handleEmailSignInLink(firebaseConfig, onToken) {
    if (!isEmailSignInUrl() || !firebaseConfig || !firebaseConfig.apiKey) return false;
    if (emailLinkHandlingPromise) return emailLinkHandlingPromise;

    emailLinkHandlingPromise = (async () => {
      try {
        await loadFirebaseSdk();
        if (!window.firebase.apps.length) {
          window.firebase.initializeApp(firebaseConfig);
        }
        const auth = window.firebase.auth();
        const incomingUrl = window.location.href;
        if (auth.isSignInWithEmailLink(incomingUrl)) {
          let email = window.localStorage.getItem("emailForSignIn");
          if (!email) {
            email = window.prompt("Please confirm your email address to complete sign in:");
          }
          if (!email) {
            stripFirebaseAuthQueryParams();
            return false;
          }

          const result = await auth.signInWithEmailLink(email.trim().toLowerCase(), incomingUrl);
          window.localStorage.removeItem("emailForSignIn");
          stripFirebaseAuthQueryParams();

          const idToken = await result.user.getIdToken();
          storeAuthToken(idToken, "firebase");
          await startFirebaseTokenAutoRefresh(firebaseConfig);
          if (onToken) await onToken(idToken);
          return true;
        }
      } catch (err) {
        console.error("Failed to complete email link sign-in:", err);
        stripFirebaseAuthQueryParams();
        const errEl = document.getElementById("auth-error-message") || document.getElementById("status");
        const msg = "Sign-in link expired or already used. Please request a fresh magic link.";
        if (errEl) {
          errEl.textContent = msg;
          errEl.style.display = "block";
        } else if (typeof window !== "undefined" && typeof window.alert === "function") {
          window.alert(msg);
        }
      } finally {
        emailLinkHandlingPromise = null;
      }
      return false;
    })();

    return emailLinkHandlingPromise;
  }

  function setupEmailSignIn(firebaseConfig, onToken) {
    if (!firebaseConfig || !firebaseConfig.apiKey) return;

    // Check if this page load is completing an incoming email link
    handleEmailSignInLink(firebaseConfig, onToken);

    // Keep Firebase ID tokens silently refreshed past 60 minutes for active Email Link sessions
    if (localStorage.getItem("ottomate_auth_provider") === "firebase" && getStoredAuthToken()) {
      startFirebaseTokenAutoRefresh(firebaseConfig);
    }

    // Build the modal lazily
    ensureEmailSignInModal(firebaseConfig, onToken);

    // Render button into custom container or wrap together with Google Sign-In in an auth group
    let container = document.getElementById("otto-email-signin-root") || document.getElementById("email-signin-root");
    if (!container) {
      const gRoot = document.getElementById("g-signin-root") || document.getElementById("google-button");
      if (gRoot && gRoot.parentNode) {
        let authGroup = document.getElementById("otto-auth-group");
        if (!authGroup) {
          authGroup = document.createElement("div");
          authGroup.id = "otto-auth-group";
          authGroup.className = "otto-auth-group";
          gRoot.parentNode.insertBefore(authGroup, gRoot);
          authGroup.appendChild(gRoot);
        }
        container = document.createElement("div");
        container.id = "otto-email-signin-root";
        container.className = "otto-email-signin-wrap";
        authGroup.appendChild(container);
      }
    }

    const isCurrentlySignedIn = Boolean(
      state.currentUser ||
      getStoredAuthToken() ||
      (document.getElementById("profile-pill") &&
       document.getElementById("profile-pill").style.display !== "none" &&
       !document.getElementById("profile-pill").classList.contains("hidden"))
    );

    if (container) {
      if (isCurrentlySignedIn) {
        container.classList.add("hidden");
        container.style.display = "none";
      } else {
        container.classList.remove("hidden");
        container.style.display = "inline-flex";
      }
    }

    if (container && !container.dataset.ottoEmailBound) {
      container.dataset.ottoEmailBound = "1";
      container.innerHTML = `
        <button type="button" id="btn-email-signin" class="otto-email-signin-btn" title="Sign in via passwordless email magic link">
          <span style="font-size: 0.88rem; line-height: 1;">✉️</span>
          <span class="otto-email-label-long">Sign in with Email</span>
          <span class="otto-email-label-short">Email</span>
        </button>
      `;
      const btn = container.querySelector("#btn-email-signin");
      if (btn) {
        btn.addEventListener("click", () => {
          const modal = document.getElementById("otto-email-signin-modal");
          if (modal) {
            const sBtn = document.getElementById("otto-email-signin-modal-submit-btn");
            const fbEl = document.getElementById("otto-email-signin-modal-feedback");
            if (sBtn) {
              sBtn.disabled = false;
              sBtn.textContent = "Send Magic Link";
            }
            if (fbEl) fbEl.textContent = "";
            modal.classList.remove("otto-hidden");
            modal.style.display = "flex";
            const inp = document.getElementById("otto-email-signin-modal-email-input");
            if (inp && window.innerWidth > 640 && !("ontouchstart" in window)) {
              inp.focus();
            }
          }
        });
      }
    }

    if (isCurrentlySignedIn) {
      toggleAuthButtons(true);
    }
  }

  /**
   * Wires dev-mode sign-in (when config.dev_mode), Google Sign-In (when config.google_client_id),
   * and Firebase Auth Email Link (when config.firebase / config.firebase_config).
   * `onToken` is awaited after a token has been stored (callers typically restore the session).
   */
  function setupSignIn(config, onToken) {
    if (!config) return;
    const isCurrentlySignedIn = Boolean(
      state.currentUser ||
      getStoredAuthToken() ||
      (document.getElementById("profile-pill") &&
       document.getElementById("profile-pill").style.display !== "none" &&
       !document.getElementById("profile-pill").classList.contains("hidden"))
    );
    const devRoot = document.getElementById("dev-signin-root");
    let devBtn = document.getElementById("btn-dev-login") || document.getElementById("dev-signin-btn");
    if (config.dev_mode && devRoot && !devBtn) {
      devBtn = document.createElement("button");
      devBtn.type = "button";
      devBtn.id = "btn-dev-login";
      devBtn.className = "btn btn-sm";
      devBtn.textContent = "🛠️ Dev Login";
      devRoot.appendChild(devBtn);
    }
    if (config.dev_mode && devBtn) {
      if (devRoot) devRoot.style.display = isCurrentlySignedIn ? "none" : "block";
      devBtn.onclick = async () => {
        storeAuthToken("dev-token", "dev");
        if (onToken) await onToken("dev-token");
      };
    }
    if (config.google_client_id) {
      renderGoogleSignIn({ clientId: config.google_client_id, onCredential: onToken });
    }
    const fbConfig = config.firebase || config.firebase_config;
    if (fbConfig && fbConfig.apiKey) {
      setupEmailSignIn(fbConfig, onToken);
    }
    if (isCurrentlySignedIn) {
      toggleAuthButtons(true);
    }
  }

  function renderMaintenanceBanner(maintenance) {
    let banner = document.getElementById("ottomate-maintenance-banner");
    if (!maintenance || !maintenance.active) {
      if (banner) banner.remove();
      return;
    }
    if (!banner) {
      banner = document.createElement("div");
      banner.id = "ottomate-maintenance-banner";
      banner.style.cssText =
        "background:#b91c1c; color:#ffffff; padding:0.65rem 1rem; text-align:center; font-weight:700; font-size:0.88rem; box-shadow:0 2px 8px rgba(0,0,0,0.2); position:relative; z-index:9999;";
      document.body.prepend(banner);
    }
    const note = maintenance.admin_note || "Service is currently undergoing scheduled maintenance.";
    banner.innerHTML = `⚠️ <strong>Maintenance Mode Active:</strong> ${escapeHtml(note)} <span style="font-weight:normal; opacity:0.85; font-size:0.8rem; margin-left:0.5rem;">(Admins only)</span>`;
  }

  async function syncAppVersion() {
    try {
      const config = await api("/api/config");
      state.config = config;
      const verEl = document.getElementById("app-version");
      if (verEl && config.version) {
        verEl.textContent = `v${config.version}`;
      }
      renderMaintenanceBanner(config.maintenance);
      return config;
    } catch (err) {
      console.warn("Failed to sync /api/config:", err);
      return null;
    }
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (c) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    })[c]);
  }

  function formatDateTime(isoString) {
    if (!isoString) return "Never";
    try {
      const d = new Date(isoString);
      if (isNaN(d.getTime())) return isoString;
      return d.toLocaleDateString(undefined, {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });
    } catch {
      return isoString;
    }
  }

  function bindBrandHome(onBrandClicked) {
    const brand = document.getElementById("brand-home") || document.querySelector(".brand");
    if (!brand || typeof onBrandClicked !== "function") return null;
    brand.setAttribute("role", "button");
    brand.setAttribute("tabindex", "0");
    if (brand.dataset.ottomateBrandBound === "1") return brand;
    brand.dataset.ottomateBrandBound = "1";
    brand.addEventListener("click", (e) => {
      onBrandClicked(e);
    });
    brand.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        onBrandClicked(e);
      }
    });
    return brand;
  }

  function getUtcDate() {
    return new Date().toISOString().slice(0, 10);
  }

  function getUtcIso() {
    return new Date().toISOString();
  }

  function updateUtcClock(el) {
    if (!el) return;
    const now = new Date();
    const iso = now.toISOString();
    const datePart = iso.substring(0, 10);
    const timePart = iso.substring(11, 19);
    el.innerHTML = `<span class="utc-clock-icon">🕒</span> <span class="utc-clock-date">${datePart}</span> <span class="utc-clock-time">${timePart} UTC</span>`;
  }

  function initUtcClock() {
    let clockEl = document.getElementById("ottomate-utc-clock");
    if (!clockEl && typeof document !== "undefined") {
      clockEl = document.createElement("div");
      clockEl.id = "ottomate-utc-clock";
      clockEl.className = "utc-clock-pill";
      clockEl.setAttribute("role", "timer");
      clockEl.setAttribute("aria-live", "off");
      clockEl.title = "Platform Standard Time (Daily challenges reset at 00:00 UTC)";

      const brandTitleRow = document.querySelector(".brand-title-row");
      const versionTag = document.querySelector(".version-tag") || document.getElementById("app-version");
      if (versionTag && versionTag.parentNode) {
        versionTag.parentNode.insertBefore(clockEl, versionTag.nextSibling);
      } else if (brandTitleRow) {
        brandTitleRow.appendChild(clockEl);
      } else {
        const brand = document.getElementById("brand-home") || document.querySelector(".brand");
        if (brand) {
          brand.appendChild(clockEl);
        } else {
          const header = document.querySelector(".ottomate-header") || document.querySelector("header");
          if (header) {
            header.appendChild(clockEl);
          }
        }
      }
    }

    if (clockEl) {
      if (!clockEl.dataset.ottomateClockBound) {
        clockEl.dataset.ottomateClockBound = "1";
        clockEl.addEventListener("click", (e) => {
          e.stopPropagation();
        });
      }
      updateUtcClock(clockEl);
      if (state.clockTimer) {
        clearInterval(state.clockTimer);
      }
      state.clockTimer = setInterval(() => {
        if (typeof document === "undefined" || document.visibilityState !== "hidden") {
          updateUtcClock(clockEl);
        }
      }, 1000);
      if (typeof document !== "undefined" && !state.clockVisibilityBound) {
        document.addEventListener("visibilitychange", () => {
          if (document.visibilityState === "visible") {
            updateUtcClock(clockEl);
          }
        });
        state.clockVisibilityBound = true;
      }
    }
    return clockEl;
  }

  function initAudioToggle() {
    if (typeof document === "undefined") return null;
    let audioBtn = document.getElementById("ottomate-audio-toggle");
    if (!audioBtn) {
      audioBtn = document.createElement("button");
      audioBtn.id = "ottomate-audio-toggle";
      audioBtn.type = "button";
      audioBtn.className = "btn btn-secondary otto-audio-btn";
      audioBtn.setAttribute("role", "button");
      audioBtn.style.padding = "0.35rem 0.55rem";
      audioBtn.style.fontSize = "0.85rem";
      audioBtn.style.cursor = "pointer";
      audioBtn.style.display = "inline-flex";
      audioBtn.style.alignItems = "center";
      audioBtn.style.gap = "0.25rem";
      audioBtn.style.lineHeight = "1";

      const updateButtonState = () => {
        const isEnabled = window.Ottomate?.audio?.isEnabled ? window.Ottomate.audio.isEnabled() : true;
        audioBtn.innerHTML = isEnabled ? "<span>🔊</span>" : "<span>🔇</span>";
        audioBtn.title = isEnabled ? "Sound Effects: Enabled (Click to mute)" : "Sound Effects: Muted (Click to enable)";
        audioBtn.setAttribute("aria-label", isEnabled ? "Mute sound effects" : "Enable sound effects");
      };

      audioBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        if (window.Ottomate?.audio?.toggle) {
          window.Ottomate.audio.toggle();
        }
        updateButtonState();
      });

      if (typeof window !== "undefined") {
        window.addEventListener("ottomate:audio-toggle", updateButtonState);
      }
      updateButtonState();

      const container = document.querySelector(".header-actions") || document.querySelector("header");
      if (container) {
        const navAnchor = document.getElementById("btn-history") ||
                          document.getElementById("btn-stats") ||
                          document.getElementById("btn-leaderboard");
        if (navAnchor && navAnchor.parentNode === container) {
          container.insertBefore(audioBtn, navAnchor.nextSibling);
        } else {
          const target = document.getElementById("otto-auth-group") ||
                         document.getElementById("g-signin-root") ||
                         document.getElementById("btn-directory") ||
                         document.getElementById("profile-pill") ||
                         document.getElementById("btn-logout");
          if (target && target.parentNode === container) {
            container.insertBefore(audioBtn, target);
          } else {
            container.appendChild(audioBtn);
          }
        }
      }
    }
    return audioBtn;
  }

  function createPoller(callback, intervalMs = 3000) {
    let timerId = null;
    const onVisibilityChange = () => {
      if (document.visibilityState === "visible" && timerId !== null) {
        callback();
      }
    };
    return {
      start(immediate = false) {
        this.stop();
        if (immediate) callback();
        timerId = setInterval(() => {
          if (typeof document === "undefined" || document.visibilityState !== "hidden") {
            callback();
          }
        }, intervalMs);
        if (typeof document !== "undefined") {
          document.addEventListener("visibilitychange", onVisibilityChange);
        }
      },
      stop() {
        if (timerId !== null) {
          clearInterval(timerId);
          timerId = null;
        }
        if (typeof document !== "undefined") {
          document.removeEventListener("visibilitychange", onVisibilityChange);
        }
      },
      isActive() {
        return timerId !== null;
      },
    };
  }

  const cronController = {
    refreshState: null,
    elapsedInterval: null,
    pollTimer: null,
    completeHideTimeout: null,
    onComplete: null,
    getTriggerPayload: null,
  };

  function formatElapsedSeconds(sec) {
    const s = Math.max(0, Math.floor(sec || 0));
    if (s < 60) return `${s}s`;
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return `${m}m ${rem}s`;
  }

  function computeLiveElapsedSeconds(st) {
    if (!st) return 0;
    if (st.started_at && st.in_progress) {
      const startMs = Date.parse(st.started_at);
      if (!Number.isNaN(startMs)) {
        return Math.max(0, Math.floor((Date.now() - startMs) / 1000));
      }
    }
    return Math.max(0, Math.floor(st.elapsed_seconds || 0));
  }

  function ensureRefreshBannerElement() {
    if (typeof document === "undefined") return null;
    let banner = document.getElementById("refresh-progress-banner");
    if (banner) return banner;

    const mainEl = document.querySelector("main") || document.body;
    if (!mainEl) return null;
    banner = document.createElement("div");
    banner.id = "refresh-progress-banner";
    banner.className = "refresh-progress-banner";
    banner.style.display = "none";
    banner.setAttribute("role", "status");
    banner.setAttribute("aria-live", "polite");
    banner.innerHTML = `
      <div class="refresh-banner-main">
        <div class="refresh-banner-left">
          <span class="refresh-spinner" id="refresh-banner-icon" aria-hidden="true">🔄</span>
          <div>
            <div class="refresh-banner-title" id="refresh-banner-title">Refresh in progress...</div>
            <div class="refresh-banner-subtitle" id="refresh-banner-subtitle">Syncing live data &amp; evaluating completed rounds</div>
          </div>
        </div>
        <div class="refresh-elapsed-pill" id="refresh-elapsed-pill">⏱️ 0s elapsed</div>
      </div>
      <div class="refresh-progress-track" id="refresh-progress-track">
        <div class="refresh-progress-bar"></div>
      </div>
    `;
    mainEl.prepend(banner);
    return banner;
  }

  function renderCronRefreshBanner(st, justCompleted = false) {
    const banner = ensureRefreshBannerElement();
    if (!banner) return;
    const iconEl = document.getElementById("refresh-banner-icon");
    const titleEl = document.getElementById("refresh-banner-title");
    const subEl = document.getElementById("refresh-banner-subtitle");
    const elapsedEl = document.getElementById("refresh-elapsed-pill");
    const trackEl = document.getElementById("refresh-progress-track");
    const btnRefresh = document.getElementById("btn-admin-refresh");
    const cronCfg = state.config?.cron || {};

    const inProgress = Boolean(st && st.in_progress);
    const defaultBtnLabel = cronCfg.button_label || "🔄 Refresh & Evaluate";

    if (btnRefresh) {
      btnRefresh.disabled = inProgress;
      btnRefresh.textContent = inProgress ? "🔄 Refreshing..." : defaultBtnLabel;
    }

    if (inProgress) {
      if (cronController.completeHideTimeout) {
        clearTimeout(cronController.completeHideTimeout);
        cronController.completeHideTimeout = null;
      }
      banner.style.display = "block";
      banner.classList.remove("refresh-completed");
      if (iconEl) iconEl.textContent = "🔄";
      if (titleEl) titleEl.textContent = cronCfg.in_progress_title || "Refresh in progress...";
      const who =
        st.triggered_by === "cloud-scheduler" || (st.triggered_by && st.triggered_by.endsWith(".gserviceaccount.com"))
          ? "Scheduled evaluation"
          : st.triggered_by
          ? `Triggered by ${st.triggered_by.split("@")[0]}`
          : "Admin refresh";
      const wkNote = st.week_number ? ` (Week ${st.week_number})` : "";
      const baseSub = cronCfg.in_progress_subtitle || "Syncing live data & evaluating completed rounds";
      if (subEl) {
        subEl.textContent = `${who}${wkNote} • ${baseSub}`;
      }
      const elapsedSec = computeLiveElapsedSeconds(st);
      if (elapsedEl) {
        elapsedEl.textContent = `⏱️ ${formatElapsedSeconds(elapsedSec)} elapsed`;
      }
      if (trackEl) trackEl.style.display = "block";

      if (!cronController.elapsedInterval) {
        cronController.elapsedInterval = setInterval(() => {
          if (!cronController.refreshState || !cronController.refreshState.in_progress) return;
          const sec = computeLiveElapsedSeconds(cronController.refreshState);
          const pill = document.getElementById("refresh-elapsed-pill");
          if (pill) {
            pill.textContent = `⏱️ ${formatElapsedSeconds(sec)} elapsed`;
          }
        }, 1000);
      }
    } else if (justCompleted) {
      if (cronController.elapsedInterval) {
        clearInterval(cronController.elapsedInterval);
        cronController.elapsedInterval = null;
      }
      banner.style.display = "block";
      banner.classList.add("refresh-completed");
      if (iconEl) iconEl.textContent = "✅";
      const evaluatedCount = st?.last_result?.evaluated_count ?? st?.last_result?.evaluated_weeks_count ?? 0;
      if (titleEl) {
        titleEl.textContent =
          evaluatedCount > 0
            ? `Refresh complete — ${evaluatedCount} item(s) evaluated!`
            : cronCfg.completed_title || "Refresh complete — Standings & data synced!";
      }
      if (subEl) {
        subEl.textContent = st?.last_result?.summary || "All standings and records are up to date.";
      }
      const totalSec = Math.max(1, computeLiveElapsedSeconds(st));
      if (elapsedEl) {
        elapsedEl.textContent = `✓ Done in ${formatElapsedSeconds(totalSec)}`;
      }
      if (trackEl) trackEl.style.display = "none";

      if (cronController.completeHideTimeout) clearTimeout(cronController.completeHideTimeout);
      cronController.completeHideTimeout = setTimeout(() => {
        banner.style.display = "none";
        banner.classList.remove("refresh-completed");
      }, 4500);
    } else {
      if (cronController.elapsedInterval) {
        clearInterval(cronController.elapsedInterval);
        cronController.elapsedInterval = null;
      }
      if (!cronController.completeHideTimeout) {
        banner.style.display = "none";
        banner.classList.remove("refresh-completed");
      }
    }
  }

  function applyCronRefreshStatus(newState) {
    if (!newState) return;
    const wasInProgress = Boolean(cronController.refreshState && cronController.refreshState.in_progress);
    const nowInProgress = Boolean(newState.in_progress);
    const justCompleted = wasInProgress && !nowInProgress;

    cronController.refreshState = newState;
    renderCronRefreshBanner(newState, justCompleted);

    if (nowInProgress) {
      scheduleNextCronRefreshPoll(1500);
    } else if (justCompleted) {
      scheduleNextCronRefreshPoll(10000);
      if (typeof cronController.onComplete === "function") {
        cronController.onComplete(newState);
      }
    }
  }

  async function checkCronRefreshStatusOnce() {
    try {
      const res = await fetch("/api/cron/status");
      if (!res.ok) return;
      const statusData = await res.json();
      applyCronRefreshStatus(statusData);
    } catch {
      // Ignore transient polling errors
    }
  }

  function scheduleNextCronRefreshPoll(delayMs = 10000) {
    if (cronController.pollTimer) {
      clearTimeout(cronController.pollTimer);
    }
    cronController.pollTimer = setTimeout(async () => {
      if (typeof document === "undefined" || document.visibilityState !== "hidden") {
        await checkCronRefreshStatusOnce();
      }
      const nextDelay = cronController.refreshState && cronController.refreshState.in_progress ? 1500 : 10000;
      scheduleNextCronRefreshPoll(nextDelay);
    }, delayMs);
  }

  async function triggerCronRefresh(customPayload = null) {
    if (cronController.refreshState && cronController.refreshState.in_progress) {
      return cronController.refreshState;
    }
    const payload =
      customPayload ||
      (typeof cronController.getTriggerPayload === "function" ? cronController.getTriggerPayload() : {}) ||
      {};

    applyCronRefreshStatus({
      in_progress: true,
      started_at: new Date().toISOString(),
      elapsed_seconds: 0,
      triggered_by: state.currentUser?.email || "admin",
      ...payload,
    });

    try {
      const st = await api("/api/cron/trigger", {
        method: "POST",
        body: payload,
      });
      applyCronRefreshStatus(st);
      await checkCronRefreshStatusOnce();
      return st;
    } catch (err) {
      cronController.refreshState = { in_progress: false };
      renderCronRefreshBanner(cronController.refreshState, false);
      throw err;
    }
  }

  async function initCronRefresh(options = {}) {
    if (options.onComplete) cronController.onComplete = options.onComplete;
    if (options.getTriggerPayload) cronController.getTriggerPayload = options.getTriggerPayload;
    await checkCronRefreshStatusOnce();
    scheduleNextCronRefreshPoll(options.pollIntervalMs || 10000);
  }

  async function initHeader(options = {}) {
    const {
      onUserSignedIn,
      onSignOut,
      onDirectoryClicked,
      onProfileClicked,
      onStatsClicked,
      onBrandClicked,
      skipConfigSync = false,
    } = options;

    if (onSignOut) {
      window.ottomateSignOut = onSignOut;
    }

    // 1. Fetch system configuration unless caller handles it
    const config = skipConfigSync ? state.config : await syncAppVersion();

    // 2. Wire Brand home click + keyboard navigation
    if (onBrandClicked) {
      bindBrandHome(onBrandClicked);
    }

    // 3. Wire Profile Pill click
    const profilePill = document.getElementById("profile-pill") || document.getElementById("profile-btn");
    if (profilePill && onProfileClicked && !profilePill.dataset.ottoHeaderBound) {
      profilePill.dataset.ottoHeaderBound = "1";
      profilePill.addEventListener("click", onProfileClicked);
    }

    // 4. Wire Directory button click
    const directoryBtn = document.getElementById("btn-directory") || document.getElementById("admin-settings-btn");
    if (directoryBtn && onDirectoryClicked && !directoryBtn.dataset.ottoHeaderBound) {
      directoryBtn.dataset.ottoHeaderBound = "1";
      directoryBtn.addEventListener("click", onDirectoryClicked);
    }

    // 5. Wire Stats button click
    const statsBtn = document.getElementById("btn-stats");
    if (statsBtn && onStatsClicked && !statsBtn.dataset.ottoHeaderBound) {
      statsBtn.dataset.ottoHeaderBound = "1";
      statsBtn.addEventListener("click", onStatsClicked);
    }

    // 6. Wire Logout button click
    const logoutBtn =
      document.getElementById("btn-logout") ||
      document.getElementById("btn-signout") ||
      document.getElementById("signout");
    if (logoutBtn && onSignOut && !logoutBtn.dataset.ottoHeaderBound) {
      logoutBtn.dataset.ottoHeaderBound = "1";
      logoutBtn.addEventListener("click", () => {
        clearAuthToken();
        toggleAuthButtons(false);
        const pill = document.getElementById("profile-pill") || document.getElementById("profile-btn");
        if (pill) {
          pill.classList.add("hidden");
          pill.style.display = "none";
        }
        onSignOut();
      });
    }

    // 7. Initialize live UTC clock pill
    initUtcClock();

    // 8. Initialize header audio toggle
    initAudioToggle();

    // 9. Observe profile pill mutations to guarantee all sign-in buttons disappear
    // immediately whenever any app makes the user profile avatar/pill visible.
    if (profilePill && typeof MutationObserver !== "undefined" && !profilePill.dataset.ottoPillObserved) {
      profilePill.dataset.ottoPillObserved = "1";
      let lastObservedVisible = null;
      const observer = new MutationObserver(() => {
        const isVisible = profilePill.style.display !== "none" && !profilePill.classList.contains("hidden");
        if (isVisible !== lastObservedVisible) {
          lastObservedVisible = isVisible;
          if (isVisible) {
            toggleAuthButtons(true);
          }
        }
      });
      observer.observe(profilePill, { attributes: true, attributeFilter: ["style", "class"] });
    }

    if (getStoredAuthToken() || state.currentUser) {
      toggleAuthButtons(true);
    }

    return {
      config,
      state,
      api,
      escapeHtml,
      formatDateTime,
      getInitials,
      bindBrandHome,
      createPoller,
      updateProfilePill,
      toggleAuthButtons,
      syncAppVersion,
      storeAuthToken,
      clearAuthToken,
      getStoredAuthToken,
      renderGoogleSignIn,
      setupSignIn,
      setupEmailSignIn,
      ensureEmailSignInModal,
      handleEmailSignInLink,
      isEmailSignInUrl,
      loadFirebaseSdk,
      getUtcDate,
      getUtcIso,
      updateUtcClock,
      initUtcClock,
      initCronRefresh,
      applyCronRefreshStatus,
      triggerCronRefresh,
    };
  }

  return {
    state,
    api,
    escapeHtml,
    formatDateTime,
    getInitials,
    bindBrandHome,
    createPoller,
    updateProfilePill,
    toggleAuthButtons,
    syncAppVersion,
    storeAuthToken,
    clearAuthToken,
    getStoredAuthToken,
    renderGoogleSignIn,
    setupSignIn,
    setupEmailSignIn,
    ensureEmailSignInModal,
    handleEmailSignInLink,
    isEmailSignInUrl,
    loadFirebaseSdk,
    getUtcDate,
    getUtcIso,
    updateUtcClock,
    initUtcClock,
    initCronRefresh,
    applyCronRefreshStatus,
    triggerCronRefresh,
    initHeader,
  };
});

