from __future__ import annotations
import re
from typing import Any, Iterator, Mapping, Sequence
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator, model_validator

from ottomate_core.db import format_short_name, format_timestamp, resolve_session_admins


class DictCompatibleModel(BaseModel):
    """Pydantic BaseModel with full dict-access compatibility for gradual migration & Firestore persistence.

    Allows callers to use strongly-typed attributes (`obj.status`, `obj.bids`) and domain methods
    while preserving legacy dictionary operations (`obj["status"]`, `obj.get("status")`, `"status" in obj`).
    """

    model_config = ConfigDict(extra="allow", validate_assignment=False)

    def __getitem__(self, key: str) -> Any:
        try:
            return getattr(self, key)
        except AttributeError as exc:
            if self.__pydantic_extra__ and key in self.__pydantic_extra__:
                return self.__pydantic_extra__[key]
            raise KeyError(key) from exc

    def __setitem__(self, key: str, value: Any) -> None:
        setattr(self, key, value)

    def __contains__(self, key: object) -> bool:
        if not isinstance(key, str):
            return False
        if key in self.__class__.model_fields:
            return True
        if self.__pydantic_extra__ and key in self.__pydantic_extra__:
            return True
        return hasattr(self, key)

    def get(self, key: str, default: Any = None) -> Any:
        try:
            val = self[key]
            return default if val is None and key not in self.model_fields_set and key not in self.__class__.model_fields else val
        except KeyError:
            return default

    def keys(self) -> list[str]:
        base_keys = list(self.__class__.model_fields.keys())
        extra_keys = list(self.__pydantic_extra__.keys()) if self.__pydantic_extra__ else []
        return base_keys + [k for k in extra_keys if k not in base_keys]

    def values(self) -> list[Any]:
        return [self[k] for k in self.keys()]

    def items(self) -> list[tuple[str, Any]]:
        return [(k, self[k]) for k in self.keys()]

    def __iter__(self) -> Iterator[str]:  # type: ignore[override]
        return iter(self.keys())

    def update(self, mapping: Mapping[str, Any] | None = None, **kwargs: Any) -> None:
        if mapping:
            for k, v in mapping.items():
                setattr(self, k, v)
        for k, v in kwargs.items():
            setattr(self, k, v)

    def to_dict(self) -> dict[str, Any]:
        """Serializes this domain object (and nested models) to a plain Python dict suitable for JSON/Firestore."""
        return self.model_dump(mode="python")


class BaseSessionObject(DictCompatibleModel):
    """Shared base domain object for any multi-player game or challenge session in Firestore."""

    id: str
    title: str = "Untitled"
    created_by: str | None = None
    created_by_name: str | None = None
    admins: list[str] = Field(default_factory=list)
    status: str = "active"
    created_at: str | None = None
    updated_at: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _coerce_aliases(cls, values: Any) -> Any:
        if not isinstance(values, Mapping):
            return values
        d = dict(values)
        if "id" not in d:
            if "game_id" in d:
                d["id"] = d["game_id"]
            elif "challenge_id" in d:
                d["id"] = d["challenge_id"]
        if "title" not in d and "name" in d:
            d["title"] = d["name"]
        if "created_by" not in d and "creator_id" in d:
            d["created_by"] = d["creator_id"]
        if "created_by_name" not in d and "creator_name" in d:
            d["created_by_name"] = d["creator_name"]
        if "admins" not in d and "session_admins" in d:
            d["admins"] = d["session_admins"]
        return d

    @property
    def game_id(self) -> str:
        """Alias for `id` commonly used in game services."""
        return self.id

    @property
    def name(self) -> str:
        """Alias for `title` commonly used in game services."""
        return self.title

    @property
    def creator_id(self) -> str | None:
        """Alias for `created_by`."""
        return self.created_by

    @property
    def creator_name(self) -> str | None:
        """Alias for `created_by_name`."""
        return self.created_by_name

    @property
    def session_admins(self) -> list[str]:
        """Alias for `admins`."""
        return self.admins

    @staticmethod
    def extract_session_metadata(data: Mapping[str, Any]) -> dict[str, Any]:
        """Extracts normalized creator, admin list, and ISO timestamps from a raw Firestore document."""
        return {
            "created_by": data.get("created_by") or data.get("creator_id"),
            "admins": resolve_session_admins(dict(data)),
            "created_at": format_timestamp(data.get("created_at")),
            "updated_at": format_timestamp(data.get("updated_at")),
        }

    @staticmethod
    def resolve_display_name(email: str, display_names: Mapping[str, str]) -> str:
        """Resolves a player/creator email to a clean display name using the users directory map."""
        d_name = display_names.get(email)
        if not d_name or d_name == email or ("@" in d_name and "@" in email):
            return format_short_name(email)
        return d_name

    def attach_creator_name(self, display_names: Mapping[str, str]) -> "BaseSessionObject":
        """Populates `created_by_name` from a resolved display_names mapping."""
        if self.created_by:
            self.created_by_name = self.resolve_display_name(self.created_by, display_names)
        return self

    @classmethod
    def resolve_player_names_map(
        cls, players: Sequence[str], display_names: Mapping[str, str]
    ) -> dict[str, str]:
        """Builds a `{email: display_name}` mapping for all seated players."""
        return {p: cls.resolve_display_name(p, display_names) for p in players}


class BaseMatchSession(BaseSessionObject):
    """Domain model for multi-hand card or board games played to a target score."""

    target_score: int = 10
    team1_score: int = 0
    team2_score: int = 0
    current_hand_number: int = 1
    current_hand_id: str = ""
    winner_team: int | None = None
    rematch_game_id: str | None = None
    completed_at: str | None = None


class ProfileUpdate(BaseModel):
    display_name: str | None = None
    preferences: PreferencesUpdate | dict[str, Any] | None = None

    @field_validator("display_name")
    def validate_display_name(cls, value: str | None) -> str | None:
        if value is None:
            return None
        trimmed = value.strip()
        if not (1 <= len(trimmed) <= 59):
            raise ValueError("Display nickname must be between 1 and 59 characters long.")
        if not re.match(r"^[a-zA-Z0-9]+$", trimmed):
            raise ValueError("Display nickname must contain only letters and numbers (no spaces or special characters).")
        return trimmed


class PreferencesUpdate(BaseModel):
    """Free-form user preferences. Services define their own keys (extras are preserved)."""

    model_config = ConfigDict(extra="allow")


class UserRoleUpdate(BaseModel):
    service: str | None = None
    role: str

    @field_validator("role")
    def validate_role(cls, value: str) -> str:
        trimmed = value.strip().lower()
        if trimmed not in ("game_admin", "admin", "participant", "player", "user"):
            raise ValueError("Role must be one of 'game_admin', 'admin', 'participant', 'player' or 'user'.")
        return trimmed


class ConfigResponse(DictCompatibleModel):
    google_client_id: str
    dev_mode: bool
    version: str
    core_version: str | None = None
    service_metadata: dict[str, Any] | None = None
    maintenance: dict[str, Any] | None = None
    cron: dict[str, Any] | None = None
    firebase: dict[str, Any] | None = None
    firebase_config: dict[str, Any] | None = None


class CronConfig(DictCompatibleModel):
    """Centralized configuration for a service's scheduled Cloud Scheduler cron job and UI admin refresh bar."""

    enabled: bool = True
    schedule: str = "0 9 * * 1"
    time_zone: str = "Etc/UTC"
    endpoint: str = "/api/cron/run"
    alias_endpoints: list[str] = Field(default_factory=list)
    description: str = "Automated scheduled evaluation and refresh"
    button_label: str = "🔄 Refresh & Evaluate"
    in_progress_title: str = "Refresh in progress..."
    in_progress_subtitle: str = "Syncing live data & evaluating completed rounds"
    completed_title: str = "Refresh complete!"
    session_collections: list[str] = Field(default_factory=lambda: ["challenges", "games"])
    collection_name: str = "cron_status"
    document_id: str = "refresh_status"
    stale_seconds: int = 120


class CronEvaluationResult(DictCompatibleModel):
    """Canonical output schema returned by all Ottomate cron and manual refresh executions."""

    timestamp: str
    service: str = ""
    triggered_by: str = "system"
    evaluated_count: int = 0
    evaluated_weeks_count: int = 0
    details: list[dict[str, Any]] = Field(default_factory=list)
    summary: str | None = None


class CronRefreshStatus(DictCompatibleModel):
    """Shared Firestore state tracking active or recently completed cron / manual refresh jobs."""

    in_progress: bool = False
    started_at: str | None = None
    completed_at: str | None = None
    elapsed_seconds: int = 0
    triggered_by: str | None = None
    challenge_id: str | None = None
    session_id: str | None = None
    week_number: int | None = None
    last_result: dict[str, Any] | None = None
    error: str | None = None


class CronTriggerRequest(BaseModel):
    """Payload accepted by POST /api/cron/trigger for manual admin refresh triggers."""

    challenge_id: str | None = None
    session_id: str | None = None
    week_number: int | None = None



class ServiceCardMetadata(DictCompatibleModel):
    """Metadata provided by a service to describe its catalog card in Ottomate Hub."""

    service_id: str
    title: str
    tagline: str = ""
    description: str = ""
    category: str = "games"
    category_label: str = ""
    icon: str = "🎮"
    url: str | None = None
    tags: list[str] = Field(default_factory=list)
    highlight: str | None = None
    color: str | None = None
    launched_at: str | None = None
    is_denylisted: bool = False
    admin_note: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class ServiceCardAdminUpdate(BaseModel):
    """Admin overrides for a service catalog card in Ottomate Hub."""

    is_denylisted: bool | None = None
    admin_note: str | None = None
    tagline: str | None = None
    description: str | None = None


class PendingPlayerAction(DictCompatibleModel):
    """Represents an active turn or daily pending action requiring player interaction."""

    action_id: str
    service_id: str
    user_id: str
    type: str = "turn"  # "turn" or "daily"
    title: str
    subtitle: str | None = None
    message: str
    url: str
    icon: str | None = None
    dismissed: bool = False
    dismissed_at: str | None = None
    created_at: str | None = None
    updated_at: str | None = None


class EmailCheckRequest(BaseModel):
    email: EmailStr


class ProxyAddRequest(BaseModel):
    email: EmailStr


class AdminProxiesUpdate(BaseModel):
    proxies: list[EmailStr]


class UserCreateRequest(BaseModel):
    email: EmailStr
    display_name: str | None = None
    nickname: str | None = None
    role: str | None = None



