import hashlib
import logging
import os
from datetime import datetime, timezone
from functools import lru_cache
from typing import Any, Mapping
from google.cloud import firestore

from ottomate_core import config as _config
from ottomate_core.config import DEFAULT_PROJECT, USERS_COLLECTION

logger = logging.getLogger(__name__)


def normalize_email(email: str) -> str:
    """Canonical email form for the whole platform (strip + lowercase).

    `user_key()` hashes this value to build Firestore document IDs, so every
    service MUST use this single implementation to avoid split user documents.
    """
    return email.strip().lower()


def user_key(email: str) -> str:
    """Returns the deterministic Firestore document key (SHA-256) for a given email address."""
    return hashlib.sha256(normalize_email(email).encode("utf-8")).hexdigest()


def format_short_name(name_or_email: str | None) -> str:
    if not name_or_email:
        return ""
    str_val = str(name_or_email).strip()
    if "@" in str_val:
        return str_val.split("@", 1)[0]
    return str_val


_database_provider = None
_users_database_provider = None


def set_database_provider(provider):
    """Overrides the Firestore client factory (pass `None` to restore the default)."""
    global _database_provider
    _database_provider = provider


def set_users_database_provider(provider):
    """Overrides the users Firestore client factory (pass `None` to restore the default)."""
    global _users_database_provider
    _users_database_provider = provider


def database(database_name: str | None = None) -> firestore.Client:
    """Returns the Firestore client for the application/game database.

    If `database_name` is omitted, resolves from the `FIRESTORE_DATABASE`
    environment variable (e.g. 'pushups', 'upanddown', 'yuquer'), then the
    default registered via `ottomate_core.config.configure_service()`, falling
    back to '(default)'.
    """
    if _database_provider is not None:
        if callable(_database_provider):
            try:
                return _database_provider(database_name)
            except TypeError:
                return _database_provider()
        return _database_provider
    project = os.environ.get("GOOGLE_CLOUD_PROJECT", DEFAULT_PROJECT)
    db_name = (
        database_name
        or os.environ.get("FIRESTORE_DATABASE")
        or _config.get_default_database()
        or "(default)"
    )
    return _get_firestore_client(project, db_name)


def users_database() -> firestore.Client:
    """Returns the Firestore client for the shared platform identity database.

    The `users` collection resides in this database (default '(default)').
    """
    if _users_database_provider is not None:
        if callable(_users_database_provider):
            return _users_database_provider()
        return _users_database_provider
    if _database_provider is not None:
        # Fallback to general database provider in test environments unless explicitly overridden
        if callable(_database_provider):
            try:
                return _database_provider("(default)")
            except TypeError:
                return _database_provider()
        return _database_provider
    project = os.environ.get("GOOGLE_CLOUD_PROJECT", DEFAULT_PROJECT)
    db_name = os.environ.get("FIRESTORE_USERS_DATABASE") or "(default)"
    return _get_firestore_client(project, db_name)


@lru_cache
def _get_firestore_client(project: str, database: str = "(default)") -> firestore.Client:
    if os.environ.get("PYTEST_CURRENT_TEST") and not os.environ.get("OTTOMATE_ALLOW_REAL_FIRESTORE_IN_TESTS"):
        raise RuntimeError(
            "Attempted to initialize a real google.cloud.firestore.Client during a pytest run! "
            "Use `use_database(monkeypatch, FakeDatabase())` or pass a `FakeDatabase` instance explicitly."
        )
    if database and database != "(default)":
        return firestore.Client(project=project, database=database)
    return firestore.Client(project=project)


def resolve_user_display_names(emails: set[str], db: firestore.Client | None = None) -> dict[str, str]:
    """Resolves a set of emails to their custom display names from the users collection."""
    client = db if db is not None else users_database()
    names = {}
    for email in emails:
        if not email:
            continue
        norm_email = normalize_email(email)
        try:
            user_snap = client.collection(USERS_COLLECTION).document(user_key(norm_email)).get()
            if user_snap.exists and user_snap.to_dict():
                data = user_snap.to_dict()
                name = data.get("display_name") or data.get("nickname")
                if name:
                    names[email] = name
        except Exception:
            logger.warning("Failed to resolve display name for %s", norm_email, exc_info=True)
    return names



def format_timestamp(value) -> str | None:
    """Formats a Firestore/datetime timestamp as an ISO-8601 string (or None)."""
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def resolve_session_admins(data: dict) -> list[str]:
    """Returns deduplicated session admin emails for a challenge/game document."""
    creator = data.get("created_by")
    raw_admins = data.get("admins", [creator]) if creator else data.get("admins", [])
    return list(set(raw_admins))


def to_firestore_dict(value):
    """Recursively converts Pydantic/DictCompatibleModel instances into plain Firestore-compatible dicts/lists."""
    if hasattr(value, "to_dict") and callable(value.to_dict):
        return to_firestore_dict(value.to_dict())
    if hasattr(value, "model_dump") and callable(value.model_dump):
        return to_firestore_dict(value.model_dump(mode="python"))
    if isinstance(value, dict):
        return {k: to_firestore_dict(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [to_firestore_dict(v) for v in value]
    return value


def _register_firestore_model_encoder() -> None:
    """Allows google-cloud-firestore to natively encode DictCompatibleModel / BaseModel instances."""
    try:
        from google.cloud.firestore_v1 import _helpers as fs_helpers

        orig_encode_value = getattr(fs_helpers, "encode_value", None)
        if orig_encode_value and not getattr(orig_encode_value, "_ottomate_patched", False):

            def _patched_encode_value(value):
                if hasattr(value, "to_dict") and callable(value.to_dict):
                    return orig_encode_value(to_firestore_dict(value))
                if hasattr(value, "model_dump") and callable(value.model_dump):
                    return orig_encode_value(to_firestore_dict(value))
                return orig_encode_value(value)

            _patched_encode_value._ottomate_patched = True  # type: ignore[attr-defined]
            fs_helpers.encode_value = _patched_encode_value
    except Exception:
        pass


_register_firestore_model_encoder()


def sync_service_card_to_registry(card: Mapping[str, Any]) -> dict[str, Any] | None:
    """Syncs the service's card metadata into the shared (default) Firestore 'services' collection.

    Preserves admin overrides (is_denylisted, admin_note) if already configured.
    """
    from datetime import datetime, timezone
    from ottomate_core.config import SERVICES_COLLECTION

    card_data = dict(card)
    service_id = card_data.get("service_id")
    if not service_id:
        return None

    try:
        db = users_database()
        doc_ref = db.collection(SERVICES_COLLECTION).document(service_id)
        doc = doc_ref.get()

        now_iso = datetime.now(timezone.utc).isoformat()
        if doc.exists:
            existing = doc.to_dict() or {}
            # Preserve admin overrides
            card_data["is_denylisted"] = existing.get("is_denylisted", card_data.get("is_denylisted", False))
            card_data["admin_note"] = existing.get("admin_note", card_data.get("admin_note"))
            if existing.get("launched_at") and not card_data.get("launched_at"):
                card_data["launched_at"] = existing.get("launched_at")
            card_data["created_at"] = existing.get("created_at", now_iso)
            card_data["updated_at"] = now_iso
        else:
            card_data.setdefault("is_denylisted", False)
            card_data.setdefault("admin_note", None)
            if not card_data.get("launched_at"):
                card_data["launched_at"] = now_iso[:10]
            card_data["created_at"] = now_iso
            card_data["updated_at"] = now_iso

        doc_ref.set(card_data, merge=True)
        return card_data
    except Exception as exc:
        logger.debug("Could not sync service card to registry: %s", exc)
        return None


def record_pending_action(
    action_id: str,
    service_id: str,
    user_id: str,
    message: str,
    url: str,
    *,
    action_type: str = "turn",
    title: str | None = None,
    subtitle: str | None = None,
    icon: str | None = None,
    **kwargs: Any,
) -> dict[str, Any] | None:
    """Records or updates an active player turn or pending daily action in shared Firestore."""
    from datetime import datetime, timezone
    from ottomate_core.config import PENDING_ACTIONS_COLLECTION

    clean_user = user_id.strip().lower()
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    now_iso = datetime.now(timezone.utc).isoformat()

    action_data: dict[str, Any] = {
        "action_id": action_id,
        "service_id": clean_service,
        "user_id": clean_user,
        "type": action_type,
        "action_type": action_type,
        "title": title or clean_service.title(),
        "subtitle": subtitle,
        "message": message,
        "url": url,
        "updated_at": now_iso,
    }
    if icon:
        action_data["icon"] = icon

    try:
        db = users_database()
        doc_ref = db.collection(PENDING_ACTIONS_COLLECTION).document(action_id)
        doc = doc_ref.get()
        if doc.exists:
            existing = doc.to_dict() or {}
            action_data["created_at"] = existing.get("created_at", now_iso)
            if existing.get("dismissed") is True:
                # Preserve user dismissal for the same daily/weekly action, or unchanged turn state
                same_turn = (
                    action_type == "turn"
                    and normalize_email(existing.get("user_id", "")) == clean_user
                    and existing.get("message") == message
                    and existing.get("subtitle") == subtitle
                )
                if action_type == "daily" or same_turn:
                    action_data["dismissed"] = True
                    action_data["dismissed_at"] = existing.get("dismissed_at", now_iso)
                else:
                    action_data["dismissed"] = False
                    action_data["dismissed_at"] = None
            else:
                action_data["dismissed"] = False
        else:
            action_data["created_at"] = now_iso
            action_data["dismissed"] = False
        doc_ref.set(action_data, merge=True)
        return None if action_data.get("dismissed") else action_data
    except Exception as exc:
        logger.warning("Could not record pending action '%s': %s", action_id, exc)
        return None


def dismiss_pending_action(action_id: str, user_id: str | None = None) -> bool:
    """Soft-dismisses a pending action so polling or re-syncing does not resurrect it."""
    from ottomate_core.config import PENDING_ACTIONS_COLLECTION

    now_iso = datetime.now(timezone.utc).isoformat()
    try:
        db = users_database()
        doc_ref = db.collection(PENDING_ACTIONS_COLLECTION).document(action_id)
        snap = doc_ref.get()
        if not snap.exists:
            return False
        data = snap.to_dict() or {}
        if user_id and normalize_email(data.get("user_id", "")) != normalize_email(user_id):
            raise PermissionError("You can only dismiss your own pending actions.")
        doc_ref.set(
            {
                "dismissed": True,
                "dismissed_at": now_iso,
                "updated_at": now_iso,
            },
            merge=True,
        )
        return True
    except PermissionError:
        raise
    except Exception as exc:
        logger.warning("Could not dismiss pending action '%s': %s", action_id, exc)
        return False


def clear_pending_action(action_id: str) -> bool:
    """Removes a completed pending turn or daily action by its action_id."""
    from ottomate_core.config import PENDING_ACTIONS_COLLECTION

    try:
        db = users_database()
        db.collection(PENDING_ACTIONS_COLLECTION).document(action_id).delete()
        return True
    except Exception as exc:
        logger.warning("Could not clear pending action '%s': %s", action_id, exc)
        return False


def clear_service_pending_actions(service_id: str, prefix: str | None = None) -> int:
    """Clears pending actions for a given service, optionally matching an action_id prefix."""
    from ottomate_core.config import PENDING_ACTIONS_COLLECTION

    clean_service = service_id.strip().lower().replace("ottomate-", "")
    deleted_count = 0
    try:
        db = users_database()
        query = db.collection(PENDING_ACTIONS_COLLECTION).where("service_id", "==", clean_service)
        docs = query.stream()
        for doc in docs:
            if prefix is None or doc.id.startswith(prefix):
                if hasattr(doc, "reference") and hasattr(doc.reference, "delete"):
                    doc.reference.delete()
                else:
                    db.collection(PENDING_ACTIONS_COLLECTION).document(doc.id).delete()
                deleted_count += 1
        return deleted_count
    except Exception as exc:
        logger.warning("Could not clear pending actions for service '%s': %s", service_id, exc)
        return 0


def get_user_pending_actions(user_id: str, *, include_dismissed: bool = False) -> list[dict[str, Any]]:
    """Retrieves all active pending actions for a specific player (case-insensitive)."""
    from ottomate_core.config import PENDING_ACTIONS_COLLECTION

    clean_user = user_id.strip().lower()
    actions: list[dict[str, Any]] = []
    try:
        db = users_database()
        docs = db.collection(PENDING_ACTIONS_COLLECTION).where("user_id", "==", clean_user).stream()
        for doc in docs:
            data = doc.to_dict() or {}
            if not include_dismissed and data.get("dismissed") is True:
                continue
            if "action_id" not in data:
                data["action_id"] = doc.id
            if "action_type" not in data and "type" in data:
                data["action_type"] = data["type"]
            actions.append(data)
        actions.sort(key=lambda a: a.get("updated_at", ""), reverse=True)
    except Exception as exc:
        logger.warning("Could not retrieve pending actions for user '%s': %s", clean_user, exc)
    return actions


def run_in_transaction(db: Any, callback: Any, *args: Any, **kwargs: Any) -> Any:
    """Executes `callback(transaction, *args, **kwargs)` atomically on real Firestore or `FakeDatabase`."""
    from google.cloud import firestore

    tx = db.transaction()
    if isinstance(db, firestore.Client):
        @firestore.transactional
        def _wrapped(transaction):
            return callback(transaction, *args, **kwargs)

        return _wrapped(tx)

    result = callback(tx, *args, **kwargs)
    if hasattr(tx, "commit"):
        tx.commit()
    return result


def record_daily_completed(
    service_id: str,
    user_id: str,
    date_str: str,
    *,
    subkey: str | None = None,
) -> None:
    """Marks a daily challenge or game completed for a given calendar date.

    1. Records `daily_completions.<service_id>.last_date` (and optional `items.<subkey>`)
       on `users/{user_key}` in the shared (default) database.
    2. Automatically clears any matching daily action from `pending_actions`.
    """
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    clean_user = normalize_email(user_id)
    uk = user_key(clean_user)

    try:
        db = users_database()
        doc_ref = db.collection(USERS_COLLECTION).document(uk)
        doc_snap = doc_ref.get()
        existing = doc_snap.to_dict() or {} if doc_snap.exists else {}
        daily_completions = dict(existing.get("daily_completions") or {})
        service_data = dict(daily_completions.get(clean_service) or {})

        # Update latest date
        last_date = service_data.get("last_date", "")
        if not last_date or date_str >= last_date:
            service_data["last_date"] = date_str

        # Update dates dictionary to preserve multi-day completion history
        dates = dict(service_data.get("dates") or {})
        dates[date_str] = datetime.now(timezone.utc).isoformat()
        service_data["dates"] = dates

        if subkey:
            items = dict(service_data.get("items") or {})
            items[subkey] = date_str
            service_data["items"] = items

        daily_completions[clean_service] = service_data
        update_payload: dict[str, Any] = {"daily_completions": daily_completions}
        if clean_service == "pushups":
            update_payload["last_result_date"] = date_str

        doc_ref.set(update_payload, merge=True)

        # Clear matching pending action(s)
        if subkey:
            clear_pending_action(f"{clean_service}_{clean_user}_{subkey}_{date_str}")
            clear_service_pending_actions(clean_service, prefix=f"{clean_service}_{clean_user}_{subkey}")
        else:
            clear_pending_action(f"{clean_service}_{clean_user}_{date_str}")
            clear_service_pending_actions(clean_service, prefix=f"{clean_service}_{clean_user}")
    except Exception as exc:
        logger.warning(
            "Could not record daily completion for service '%s', user '%s', date '%s': %s",
            clean_service,
            clean_user,
            date_str,
            exc,
        )


def is_daily_completed(
    service_id: str,
    user_id: str,
    date_str: str,
    *,
    subkey: str | None = None,
) -> bool:
    """Checks whether the user has already completed the daily challenge/task for date_str."""
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    clean_user = normalize_email(user_id)
    uk = user_key(clean_user)

    try:
        db = users_database()
        doc_ref = db.collection(USERS_COLLECTION).document(uk)
        doc_snap = doc_ref.get()
        if not doc_snap.exists:
            return False
        data = doc_snap.to_dict() or {}
        daily_completions = data.get("daily_completions") or {}
        service_data = daily_completions.get(clean_service) or {}

        if subkey:
            items = service_data.get("items") or {}
            item_val = items.get(subkey)
            return item_val == date_str or (item_val is not None and item_val >= date_str)

        # Backward compatibility for existing pushups records
        if clean_service == "pushups" and data.get("last_result_date") == date_str:
            return True

        # Check explicit dates mapping
        dates = service_data.get("dates") or {}
        if date_str in dates:
            return True

        # If user has completed up through date_str or ahead of it (e.g. UTC rollover)
        last_date = service_data.get("last_date")
        if last_date and last_date >= date_str:
            return True

        return False
    except Exception as exc:
        logger.warning(
            "Could not check daily completion for service '%s', user '%s', date '%s': %s",
            clean_service,
            clean_user,
            date_str,
            exc,
        )
        return False


def sync_daily_pending_action(
    service_id: str,
    user_id: str,
    date_str: str,
    *,
    is_completed: bool = False,
    title: str | None = None,
    subtitle: str | None = None,
    message: str | None = None,
    url: str = "",
    icon: str = "⚡",
    subkey: str | None = None,
) -> dict[str, Any] | None:
    """Standardized daily challenge or game pending action synchronization.

    If `is_completed` is True:
        Marks the task completed via `record_daily_completed` and clears the pending action.
    If `is_completed` is False:
        If `is_daily_completed()` returns True, ensures action is cleared and returns None.
        Otherwise, records the active daily pending action with action_id:
        `{service_id}_{user_id}_{subkey}_{date_str}` if subkey else `{service_id}_{user_id}_{date_str}`.
    """
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    clean_user = normalize_email(user_id)
    action_id = (
        f"{clean_service}_{clean_user}_{subkey}_{date_str}"
        if subkey
        else f"{clean_service}_{clean_user}_{date_str}"
    )

    if is_completed:
        record_daily_completed(clean_service, clean_user, date_str, subkey=subkey)
        return None

    if is_daily_completed(clean_service, clean_user, date_str, subkey=subkey):
        clear_pending_action(action_id)
        return None

    default_msg = f"Today's {title or clean_service.title()} ({date_str}) is waiting!"
    return record_pending_action(
        action_id=action_id,
        service_id=clean_service,
        user_id=clean_user,
        action_type="daily",
        title=title or clean_service.title(),
        subtitle=subtitle,
        message=message or default_msg,
        url=url,
        icon=icon,
    )


def sync_turn_pending_action(
    service_id: str,
    game_id: str,
    turn_user_id: str | None,
    *,
    is_active: bool = True,
    is_bot: bool = False,
    title: str | None = None,
    subtitle: str | None = None,
    message: str = "It's your turn!",
    url: str = "",
    icon: str = "🔴",
) -> dict[str, Any] | None:
    """Standardized turn-based pending action synchronization.

    If `is_active` is False, `turn_user_id` is None, or `is_bot` is True:
        Clears `{service_id}_{game_id}` from `pending_actions` and returns None.
    Otherwise:
        Records an active 'turn' pending action for `turn_user_id`.
    """
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    action_id = f"{clean_service}_{game_id}"

    if not is_active or not turn_user_id or is_bot:
        clear_pending_action(action_id)
        return None

    return record_pending_action(
        action_id=action_id,
        service_id=clean_service,
        user_id=turn_user_id,
        action_type="turn",
        title=title or clean_service.title(),
        subtitle=subtitle,
        message=message,
        url=url,
        icon=icon,
    )


def clear_turn_pending_action(service_id: str, game_id: str) -> bool:
    """Removes a turn pending action when a game is deleted, aborted, cancelled, or completed."""
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    action_id = f"{clean_service}_{game_id}"
    return clear_pending_action(action_id)


def clear_daily_pending_action(
    service_id: str,
    *,
    user_id: str | None = None,
    subkey: str | None = None,
    date_str: str | None = None,
) -> int:
    """Clears daily pending actions when a challenge, participant, or daily action is deleted or removed."""
    from ottomate_core.config import PENDING_ACTIONS_COLLECTION

    clean_service = service_id.strip().lower().replace("ottomate-", "")
    clean_user = normalize_email(user_id) if user_id else None

    # Case 1: Specific action id if all 3 are known
    if clean_user and subkey and date_str:
        action_id = f"{clean_service}_{clean_user}_{subkey}_{date_str}"
        return 1 if clear_pending_action(action_id) else 0

    # Case 2: Specific user daily action without subkey
    if clean_user and date_str and not subkey:
        action_id = f"{clean_service}_{clean_user}_{date_str}"
        return 1 if clear_pending_action(action_id) else 0

    # Case 3: Specific user with subkey (any date)
    if clean_user and subkey:
        prefix = f"{clean_service}_{clean_user}_{subkey}"
        return clear_service_pending_actions(clean_service, prefix=prefix)

    # Case 4: Specific user (all actions for this service)
    if clean_user and not subkey:
        prefix = f"{clean_service}_{clean_user}"
        return clear_service_pending_actions(clean_service, prefix=prefix)

    # Case 5: Subkey deleted across all users (e.g. challenge deleted)
    if subkey and not clean_user:
        deleted = 0
        try:
            db = users_database()
            docs = db.collection(PENDING_ACTIONS_COLLECTION).where("service_id", "==", clean_service).stream()
            sub_token = f"_{subkey}_"
            for doc in docs:
                if sub_token in doc.id or doc.id.endswith(f"_{subkey}"):
                    if hasattr(doc, "reference") and hasattr(doc.reference, "delete"):
                        doc.reference.delete()
                    else:
                        db.collection(PENDING_ACTIONS_COLLECTION).document(doc.id).delete()
                    deleted += 1
        except Exception as exc:
            logger.warning("Could not clear pending actions for subkey '%s': %s", subkey, exc)
        return deleted

    return 0


def clear_daily_completed(
    service_id: str,
    user_id: str,
    date_str: str,
    *,
    subkey: str | None = None,
) -> bool:
    """Reverses record_daily_completed (e.g. when a workout or daily log is deleted or undone)."""
    clean_service = service_id.strip().lower().replace("ottomate-", "")
    clean_user = normalize_email(user_id)
    uk = user_key(clean_user)

    try:
        db = users_database()
        doc_ref = db.collection(USERS_COLLECTION).document(uk)
        doc_snap = doc_ref.get()
        if not doc_snap.exists:
            return True
        existing = doc_snap.to_dict() or {}
        daily_completions = dict(existing.get("daily_completions") or {})
        service_data = dict(daily_completions.get(clean_service) or {})

        if subkey:
            items = dict(service_data.get("items") or {})
            if items.get(subkey) == date_str:
                items.pop(subkey, None)
                service_data["items"] = items
        else:
            dates = dict(service_data.get("dates") or {})
            dates.pop(date_str, None)
            service_data["dates"] = dates
            if service_data.get("last_date") == date_str:
                remaining = sorted(dates.keys())
                service_data["last_date"] = remaining[-1] if remaining else None

        daily_completions[clean_service] = service_data
        update_payload: dict[str, Any] = {"daily_completions": daily_completions}
        if clean_service == "pushups" and existing.get("last_result_date") == date_str:
            update_payload["last_result_date"] = None

        doc_ref.set(update_payload, merge=True)
        return True
    except Exception as exc:
        logger.warning(
            "Could not clear daily completion for service '%s', user '%s', date '%s': %s",
            clean_service,
            clean_user,
            date_str,
            exc,
        )
        return False

