"""Centralized Cloud Scheduler cron configuration, Firestore progress tracking, and output normalization."""

from __future__ import annotations

from datetime import datetime, timezone
import inspect
import logging
from typing import Any, Callable, Mapping

from ottomate_core.config import get_service_name
from ottomate_core.db import database
from ottomate_core.models import CronConfig, CronEvaluationResult, CronRefreshStatus

logger = logging.getLogger(__name__)

_cron_handler: Callable[..., Any] | None = None
_cron_config: CronConfig | None = None


def configure_cron(
    handler: Callable[..., Any] | None = None,
    config: CronConfig | Mapping[str, Any] | None = None,
) -> CronConfig | None:
    """Registers the service's centralized cron/refresh handler and configuration."""
    global _cron_handler, _cron_config
    _cron_handler = handler

    if config is not None:
        if isinstance(config, CronConfig):
            _cron_config = config
        elif isinstance(config, Mapping):
            _cron_config = CronConfig(**dict(config))
        else:
            _cron_config = CronConfig()
    elif handler is not None:
        _cron_config = _cron_config or CronConfig()
    else:
        _cron_config = None

    return _cron_config


def get_cron_config() -> CronConfig | None:
    """Returns the registered CronConfig for this service, or None if cron is not configured."""
    return _cron_config


def get_cron_handler() -> Callable[..., Any] | None:
    """Returns the registered cron execution callable, or None if unset."""
    return _cron_handler


def _resolve_config(config: CronConfig | Mapping[str, Any] | None = None) -> CronConfig:
    if isinstance(config, CronConfig):
        return config
    if isinstance(config, Mapping):
        return CronConfig(**dict(config))
    if _cron_config is not None:
        return _cron_config
    return CronConfig()


def normalize_cron_output(
    raw_result: Any,
    service_name: str = "",
    triggered_by: str = "system",
) -> dict[str, Any]:
    """Normalizes any cron handler return value into the canonical CronEvaluationResult dictionary."""
    now_iso = datetime.now(timezone.utc).isoformat()
    resolved_service = service_name or get_service_name() or "ottomate-service"

    if isinstance(raw_result, CronEvaluationResult):
        raw_dict = raw_result.to_dict()
    elif hasattr(raw_result, "model_dump"):
        raw_dict = raw_result.model_dump(mode="python")
    elif isinstance(raw_result, Mapping):
        raw_dict = dict(raw_result)
    else:
        raw_dict = {}

    details = raw_dict.get("details")
    if not isinstance(details, list):
        details = []

    evaluated_count = raw_dict.get("evaluated_count")
    evaluated_weeks_count = raw_dict.get("evaluated_weeks_count")

    if evaluated_count is None and evaluated_weeks_count is not None:
        evaluated_count = int(evaluated_weeks_count)
    elif evaluated_weeks_count is None and evaluated_count is not None:
        evaluated_weeks_count = int(evaluated_count)
    elif evaluated_count is None and evaluated_weeks_count is None:
        evaluated_count = len(details)
        evaluated_weeks_count = len(details)

    normalized = CronEvaluationResult(
        timestamp=str(raw_dict.get("timestamp") or now_iso),
        service=str(raw_dict.get("service") or resolved_service),
        triggered_by=str(raw_dict.get("triggered_by") or triggered_by),
        evaluated_count=int(evaluated_count or 0),
        evaluated_weeks_count=int(evaluated_weeks_count or 0),
        details=details,
        summary=raw_dict.get("summary"),
    ).to_dict()

    # Preserve any domain-specific extra fields (e.g. explicit_evaluation)
    for k, v in raw_dict.items():
        if k not in normalized:
            normalized[k] = v

    return normalized


def get_cron_refresh_status(
    config: CronConfig | Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Reads the shared Firestore refresh status document so all connected clients can display live progress."""
    cfg = _resolve_config(config)
    now = datetime.now(timezone.utc)
    default_state = CronRefreshStatus().to_dict()

    try:
        db = database()
        doc = db.collection(cfg.collection_name).document(cfg.document_id).get()
        if not doc.exists:
            return default_state

        data = doc.to_dict() or {}
        in_progress = bool(data.get("in_progress", False))
        started_at_str = data.get("started_at")
        completed_at_str = data.get("completed_at")
        elapsed_seconds = 0

        if started_at_str:
            try:
                started_dt = datetime.fromisoformat(str(started_at_str).replace("Z", "+00:00"))
                if in_progress:
                    elapsed_seconds = max(0, int((now - started_dt).total_seconds()))
                    if elapsed_seconds > cfg.stale_seconds:
                        in_progress = False
                elif completed_at_str:
                    completed_dt = datetime.fromisoformat(str(completed_at_str).replace("Z", "+00:00"))
                    elapsed_seconds = max(0, int((completed_dt - started_dt).total_seconds()))
            except Exception:
                pass

        return CronRefreshStatus(
            in_progress=in_progress,
            started_at=started_at_str,
            completed_at=completed_at_str,
            elapsed_seconds=elapsed_seconds,
            triggered_by=data.get("triggered_by"),
            challenge_id=data.get("challenge_id") or data.get("session_id"),
            session_id=data.get("session_id") or data.get("challenge_id"),
            week_number=data.get("week_number"),
            last_result=data.get("last_result"),
            error=data.get("error"),
        ).to_dict()
    except Exception as exc:
        logger.warning("Failed to read cron refresh status: %s", exc)
        return default_state


def try_acquire_cron_refresh_lock(
    *,
    triggered_by: str = "admin",
    challenge_id: str | None = None,
    session_id: str | None = None,
    week_number: int | None = None,
    config: CronConfig | Mapping[str, Any] | None = None,
) -> tuple[bool, dict[str, Any]]:
    """Atomically checks and acquires the Firestore cron refresh lock to prevent multi-instance TOCTOU races."""
    from ottomate_core.db import run_in_transaction

    cfg = _resolve_config(config)
    now = datetime.now(timezone.utc)
    now_iso = now.isoformat()
    resolved_session = challenge_id or session_id
    new_state = CronRefreshStatus(
        in_progress=True,
        started_at=now_iso,
        completed_at=None,
        elapsed_seconds=0,
        triggered_by=triggered_by,
        challenge_id=resolved_session,
        session_id=resolved_session,
        week_number=week_number,
        last_result=None,
        error=None,
    ).to_dict()

    try:
        db = database()
        doc_ref = db.collection(cfg.collection_name).document(cfg.document_id)

        def _tx_body(tx):
            snap = doc_ref.get(transaction=tx)
            if snap.exists:
                data = snap.to_dict() or {}
                if data.get("in_progress"):
                    started_str = data.get("started_at")
                    elapsed = 0
                    if started_str:
                        try:
                            started_dt = datetime.fromisoformat(str(started_str).replace("Z", "+00:00"))
                            elapsed = max(0, int((now - started_dt).total_seconds()))
                        except Exception:
                            elapsed = 0
                    if elapsed <= cfg.stale_seconds:
                        existing = CronRefreshStatus(
                            in_progress=True,
                            started_at=started_str,
                            completed_at=data.get("completed_at"),
                            elapsed_seconds=elapsed,
                            triggered_by=data.get("triggered_by"),
                            challenge_id=data.get("challenge_id") or data.get("session_id"),
                            session_id=data.get("session_id") or data.get("challenge_id"),
                            week_number=data.get("week_number"),
                            last_result=data.get("last_result"),
                            error=data.get("error"),
                        ).to_dict()
                        return False, existing
            tx.set(doc_ref, new_state)
            return True, new_state

        return run_in_transaction(db, _tx_body)
    except Exception as exc:
        logger.warning("Failed to acquire transactional cron refresh lock: %s", exc)
        return True, new_state


def start_cron_refresh_job(
    triggered_by: str = "admin",
    challenge_id: str | None = None,
    session_id: str | None = None,
    week_number: int | None = None,
    config: CronConfig | Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Marks a shared refresh/evaluation job as in_progress in Firestore so all users see the status bar."""
    _, state = try_acquire_cron_refresh_lock(
        triggered_by=triggered_by,
        challenge_id=challenge_id,
        session_id=session_id,
        week_number=week_number,
        config=config,
    )
    return state


def _invoke_handler(
    handler: Callable[..., Any],
    *,
    triggered_by: str,
    challenge_id: str | None,
    session_id: str | None,
    week_number: int | None,
) -> Any:
    """Invokes the registered cron handler, passing only parameters it accepts."""
    try:
        sig = inspect.signature(handler)
        params = sig.parameters
        accepts_var_kw = any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values())
        candidate_kwargs = {
            "triggered_by": triggered_by,
            "challenge_id": challenge_id or session_id,
            "session_id": session_id or challenge_id,
            "week_number": week_number,
        }
        if accepts_var_kw:
            return handler(**candidate_kwargs)
        filtered = {k: v for k, v in candidate_kwargs.items() if k in params}
        return handler(**filtered)
    except (ValueError, TypeError):
        return handler()


def execute_cron_refresh_job(
    handler: Callable[..., Any] | None = None,
    *,
    triggered_by: str = "system",
    challenge_id: str | None = None,
    session_id: str | None = None,
    week_number: int | None = None,
    service_name: str = "",
    config: CronConfig | Mapping[str, Any] | None = None,
    already_locked_started_at: str | None = None,
) -> dict[str, Any]:
    """Executes the registered cron handler, updates Firestore status, and returns canonical CronEvaluationResult."""
    cfg = _resolve_config(config)
    active_handler = handler or _cron_handler
    if active_handler is None:
        raise RuntimeError("No cron handler registered for this service.")

    resolved_session = challenge_id or session_id
    if already_locked_started_at:
        started_at = already_locked_started_at
    else:
        acquired, lock_state = try_acquire_cron_refresh_lock(
            triggered_by=triggered_by,
            challenge_id=resolved_session,
            session_id=resolved_session,
            week_number=week_number,
            config=cfg,
        )
        if not acquired:
            return normalize_cron_output(
                {"evaluated_count": 0, "skipped_reason": "already_in_progress", "details": []},
                service_name=service_name or get_service_name(),
                triggered_by=triggered_by,
            )
        started_at = lock_state.get("started_at") or datetime.now(timezone.utc).isoformat()

    try:
        raw_res = _invoke_handler(
            active_handler,
            triggered_by=triggered_by,
            challenge_id=resolved_session,
            session_id=resolved_session,
            week_number=week_number,
        )
        normalized = normalize_cron_output(
            raw_res,
            service_name=service_name or get_service_name(),
            triggered_by=triggered_by,
        )
        completed_iso = datetime.now(timezone.utc).isoformat()
        final_state = CronRefreshStatus(
            in_progress=False,
            started_at=started_at,
            completed_at=completed_iso,
            elapsed_seconds=0,
            triggered_by=triggered_by,
            challenge_id=resolved_session,
            session_id=resolved_session,
            week_number=week_number,
            last_result=normalized,
            error=None,
        ).to_dict()
        db = database()
        db.collection(cfg.collection_name).document(cfg.document_id).set(final_state)
        return normalized
    except Exception as exc:
        logger.error("Cron refresh job failed: %s", exc, exc_info=True)
        completed_iso = datetime.now(timezone.utc).isoformat()
        try:
            db = database()
            db.collection(cfg.collection_name).document(cfg.document_id).set(
                CronRefreshStatus(
                    in_progress=False,
                    started_at=started_at,
                    completed_at=completed_iso,
                    elapsed_seconds=0,
                    triggered_by=triggered_by,
                    challenge_id=resolved_session,
                    session_id=resolved_session,
                    week_number=week_number,
                    last_result=None,
                    error=str(exc),
                ).to_dict()
            )
        except Exception:
            pass
        raise

