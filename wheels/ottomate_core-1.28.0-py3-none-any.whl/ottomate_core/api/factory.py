from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

from fastapi import APIRouter, FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from ottomate_core.api.cron import create_cron_router
from ottomate_core.api.system import create_system_router, render_index_html
from ottomate_core.api.users import create_users_router
from ottomate_core.config import get_service_name
from ottomate_core.cron import configure_cron, get_cron_config, get_cron_handler
from ottomate_core.models import CronConfig


def create_core_router(service_name: str, service_version: str = "0.1.0") -> APIRouter:
    """Creates a unified router including system config, health checks, and user/profile/directory APIs."""
    router = APIRouter()
    router.include_router(create_system_router(service_version=service_version, service_name=service_name))
    router.include_router(create_users_router(service_name=service_name))
    return router


def add_security_headers_middleware(app: FastAPI) -> None:
    """Registers standard HTTP middleware to enforce COOP headers required for Google Identity Services popup auth."""

    @app.middleware("http")
    async def _add_security_headers(request, call_next):
        response = await call_next(request)
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin-allow-popups"
        return response


def create_ottomate_app(
    *,
    title: str,
    description: str = "",
    version: str = "0.1.0",
    service_name: str | None = None,
    static_dir: Path | str | None = None,
    index_file: Path | str | None = None,
    routers: Sequence[APIRouter] = (),
    cron_handler: Callable[..., Any] | None = None,
    cron_config: CronConfig | Mapping[str, Any] | None = None,
) -> FastAPI:
    """Creates a standardized Ottomate FastAPI application.

    Automatically registers:
    - COOP security headers middleware (`same-origin-allow-popups`)
    - Core system & user routers (`/api/config`, `/health`, `/healthz`, `/api/healthz`, `/api/me`, `/api/users`, `/core-static`)
    - Centralized Cloud Scheduler & Admin Refresh router (`/api/cron/status`, `/api/cron/trigger`, `/api/cron/run`) when `cron_handler` is registered
    - Service-specific routers passed in `routers`
    - `/static` directory mount and `/favicon.ico` route (when `static_dir` is provided)
    - `/` index route using `render_index_html(index_file, version)` with automatic `?v=<version>` cache-busting
    """
    resolved_service_name = service_name or get_service_name()
    if cron_handler is not None or cron_config is not None:
        configure_cron(handler=cron_handler or get_cron_handler(), config=cron_config or get_cron_config())

    app = FastAPI(
        title=title,
        description=description,
        version=version,
    )
    add_security_headers_middleware(app)
    app.include_router(create_core_router(service_name=resolved_service_name, service_version=version))

    has_custom_cron_router = any(getattr(r, "prefix", "") == "/api/cron" for r in routers)
    if get_cron_handler() is not None and not has_custom_cron_router:
        app.include_router(create_cron_router(service_name=resolved_service_name))

    for router in routers:
        app.include_router(router)

    if static_dir is not None:
        static_path = Path(static_dir)
        resolved_index = Path(index_file) if index_file is not None else (static_path / "index.html")
        favicon_ico = static_path / "favicon.ico"
        favicon_svg = static_path / "favicon.svg"

        app.mount("/static", StaticFiles(directory=str(static_path)), name="static")

        if favicon_ico.exists() or favicon_svg.exists():
            @app.get("/favicon.ico", include_in_schema=False)
            def favicon():
                if favicon_ico.exists():
                    return FileResponse(favicon_ico, media_type="image/x-icon")
                return FileResponse(favicon_svg, media_type="image/svg+xml")

        if resolved_index.exists():
            @app.get("/", include_in_schema=False)
            def index():
                return render_index_html(resolved_index, version)

    return app
