"""Centralized FastAPI router for Cloud Scheduler cron jobs and async admin refresh."""

from __future__ import annotations

import logging
import os
from typing import Any, Callable, Mapping

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from google.auth.transport import requests as google_requests
from google.oauth2 import id_token

from ottomate_core.auth import (
    User,
    _get_token_issuer,
    dev_mode_enabled,
    get_current_user,
    google_client_id,
    verify_bearer_token,
)
from ottomate_core.config import get_service_name
from ottomate_core.cron import (
    configure_cron,
    execute_cron_refresh_job,
    get_cron_config,
    get_cron_handler,
    get_cron_refresh_status,
    try_acquire_cron_refresh_lock,
)
from ottomate_core.db import database, normalize_email
from ottomate_core.deps import is_admin_user, is_game_admin, is_session_admin, is_super_admin
from ottomate_core.models import CronConfig, CronTriggerRequest

logger = logging.getLogger(__name__)
optional_bearer = HTTPBearer(auto_error=False)


def allowed_scheduler_service_accounts(service_name: str = "") -> set[str]:
    """Returns the set of GCP service account emails allowed to invoke Cloud Scheduler cron endpoints."""
    project_id = os.environ.get("GOOGLE_CLOUD_PROJECT", "ottomate-gaming-platform").strip()
    resolved_service = (service_name or get_service_name() or "ottomate-service").removeprefix("ottomate-")
    custom_sa = os.environ.get("CRON_SERVICE_ACCOUNT_EMAIL", "").strip().lower()
    accounts = {
        f"ottomate-{resolved_service}@{project_id}.iam.gserviceaccount.com".lower(),
        f"{project_id}@appspot.gserviceaccount.com".lower(),
    }
    if custom_sa:
        accounts.add(custom_sa)
    return accounts


def _expected_scheduler_audiences(request: Request | None) -> set[str]:
    """Determines valid OIDC audiences for Cloud Scheduler requests."""
    audiences: set[str] = set()
    configured = os.environ.get("CRON_OIDC_AUDIENCE", "").strip()
    if configured:
        for item in configured.split(","):
            clean = item.strip().rstrip("/")
            if clean:
                audiences.add(clean)
        return audiences

    if request is not None:
        host = (request.headers.get("x-forwarded-host") or request.headers.get("host") or "").split(",")[0].strip()
        bare_host = host.split(":")[0].lower()
        if bare_host and bare_host not in ("testserver", "localhost", "127.0.0.1"):
            audiences.add(f"https://{host}".rstrip("/"))
    return audiences


def _matches_scheduler_audience(claims_aud: Any, expected_audiences: set[str]) -> bool:
    if not expected_audiences:
        return True
    if isinstance(claims_aud, str):
        aud_list = [claims_aud]
    elif isinstance(claims_aud, (list, tuple, set)):
        aud_list = [str(a) for a in claims_aud]
    else:
        return False

    for raw_aud in aud_list:
        norm_aud = raw_aud.strip().rstrip("/")
        for exp in expected_audiences:
            if norm_aud == exp or norm_aud.startswith(f"{exp}/"):
                return True
    return False


def verify_scheduler_or_admin(
    request: Request = None,  # type: ignore[assignment]
    credentials: HTTPAuthorizationCredentials | None = Depends(optional_bearer),
) -> str:
    """Verifies that a cron request comes from an authorized Cloud Scheduler SA (OIDC) or an Ottomate Admin."""
    is_unconfigured_pytest = (
        "PYTEST_CURRENT_TEST" in os.environ
        and not google_client_id()
        and not os.environ.get("CRON_REQUIRE_AUTH")
        and not (credentials and credentials.credentials)
    )
    if dev_mode_enabled():
        if credentials and credentials.credentials and credentials.credentials.startswith("dev:"):
            return credentials.credentials.split("dev:", 1)[1] or "dev-scheduler"
        return "cloud-scheduler"

    if is_unconfigured_pytest:
        return "cloud-scheduler"

    if not credentials or not credentials.credentials:
        raise HTTPException(
            status_code=401,
            detail="Missing Authorization Bearer token (expected Cloud Scheduler OIDC token or Admin token).",
        )

    token = credentials.credentials
    service_name = get_service_name()
    iss = _get_token_issuer(token)

    # 1. Check Cloud Scheduler OIDC token (issued by Google OAuth2 for the project's service account)
    if not iss.startswith("https://securetoken.google.com/"):
        oidc_exc: Exception | None = None
        claims: dict[str, Any] | None = None
        configured_aud = os.environ.get("CRON_OIDC_AUDIENCE", "").strip()
        single_aud = configured_aud.rstrip("/") if configured_aud and "," not in configured_aud else None
        try:
            claims = id_token.verify_oauth2_token(token, google_requests.Request(), audience=single_aud)
        except Exception as exc:
            oidc_exc = exc

        if claims is not None:
            email = normalize_email(claims.get("email", ""))
            if not email or not claims.get("email_verified", False):
                raise HTTPException(status_code=401, detail="OIDC token missing verified email claim.")

            if email in allowed_scheduler_service_accounts(service_name):
                expected_audiences = _expected_scheduler_audiences(request)
                if not _matches_scheduler_audience(claims.get("aud"), expected_audiences):
                    raise HTTPException(
                        status_code=401,
                        detail="OIDC token audience does not match this Cloud Run service.",
                    )
                return email

            # Reject unauthorized GCP service accounts immediately (no cross-project .gserviceaccount.com wildcard!)
            if email.endswith(".gserviceaccount.com"):
                raise HTTPException(
                    status_code=403,
                    detail="Service account is not authorized to invoke cron for this service.",
                )

        # If token wasn't a Scheduler SA token, fall through to strict Admin user token check below
        # (which enforces GOOGLE_CLIENT_ID audience for OAuth tokens or FIREBASE_PROJECT_ID for Firebase tokens).
        if claims is None and not google_client_id() and oidc_exc is not None:
            raise HTTPException(status_code=401, detail=f"Invalid OIDC token: {oidc_exc}") from oidc_exc

    # 2. Verify interactive Admin token (supports both Google OAuth2 and Firebase Auth Email Link tokens)
    user = verify_bearer_token(token)
    cfg = get_cron_config()
    session_cols = tuple(cfg.session_collections) if cfg and cfg.session_collections else ("challenges", "games")
    if is_admin_user(user, service_name=service_name, session_collections=session_cols):
        return user.email

    raise HTTPException(
        status_code=403,
        detail="Caller is neither the authorized Cloud Scheduler service account nor an Ottomate Admin.",
    )


def _check_session_or_service_admin(
    user: User,
    service_name: str,
    target_session_id: str | None,
    session_collections: tuple[str, ...],
) -> None:
    if is_super_admin(user) or is_game_admin(user, service_name):
        return

    if target_session_id:
        db = database()
        for col in session_collections:
            try:
                snap = db.collection(col).document(target_session_id).get()
                if snap.exists:
                    if is_session_admin(user, snap.to_dict() or {}, service_name=service_name):
                        return
                    raise HTTPException(
                        status_code=403,
                        detail="Only Super Admins, Game Admins, or Session/Challenge Admins can trigger refresh.",
                    )
            except HTTPException:
                raise
            except Exception:
                continue

    if is_admin_user(user, service_name=service_name, session_collections=session_collections):
        return

    raise HTTPException(
        status_code=403,
        detail="Only Super Admins, Game Admins, or Session/Challenge Admins can trigger refresh.",
    )


def create_cron_router(
    service_name: str | None = None,
    handler: Callable[..., Any] | None = None,
    config: CronConfig | Mapping[str, Any] | None = None,
) -> APIRouter:
    """Creates a standardized `/api/cron` router for Cloud Scheduler jobs and async UI admin triggers."""
    if handler is not None or config is not None:
        configure_cron(handler=handler or get_cron_handler(), config=config or get_cron_config())

    cfg = get_cron_config() or CronConfig()
    resolved_service = service_name or get_service_name() or "ottomate-service"
    session_cols = tuple(cfg.session_collections or ["challenges", "games"])

    router = APIRouter(prefix="/api/cron", tags=["cron"])

    @router.get("/status")
    def get_status(
        credentials: HTTPAuthorizationCredentials | None = Depends(optional_bearer),
    ) -> dict[str, Any]:
        """Public status endpoint polled by clients to display the live 'Refresh in progress' bar with elapsed time."""
        st = dict(get_cron_refresh_status(cfg))
        is_trusted = False
        if credentials and credentials.credentials:
            try:
                u = verify_bearer_token(credentials.credentials)
                is_trusted = is_admin_user(u, service_name=resolved_service, session_collections=session_cols)
            except Exception:
                is_trusted = False
        if not is_trusted:
            trig = st.get("triggered_by")
            if isinstance(trig, str) and "@" in trig:
                st["triggered_by"] = "scheduler" if trig.endswith(".gserviceaccount.com") else "admin"
            if st.get("error"):
                st["error"] = "Refresh failed. Check server logs."
        return st

    @router.post("/trigger")
    def trigger_refresh(
        payload: CronTriggerRequest | None = None,
        challenge_id: str | None = Query(default=None),
        session_id: str | None = Query(default=None),
        week_number: int | None = Query(default=None),
        user: User = Depends(get_current_user),
    ) -> dict[str, Any]:
        """Authenticated Admin endpoint to trigger a refresh & evaluation job.

        Executes synchronously within the active HTTP request so Cloud Run (`cpu_idle = true`)
        keeps full vCPU allocated until Firestore status updates complete, while writing
        `in_progress = True` atomically upfront so concurrent viewers see live elapsed progress.
        """
        target_session = (
            (payload.challenge_id if payload and payload.challenge_id else None)
            or (payload.session_id if payload and payload.session_id else None)
            or challenge_id
            or session_id
        )
        target_week = (payload.week_number if payload and payload.week_number is not None else None) or week_number

        _check_session_or_service_admin(user, resolved_service, target_session, session_cols)

        acquired, lock_state = try_acquire_cron_refresh_lock(
            triggered_by=user.email,
            challenge_id=target_session,
            session_id=target_session,
            week_number=target_week,
            config=cfg,
        )
        if not acquired:
            return lock_state

        execute_cron_refresh_job(
            handler=handler or get_cron_handler(),
            triggered_by=user.email,
            challenge_id=target_session,
            session_id=target_session,
            week_number=target_week,
            service_name=resolved_service,
            config=cfg,
            already_locked_started_at=lock_state.get("started_at"),
        )
        return get_cron_refresh_status(cfg)

    def _run_scheduled_cron(caller: str = Depends(verify_scheduler_or_admin)) -> dict[str, Any]:
        """Automated Cloud Scheduler target: executes the registered cron handler idempotently."""
        return execute_cron_refresh_job(
            handler=handler or get_cron_handler(),
            triggered_by=caller,
            service_name=resolved_service,
            config=cfg,
        )

    # Canonical endpoint: POST /api/cron/run
    router.add_api_route("/run", _run_scheduled_cron, methods=["POST"], name="cron_run")

    # Register configured custom endpoint / aliases (e.g. /api/cron/evaluate-week)
    extra_paths: list[str] = []
    if cfg.endpoint and cfg.endpoint != "/api/cron/run":
        extra_paths.append(cfg.endpoint)
    for alias in cfg.alias_endpoints:
        if alias and alias not in extra_paths and alias != "/api/cron/run":
            extra_paths.append(alias)

    for raw_path in extra_paths:
        rel_path = raw_path.removeprefix("/api/cron")
        if not rel_path.startswith("/"):
            rel_path = f"/{rel_path}"
        if rel_path != "/run":
            router.add_api_route(rel_path, _run_scheduled_cron, methods=["POST"])

    return router

