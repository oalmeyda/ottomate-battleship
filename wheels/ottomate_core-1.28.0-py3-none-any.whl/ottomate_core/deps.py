"""3-tier RBAC authorization guards shared by all Ottomate services.

Tiers: Super Admin (platform-wide) > Game Admin (per service) > Session Admin
(per challenge/game). Failures to reach Firestore are logged and fail closed.
"""

import logging
from typing import Iterable

from ottomate_core import auth
from ottomate_core import db as db_module
from ottomate_core.auth import User
from ottomate_core.config import USERS_COLLECTION, get_service_name
from fastapi import Depends, HTTPException

logger = logging.getLogger(__name__)

GAME_ADMIN_ROLES = ("game_admin", "admin")
SESSION_ADMIN_MEMBERSHIP_ROLES = ("organizer", "admin")


def service_role_keys(service_name: str) -> tuple[str, ...]:
    """Returns both raw and 'ottomate-' prefixed keys for a service name (e.g. ('poker', 'ottomate-poker'))."""
    if not service_name:
        return ()
    bare = service_name.removeprefix("ottomate-")
    if not bare:
        return (service_name,)
    return (bare, f"ottomate-{bare}")


def _load_user_doc(user: User) -> dict:
    """Returns the user's Firestore document (or `{}`), failing closed on errors."""
    try:
        db = db_module.users_database()
        snap = db.collection(USERS_COLLECTION).document(db_module.user_key(user.email)).get()
        if snap.exists and snap.to_dict():
            return snap.to_dict()
    except Exception:
        logger.warning("Failed to load user document for RBAC check (%s)", user.email, exc_info=True)
    return {}


def is_super_admin(user: User) -> bool:
    """Checks whether the user is a platform-wide Super Admin ('Admin of Admins')."""
    if user.email in auth.organizer_emails():
        return True
    return _load_user_doc(user).get("system_role") == "super_admin"


def is_game_admin(user: User, service_name: str | None = None) -> bool:
    """Checks whether the user is a Game Admin for `service_name` or a Super Admin.

    Accepts service_name in both raw and 'ottomate-' prefixed forms (e.g. 'poker' or 'ottomate-poker').
    Defaults to `get_service_name()` when `service_name` is omitted.
    This is a single role lookup on the user's document; it never scans game or
    challenge collections.
    """
    resolved_service = service_name or get_service_name()
    if user.email in auth.organizer_emails():
        return True
    data = _load_user_doc(user)
    if data.get("system_role") == "super_admin":
        return True
    roles = data.get("roles", {})
    return any(roles.get(k) in GAME_ADMIN_ROLES for k in service_role_keys(resolved_service))


def is_admin(user: User, service_name: str | None = None) -> bool:
    """Super Admin or Game Admin for `service_name` (defaults to the `configure_service()` name)."""
    return is_game_admin(user, service_name or get_service_name())


def get_authenticated_user(current_user: User = Depends(auth.get_current_user)) -> User:
    """FastAPI dependency ensuring the caller is signed in."""
    if not current_user:
        raise HTTPException(status_code=401, detail="Authentication required.")
    return current_user


def require_admin_user(current_user: User = Depends(get_authenticated_user)) -> User:
    """FastAPI dependency ensuring the caller is a Super Admin or Game Admin for the configured service."""
    if not is_admin(current_user):
        raise HTTPException(status_code=403, detail="Admin permissions required.")
    return current_user


def resolve_acting_target(
    user: User,
    requested_email: str | None,
    service_name: str | None = None,
    action: str = "act",
) -> str:
    """Resolves the normalized email a request acts on behalf of.

    Returns the caller's own email when `requested_email` is empty or the caller's. Otherwise the caller
    must be an admin for the service or an authorized proxy of the target; else raises HTTP 403.
    """
    actor = db_module.normalize_email(user.email)
    if not requested_email:
        return actor
    target = db_module.normalize_email(requested_email)
    if target == actor:
        return actor
    if not is_admin(user, service_name) and not can_act_as_proxy(actor, target):
        raise HTTPException(
            status_code=403,
            detail=f"You do not have proxy permission to {action} on behalf of {target}.",
        )
    return target


def _owns_or_administers_session(db, collection: str, email: str) -> bool:
    """True if `email` created or co-administers at least one doc in `collection` (indexed queries)."""
    for field, op in (("created_by", "=="), ("admins", "array_contains")):
        query = db.collection(collection).where(field, op, email)
        if hasattr(query, "limit"):
            query = query.limit(1)
        for _ in query.stream():
            return True
    return False


def is_admin_user(
    user: User,
    service_name: str = "",
    session_collections: Iterable[str] = (),
) -> bool:
    """Checks whether the user is an admin of any kind.

    Super Admin, Game Admin (for `service_name`, or for any service when empty),
    or Session Admin of at least one document in the given `session_collections`.
    """
    if is_super_admin(user):
        return True
    roles = _load_user_doc(user).get("roles", {})
    if service_name:
        if any(roles.get(k) in GAME_ADMIN_ROLES for k in service_role_keys(service_name)):
            return True
    elif any(role in GAME_ADMIN_ROLES for role in roles.values()):
        return True
    collections = tuple(session_collections)
    if collections:
        try:
            db = db_module.database()
            return any(_owns_or_administers_session(db, col, user.email) for col in collections)
        except Exception:
            logger.warning("Failed to check session admin membership (%s)", user.email, exc_info=True)
    return False


def is_session_admin(
    user: User,
    session_data: dict,
    service_name: str = "",
    membership: dict | None = None,
) -> bool:
    """Checks whether the user administers an individual challenge/game session.

    True for Game Admins of `service_name`, the session creator, anyone in the
    session's `admins` list, or a member whose `membership["role"]` is
    `organizer`/`admin` (pass the user's membership document when available).
    """
    if service_name and is_game_admin(user, service_name):
        return True
    creator = session_data.get("created_by") or session_data.get("creator_id")
    if creator == user.email:
        return True
    admins = session_data.get("admins") or session_data.get("session_admins") or []
    if user.email in admins:
        return True
    return bool(membership) and membership.get("role") in SESSION_ADMIN_MEMBERSHIP_ROLES


def can_act_as_proxy(actor_email: str, target_email: str, db=None) -> bool:
    """Checks whether actor_email is authorized to act on behalf of target_email.

    Returns True if:
    - actor_email and target_email are the same user, or
    - actor_email is listed in target_email's authorized proxies list.
    """
    if not actor_email or not target_email:
        return False
    norm_actor = db_module.normalize_email(actor_email)
    norm_target = db_module.normalize_email(target_email)
    if norm_actor == norm_target:
        return True
    try:
        if db is None:
            db = db_module.users_database()
        target_snap = db.collection(USERS_COLLECTION).document(db_module.user_key(norm_target)).get()
        if target_snap.exists and target_snap.to_dict():
            data = target_snap.to_dict()
            proxies = [db_module.normalize_email(p) for p in data.get("proxies", []) if isinstance(p, str)]
            return norm_actor in proxies
    except Exception:
        logger.warning("Failed to evaluate proxy authorization (%s -> %s)", norm_actor, norm_target, exc_info=True)
    return False
