"""Poker engine primitives, hand evaluation, pot-limit betting, and side-pot resolution."""

from __future__ import annotations

from enum import Enum, IntEnum
import itertools
from typing import Any, Mapping, Sequence

from pydantic import ConfigDict, Field

from ottomate_core.card_engine.cards import (
    RANK_LABELS,
    RANK_NAMES,
    Card,
)
from ottomate_core.models import DictCompatibleModel


class HandRank(IntEnum):
    """Canonical 10-tier poker hand classification."""

    HIGH_CARD = 1
    ONE_PAIR = 2
    TWO_PAIR = 3
    THREE_OF_A_KIND = 4
    STRAIGHT = 5
    FLUSH = 6
    FULL_HOUSE = 7
    FOUR_OF_A_KIND = 8
    STRAIGHT_FLUSH = 9
    ROYAL_FLUSH = 10


HAND_RANK_NAMES: dict[HandRank, str] = {
    HandRank.HIGH_CARD: "High Card",
    HandRank.ONE_PAIR: "One Pair",
    HandRank.TWO_PAIR: "Two Pair",
    HandRank.THREE_OF_A_KIND: "Three of a Kind",
    HandRank.STRAIGHT: "Straight",
    HandRank.FLUSH: "Flush",
    HandRank.FULL_HOUSE: "Full House",
    HandRank.FOUR_OF_A_KIND: "Four of a Kind",
    HandRank.STRAIGHT_FLUSH: "Straight Flush",
    HandRank.ROYAL_FLUSH: "Royal Flush",
}


class PokerVariant(str, Enum):
    """Supported Dealer's Choice poker variants."""

    TEXAS_HOLDEM = "texas_holdem"
    FIVE_CARD_STUD = "five_card_stud"
    OMAHA = "omaha"
    SEVEN_CARD_STUD = "seven_card_stud"
    FIVE_CARD_DRAW = "five_card_draw"
    ELEVATOR = "elevator"


class BetAction(str, Enum):
    """Standard poker betting actions."""

    CHECK = "check"
    CALL = "call"
    BET = "bet"
    RAISE = "raise"
    ALL_IN = "all_in"
    FOLD = "fold"


class PokerHandResult(DictCompatibleModel):
    """Immutable evaluation result of a 5-card poker hand with strict score tuple."""

    model_config = ConfigDict(frozen=True, extra="allow")

    rank: HandRank
    rank_name: str
    score_tuple: tuple[int, ...]
    best_cards: list[Card]
    description: str

    def __lt__(self, other: Any) -> bool:
        if not isinstance(other, PokerHandResult):
            return NotImplemented
        return self.score_tuple < other.score_tuple

    def __le__(self, other: Any) -> bool:
        if not isinstance(other, PokerHandResult):
            return NotImplemented
        return self.score_tuple <= other.score_tuple

    def __gt__(self, other: Any) -> bool:
        if not isinstance(other, PokerHandResult):
            return NotImplemented
        return self.score_tuple > other.score_tuple

    def __ge__(self, other: Any) -> bool:
        if not isinstance(other, PokerHandResult):
            return NotImplemented
        return self.score_tuple >= other.score_tuple

    def __eq__(self, other: Any) -> bool:
        if not isinstance(other, PokerHandResult):
            return NotImplemented
        return self.score_tuple == other.score_tuple


class SidePot(DictCompatibleModel):
    """Calculated pot segment with eligible contenders and winner payouts."""

    model_config = ConfigDict(extra="allow")

    pot_index: int = 0
    amount: int
    eligible_players: list[str] = Field(default_factory=list)
    winners: list[str] = Field(default_factory=list)
    payout_per_winner: int = 0
    remainder_chips: int = 0


def _ensure_card(c: Any) -> Card:
    """Coerces dicts, tuples, or Card objects into strongly-typed Card."""
    if isinstance(c, Card):
        return c
    if isinstance(c, Mapping):
        return Card.create(rank=int(c["rank"]), suit=str(c["suit"]))
    if isinstance(c, (list, tuple)) and len(c) >= 2:
        return Card.create(rank=int(c[0]), suit=str(c[1]))
    raise ValueError(f"Cannot coerce {c!r} into a Card")


def evaluate_5card_hand(cards: Sequence[Card | Mapping[str, Any]]) -> PokerHandResult:
    """Evaluates an exact 5-card poker hand and assigns its rank and lexicographical score tuple."""
    if len(cards) != 5:
        raise ValueError(f"evaluate_5card_hand requires exactly 5 cards, received {len(cards)}")

    card_objs = [_ensure_card(c) for c in cards]
    # Sort descending by rank
    card_objs.sort(key=lambda c: c.rank, reverse=True)

    ranks = [c.rank for c in card_objs]
    suits = [c.suit for c in card_objs]

    is_flush = len(set(suits)) == 1

    # Check straight
    is_straight = False
    straight_high = 0
    is_wheel = False

    unique_ranks = sorted(set(ranks), reverse=True)
    if len(unique_ranks) == 5:
        if unique_ranks[0] - unique_ranks[4] == 4:
            is_straight = True
            straight_high = unique_ranks[0]
        elif unique_ranks == [14, 5, 4, 3, 2]:
            is_straight = True
            straight_high = 5
            is_wheel = True

    # Count rank frequencies
    rank_counts: dict[int, int] = {}
    for r in ranks:
        rank_counts[r] = rank_counts.get(r, 0) + 1

    # Sort frequencies descending: primary count desc, then rank desc
    freq_items = sorted(rank_counts.items(), key=lambda item: (item[1], item[0]), reverse=True)
    counts = [item[1] for item in freq_items]
    freq_ranks = [item[0] for item in freq_items]

    # Reorder cards according to frequency groups for best_cards representation
    ordered_cards = sorted(
        card_objs,
        key=lambda c: (rank_counts[c.rank], 1 if is_wheel and c.rank == 14 else c.rank),
        reverse=True,
    )

    # 10. Royal Flush & 9. Straight Flush
    if is_flush and is_straight:
        if straight_high == 14 and not is_wheel:
            suit_name = card_objs[0].suit_name
            return PokerHandResult(
                rank=HandRank.ROYAL_FLUSH,
                rank_name=HAND_RANK_NAMES[HandRank.ROYAL_FLUSH],
                score_tuple=(int(HandRank.ROYAL_FLUSH), 14),
                best_cards=ordered_cards,
                description=f"Royal Flush in {suit_name}",
            )
        desc = "5-High Straight Flush (Wheel)" if is_wheel else f"{RANK_LABELS[straight_high]}-High Straight Flush"
        return PokerHandResult(
            rank=HandRank.STRAIGHT_FLUSH,
            rank_name=HAND_RANK_NAMES[HandRank.STRAIGHT_FLUSH],
            score_tuple=(int(HandRank.STRAIGHT_FLUSH), straight_high),
            best_cards=ordered_cards,
            description=f"{desc} in {card_objs[0].suit_name}",
        )

    # 8. Four of a Kind
    if counts == [4, 1]:
        quad_rank = freq_ranks[0]
        kicker = freq_ranks[1]
        return PokerHandResult(
            rank=HandRank.FOUR_OF_A_KIND,
            rank_name=HAND_RANK_NAMES[HandRank.FOUR_OF_A_KIND],
            score_tuple=(int(HandRank.FOUR_OF_A_KIND), quad_rank, kicker),
            best_cards=ordered_cards,
            description=f"Four of a Kind, {RANK_NAMES[quad_rank]}s",
        )

    # 7. Full House
    if counts == [3, 2]:
        trip_rank = freq_ranks[0]
        pair_rank = freq_ranks[1]
        return PokerHandResult(
            rank=HandRank.FULL_HOUSE,
            rank_name=HAND_RANK_NAMES[HandRank.FULL_HOUSE],
            score_tuple=(int(HandRank.FULL_HOUSE), trip_rank, pair_rank),
            best_cards=ordered_cards,
            description=f"Full House, {RANK_NAMES[trip_rank]}s full of {RANK_NAMES[pair_rank]}s",
        )

    # 6. Flush
    if is_flush:
        return PokerHandResult(
            rank=HandRank.FLUSH,
            rank_name=HAND_RANK_NAMES[HandRank.FLUSH],
            score_tuple=(int(HandRank.FLUSH), *ranks),
            best_cards=ordered_cards,
            description=f"Flush, {RANK_LABELS[ranks[0]]}-High in {card_objs[0].suit_name}",
        )

    # 5. Straight
    if is_straight:
        desc = "5-High Straight (Wheel)" if is_wheel else f"{RANK_LABELS[straight_high]}-High Straight"
        return PokerHandResult(
            rank=HandRank.STRAIGHT,
            rank_name=HAND_RANK_NAMES[HandRank.STRAIGHT],
            score_tuple=(int(HandRank.STRAIGHT), straight_high),
            best_cards=ordered_cards,
            description=desc,
        )

    # 4. Three of a Kind
    if counts == [3, 1, 1]:
        trip_rank = freq_ranks[0]
        kickers = freq_ranks[1:]
        return PokerHandResult(
            rank=HandRank.THREE_OF_A_KIND,
            rank_name=HAND_RANK_NAMES[HandRank.THREE_OF_A_KIND],
            score_tuple=(int(HandRank.THREE_OF_A_KIND), trip_rank, *kickers),
            best_cards=ordered_cards,
            description=f"Three of a Kind, {RANK_NAMES[trip_rank]}s",
        )

    # 3. Two Pair
    if counts == [2, 2, 1]:
        high_pair = max(freq_ranks[0], freq_ranks[1])
        low_pair = min(freq_ranks[0], freq_ranks[1])
        kicker = freq_ranks[2]
        return PokerHandResult(
            rank=HandRank.TWO_PAIR,
            rank_name=HAND_RANK_NAMES[HandRank.TWO_PAIR],
            score_tuple=(int(HandRank.TWO_PAIR), high_pair, low_pair, kicker),
            best_cards=ordered_cards,
            description=f"Two Pair, {RANK_NAMES[high_pair]}s and {RANK_NAMES[low_pair]}s",
        )

    # 2. One Pair
    if counts == [2, 1, 1, 1]:
        pair_rank = freq_ranks[0]
        kickers = freq_ranks[1:]
        return PokerHandResult(
            rank=HandRank.ONE_PAIR,
            rank_name=HAND_RANK_NAMES[HandRank.ONE_PAIR],
            score_tuple=(int(HandRank.ONE_PAIR), pair_rank, *kickers),
            best_cards=ordered_cards,
            description=f"Pair of {RANK_NAMES[pair_rank]}s",
        )

    # 1. High Card
    return PokerHandResult(
        rank=HandRank.HIGH_CARD,
        rank_name=HAND_RANK_NAMES[HandRank.HIGH_CARD],
        score_tuple=(int(HandRank.HIGH_CARD), *ranks),
        best_cards=ordered_cards,
        description=f"High Card {RANK_NAMES[ranks[0]]}",
    )


def evaluate_best_poker_hand(cards: Sequence[Card | Mapping[str, Any]]) -> PokerHandResult:
    """Evaluates N cards (where N >= 5) and selects the maximal 5-card combination."""
    if len(cards) < 5:
        raise ValueError(f"evaluate_best_poker_hand requires at least 5 cards, received {len(cards)}")
    if len(cards) == 5:
        return evaluate_5card_hand(cards)

    combos = itertools.combinations(cards, 5)
    best_hand: PokerHandResult | None = None
    for combo in combos:
        evaluated = evaluate_5card_hand(combo)
        if best_hand is None or evaluated > best_hand:
            best_hand = evaluated

    assert best_hand is not None
    return best_hand


def evaluate_7card_hand(cards: Sequence[Card | Mapping[str, Any]]) -> PokerHandResult:
    """Alias for evaluate_best_poker_hand with exactly 7 cards (standard Texas Hold'em or 7 Card Stud)."""
    if len(cards) != 7:
        raise ValueError(f"evaluate_7card_hand requires exactly 7 cards, received {len(cards)}")
    return evaluate_best_poker_hand(cards)


def evaluate_omaha_hand(
    hole_cards: Sequence[Card | Mapping[str, Any]],
    board_cards: Sequence[Card | Mapping[str, Any]],
) -> PokerHandResult:
    """Evaluates an Omaha poker hand according to the strict canonical rule:
    Must use EXACTLY 2 cards from hole_cards and EXACTLY 3 cards from board_cards.
    """
    if len(hole_cards) < 4:
        raise ValueError(f"Omaha requires at least 4 hole cards, received {len(hole_cards)}")
    if len(board_cards) != 5:
        raise ValueError(f"Omaha requires exactly 5 community board cards, received {len(board_cards)}")

    hole_combos = list(itertools.combinations(hole_cards, 2))
    board_combos = list(itertools.combinations(board_cards, 3))

    best_hand: PokerHandResult | None = None
    for h_pair in hole_combos:
        for b_triplet in board_combos:
            candidate = list(h_pair) + list(b_triplet)
            evaluated = evaluate_5card_hand(candidate)
            if best_hand is None or evaluated > best_hand:
                best_hand = evaluated

    assert best_hand is not None
    return best_hand


def evaluate_elevator_hand(
    hole_cards: Sequence[Card | Mapping[str, Any]],
    left_column: Sequence[Card | Mapping[str, Any]],
    elevator_card: Card | Mapping[str, Any],
    right_column: Sequence[Card | Mapping[str, Any]],
) -> tuple[PokerHandResult, int]:
    """Evaluates an Elevator Poker hand.

    Layout:
    The 7 community cards form an 'H' shape with 3 floors:
    - Floor 1 (bottom): left_column[0], elevator_card, right_column[0]
    - Floor 2 (middle): left_column[1], elevator_card, right_column[1]
    - Floor 3 (top): left_column[2], elevator_card, right_column[2]

    To make their 5-card hand, each player uses their hole cards plus the 3 horizontal
    cards across a single floor line of their choice (the elevator card connects to that floor).

    Returns:
        (best_hand_result, chosen_floor_1_indexed)
    """
    if len(left_column) < 3 or len(right_column) < 3:
        raise ValueError("Elevator poker requires 3 cards in left column and 3 cards in right column")

    best_hand: PokerHandResult | None = None
    best_floor: int = 1

    for floor_idx in range(3):
        floor_cards = [left_column[floor_idx], elevator_card, right_column[floor_idx]]
        combined = list(hole_cards) + floor_cards
        if len(combined) == 5:
            evaluated = evaluate_5card_hand(combined)
        else:
            evaluated = evaluate_best_poker_hand(combined)

        if best_hand is None or evaluated > best_hand:
            best_hand = evaluated
            best_floor = floor_idx + 1

    assert best_hand is not None
    return best_hand, best_floor


def compare_hands(hand_a: PokerHandResult, hand_b: PokerHandResult) -> int:
    """Compares two hands: returns 1 if A > B, -1 if A < B, and 0 if tied."""
    if hand_a.score_tuple > hand_b.score_tuple:
        return 1
    if hand_a.score_tuple < hand_b.score_tuple:
        return -1
    return 0


def determine_winners(player_hands: Mapping[str, PokerHandResult]) -> list[str]:
    """Given a mapping of player_id -> PokerHandResult, returns list of winning player IDs."""
    if not player_hands:
        return []
    best_score = max(h.score_tuple for h in player_hands.values())
    return [p for p, h in player_hands.items() if h.score_tuple == best_score]


def calculate_pot_limit_raise(
    current_pot: int,
    current_table_bet: int,
    player_current_bet: int,
) -> int:
    """Calculates maximum committed total bet allowed under Pot-Limit rules.

    Under Pot-Limit rules:
    - Amount to call = current_table_bet - player_current_bet
    - Pot after calling = current_pot + Amount to call
    - Max raise size = Pot after calling
    - Total maximum bet = current_table_bet + Max raise size
    """
    call_amount = max(0, current_table_bet - player_current_bet)
    pot_after_call = current_pot + call_amount
    return current_table_bet + pot_after_call


def resolve_pots(
    contributions: Mapping[str, int],
    active_players: Sequence[str],
    showdown_hands: Mapping[str, PokerHandResult],
) -> list[SidePot]:
    """Calculates main pot and side pots for all-in situations and distributes payouts.

    Args:
        contributions: Total chips put into the hand by each player (folded or active).
        active_players: Players who have not folded and remain eligible for pots.
        showdown_hands: PokerHandResult for each active player reaching showdown.

    Returns:
        List of SidePot objects ordered from Main Pot (index 0) to outermost side pot.
    """
    active_set = set(active_players)
    if not contributions:
        return []

    # Get all unique positive contribution levels from all participating players
    levels = sorted({amt for amt in contributions.values() if amt > 0})
    if not levels:
        return []

    pots: list[SidePot] = []
    prev_level = 0

    for idx, level in enumerate(levels):
        tier_diff = level - prev_level
        # Chips collected from every player who contributed at least this tier
        tier_pot = 0
        eligible_for_tier: list[str] = []

        for player, total in contributions.items():
            if total >= level:
                tier_pot += tier_diff
                if player in active_set:
                    eligible_for_tier.append(player)
            elif total > prev_level:
                tier_pot += (total - prev_level)

        prev_level = level

        if tier_pot <= 0 or not eligible_for_tier:
            continue

        # Determine winners among active players eligible for this pot
        eligible_hands = {p: showdown_hands[p] for p in eligible_for_tier if p in showdown_hands}
        winners = determine_winners(eligible_hands) if eligible_hands else eligible_for_tier

        num_winners = len(winners) if winners else 1
        payout = tier_pot // num_winners
        remainder = tier_pot % num_winners

        pots.append(
            SidePot(
                pot_index=idx,
                amount=tier_pot,
                eligible_players=sorted(eligible_for_tier),
                winners=sorted(winners),
                payout_per_winner=payout,
                remainder_chips=remainder,
            )
        )

    return pots

