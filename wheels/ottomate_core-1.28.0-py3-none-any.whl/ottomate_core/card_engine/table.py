"""Reusable multi-player card table state, dealer rotation, hand masking, and live action ledger."""

from __future__ import annotations
from datetime import datetime, timezone
import secrets
from typing import Any, Mapping, Sequence

from pydantic import Field, model_validator

from ottomate_core.card_engine.cards import Card, create_shuffled_deck, make_card
from ottomate_core.card_engine.trick import CompletedTrick, TrickPlay
from ottomate_core.models import DictCompatibleModel


class ActionLogEntry(DictCompatibleModel):
    """Represents a single event in the live table action ledger."""

    type: str
    text: str
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class LiveTableState(DictCompatibleModel):
    """Strongly-typed state of an active multi-player card table round."""

    mode: str = "live"
    stage: str = "bidding"
    dealer: str = ""
    trump_card: Card | None = None
    trump_suit: str | None = None
    hands: dict[str, list[Card]] = Field(default_factory=dict)
    bids: dict[str, int] = Field(default_factory=dict)
    bidding_order: list[str] = Field(default_factory=list)
    bidding_turn: str | None = None
    tricks_won: dict[str, int] = Field(default_factory=dict)
    current_trick: list[TrickPlay] = Field(default_factory=list)
    trick_lead_player: str | None = None
    turn_player: str | None = None
    trick_history: list[CompletedTrick] = Field(default_factory=list)
    trick_completed: bool = False
    trick_winner: str | None = None
    winning_card: Card | None = None
    trick_explanation: str | None = None
    trick_completed_at: str | None = None
    last_action_at: str | None = None
    action_log: list[ActionLogEntry] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _coerce_nested(cls, values: Any) -> Any:
        if not isinstance(values, Mapping):
            return values
        data = dict(values)
        if data.get("trump_card") and not isinstance(data["trump_card"], Card):
            data["trump_card"] = Card.from_raw(data["trump_card"])
        if data.get("winning_card") and not isinstance(data["winning_card"], Card):
            data["winning_card"] = Card.from_raw(data["winning_card"])
        if "hands" in data and isinstance(data["hands"], Mapping):
            data["hands"] = {
                p: [Card.from_raw(c) for c in cards]
                for p, cards in data["hands"].items()
            }
        return data

    def record_action(
        self,
        action_type: str,
        text: str,
        details: Mapping[str, Any] | None = None,
        max_entries: int = 100,
    ) -> ActionLogEntry:
        """Appends a timestamped event entry to this live table's action_log."""
        payload: dict[str, Any] = {
            "type": action_type,
            "text": text,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        if details:
            payload.update(details)
        entry = ActionLogEntry(**payload)
        self.action_log.append(entry)
        if len(self.action_log) > max_entries:
            self.action_log = self.action_log[-max_entries:]
        return entry


class LiveRoundSnapshot(DictCompatibleModel):
    """Strongly-typed client snapshot for a live card table round."""

    game_id: str
    round_number: int
    cards_per_player: int
    mode: str = "live"
    stage: str = "bidding"
    dealer: str | None = None
    trump_card: Card | None = None
    trump_suit: str | None = None
    hands: dict[str, list[Card]] = Field(default_factory=dict)
    all_hands: dict[str, list[Card]] | None = None
    my_hand: list[Card] = Field(default_factory=list)
    hands_counts: dict[str, int] = Field(default_factory=dict)
    hand_sizes: dict[str, int] = Field(default_factory=dict)
    bids: dict[str, int] = Field(default_factory=dict)
    bidding_turn: str | None = None
    bidding_order: list[str] = Field(default_factory=list)
    tricks_won: dict[str, int] = Field(default_factory=dict)
    current_trick: list[TrickPlay] = Field(default_factory=list)
    trick_lead_player: str | None = None
    lead_player: str | None = None
    lead_suit: str | None = None
    turn_player: str | None = None
    current_turn: str | None = None
    trick_history: list[CompletedTrick] = Field(default_factory=list)
    tricks_history: list[CompletedTrick] = Field(default_factory=list)
    scores: dict[str, int] = Field(default_factory=dict)
    is_admin: bool = False
    can_bid: bool = False
    can_play: bool = False
    legal_cards: list[str] = Field(default_factory=list)
    proxy_players: list[str] = Field(default_factory=list)
    acting_player: str = ""
    status: str = "bidding"
    game_current_round: int = 1
    game_status: str = "active"
    game_cumulative_scores: dict[str, int] = Field(default_factory=dict)
    cumulative_scores: dict[str, int] = Field(default_factory=dict)
    npc_players: dict[str, str] = Field(default_factory=dict)
    updated_at: str | None = None
    trick_completed: bool = False
    trick_winner: str | None = None
    winning_card: Card | None = None
    trick_explanation: str | None = None
    trick_completed_at: str | None = None
    last_action_at: str | None = None
    action_log: list[ActionLogEntry] = Field(default_factory=list)


def pick_starting_dealer(num_players: int, previous_dealer_idx: int | None = None) -> int:
    """Selects a random starting dealer index in `[0, num_players - 1]`.

    When `previous_dealer_idx` is supplied (e.g. on a rematch) and `num_players > 1`,
    guarantees a different starting dealer from the previous game.
    """
    if num_players <= 1:
        return 0
    if previous_dealer_idx is None:
        return secrets.randbelow(num_players)
    prev = int(previous_dealer_idx) % num_players
    return (prev + 1 + secrets.randbelow(num_players - 1)) % num_players


def get_round_dealer_and_order(
    players: Sequence[str],
    round_number: int = 1,
    starting_dealer_idx: int = 0,
) -> tuple[str, list[str]]:
    """Returns `(dealer_email, clockwise_order_starting_left_of_dealer)` for the given 1-indexed round."""
    if not players:
        raise ValueError("Players list cannot be empty.")
    n = len(players)
    dealer_idx = (int(starting_dealer_idx) + int(round_number) - 1) % n
    dealer = players[dealer_idx]
    clockwise_order = [players[(dealer_idx + 1 + i) % n] for i in range(n)]
    return dealer, clockwise_order


def mask_hands_for_viewer(
    hands: Mapping[str, Sequence[Card | Mapping[str, Any]]],
    viewer_email: str,
    is_admin: bool,
    proxy_players: Sequence[str] = (),
) -> dict[str, list[Card]]:
    """Masks opponent hands with face-down `Card.hidden(i)` placeholders unless viewer is authorized."""
    proxy_set = set(proxy_players)
    visible: dict[str, list[Card]] = {}
    for player_email, hand in hands.items():
        if is_admin or player_email == viewer_email or player_email in proxy_set:
            visible[player_email] = [Card.from_raw(c) for c in hand]
        else:
            visible[player_email] = [Card.hidden(i) for i in range(len(hand))]
    return visible


def record_live_action(
    live_state: LiveTableState | dict[str, Any],
    action_type: str,
    text: str,
    details: Mapping[str, Any] | None = None,
    max_entries: int = 100,
) -> ActionLogEntry:
    """Appends an event entry to a `LiveTableState` or mutable `live_state` dict."""
    if isinstance(live_state, LiveTableState):
        return live_state.record_action(action_type, text, details=details, max_entries=max_entries)

    if "action_log" not in live_state or not isinstance(live_state["action_log"], list):
        live_state["action_log"] = []
    payload: dict[str, Any] = {
        "type": action_type,
        "text": text,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    if details:
        payload.update(details)
    entry = ActionLogEntry(**payload)
    live_state["action_log"].append(entry)
    if len(live_state["action_log"]) > max_entries:
        live_state["action_log"] = live_state["action_log"][-max_entries:]
    return entry


def deal_standard_round(
    players: Sequence[str],
    cards_count: int,
    round_number: int = 1,
    seed: int | str | None = None,
    starting_dealer_idx: int = 0,
) -> LiveTableState:
    """Deals `cards_count` cards to each player, flips a trump card, and initializes `LiveTableState`."""
    deck = create_shuffled_deck(seed)
    hands: dict[str, list[Card]] = {p: [] for p in players}
    idx = 0
    for _ in range(cards_count):
        for p in players:
            hands[p].append(deck[idx])
            idx += 1

    for p in players:
        hands[p].sort(key=lambda c: (c.suit, c.rank))

    trump_card = deck[idx] if idx < len(deck) else make_card(14, "S")
    trump_suit = trump_card.suit
    dealer, bidding_order = get_round_dealer_and_order(players, round_number, starting_dealer_idx)

    return LiveTableState(
        mode="live",
        stage="bidding",
        dealer=dealer,
        trump_card=trump_card,
        trump_suit=trump_suit,
        hands=hands,
        bids={},
        bidding_order=bidding_order,
        bidding_turn=bidding_order[0],
        tricks_won={p: 0 for p in players},
        current_trick=[],
        trick_lead_player=bidding_order[0],
        turn_player=bidding_order[0],
        trick_history=[],
        action_log=[
            ActionLogEntry(
                type="deal",
                round=round_number,
                text=(
                    f"Round {round_number} dealt • {cards_count} cards each • "
                    f"Trump is {trump_suit} ({trump_card.label}{trump_card.suit_symbol}) • "
                    f"Dealer is {dealer}"
                ),
            )
        ],
    )
