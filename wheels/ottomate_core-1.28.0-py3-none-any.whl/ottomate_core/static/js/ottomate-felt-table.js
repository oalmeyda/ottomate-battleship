// Ottomate Core: Shared Circular Felt Card Table & Playing Card UI Kit
// Served via /core-static/js/ottomate-felt-table.js

const OTTOMATE_SUIT_MAP = {
  S: { symbol: "♠", name: "Spades", colorClass: "black-suit", color: "#f8fafc" },
  H: { symbol: "♥", name: "Hearts", colorClass: "red-suit", color: "#ef4444" },
  D: { symbol: "♦", name: "Diamonds", colorClass: "red-suit", color: "#ef4444" },
  C: { symbol: "♣", name: "Clubs", colorClass: "black-suit", color: "#f8fafc" }
};

function partitionCircularSeats(totalPlayers) {
  const N = totalPlayers;
  if (N <= 0) return { top: [], right: [], bottom: [], left: [] };
  if (N === 1) return { top: [0], right: [], bottom: [], left: [] };
  if (N === 2) return { top: [0], right: [], bottom: [1], left: [] };
  if (N === 3) return { top: [0], right: [1], bottom: [2], left: [] };

  // N >= 4: 1 on Right (East), 1 on Left (West), remaining N - 2 split across Top and Bottom
  const topCount = Math.ceil((N - 2) / 2);
  const top = [];
  for (let i = 0; i < topCount; i++) top.push(i);
  const right = [topCount];
  const bottom = [];
  for (let i = topCount + 1; i < N - 1; i++) bottom.push(i);
  const left = [N - 1];
  return { top, right, bottom, left };
}

function getSeatAngle(position, seatIndex, totalInPosition) {
  if (position === "left") return 90;
  if (position === "right") return 270;
  if (position === "top") {
    if (!totalInPosition || totalInPosition <= 1) return 180;
    if (totalInPosition === 2) return seatIndex === 0 ? 135 : 225;
    const step = 90 / (totalInPosition - 1);
    return Math.round(135 + seatIndex * step);
  }
  if (position === "bottom") {
    if (!totalInPosition || totalInPosition <= 1) return 0;
    if (totalInPosition === 2) return seatIndex === 0 ? 45 : 315;
    const step = 90 / (totalInPosition - 1);
    return Math.round(45 + seatIndex * step);
  }
  return 0;
}

function determineWinningTrickIndex(trickList, trumpSuit) {
  if (!trickList || trickList.length === 0) return -1;
  const firstPlay = trickList[0];
  if (!firstPlay || !firstPlay.card) return -1;
  const leadSuit = firstPlay.card.suit;
  let winIdx = 0;
  let winCard = firstPlay.card;

  for (let i = 1; i < trickList.length; i++) {
    const play = trickList[i];
    const c = play.card;
    if (!c) continue;

    const cTrump = (c.suit === trumpSuit);
    const winTrump = (winCard.suit === trumpSuit);

    if (cTrump && !winTrump) {
      winIdx = i;
      winCard = c;
    } else if (cTrump && winTrump) {
      if ((c.rank ?? 0) > (winCard.rank ?? 0)) {
        winIdx = i;
        winCard = c;
      }
    } else if (!cTrump && !winTrump) {
      if (c.suit === leadSuit && (c.rank ?? 0) > (winCard.rank ?? 0)) {
        winIdx = i;
        winCard = c;
      }
    }
  }
  return winIdx;
}

function renderPlayingCard(card, onClickJs = null, isPlayable = true, extraClasses = "", disabledReason = "", playerColor = null, cardOptions = {}) {
  if (!card) return "";
  if (card.id && (card.id.startsWith("hidden") || card.suit === "?" || card.suit === "hidden")) {
    return `
      <div class="playing-card ${extraClasses}" style="background: #1e3a8a; border: 2px solid #60a5fa; display: flex; align-items: center; justify-content: center; color: #93c5fd; font-size: 1.5rem;" title="Opponent card (Face down)">
        🎴
      </div>
    `;
  }
  const suitInfo = OTTOMATE_SUIT_MAP[card.suit] || { symbol: card.suit, name: "", colorClass: "black-suit" };
  const displayRank = card.label || card.rank;
  const showAssist = Boolean(typeof state !== "undefined" && state.settings && state.settings.highlightPlayable);

  let cardStateClass = "";
  if (onClickJs && isPlayable) {
    cardStateClass = showAssist ? "playable" : "clickable-unassisted";
  } else if (!isPlayable) {
    cardStateClass = showAssist ? "disabled" : "";
  }

  const clickAttr = (onClickJs && isPlayable)
    ? `onclick="${onClickJs}"`
    : (disabledReason ? `onclick="showAlert('${disabledReason.replace(/'/g, "\\'")}', true)"` : "");
  const titleAttr = isPlayable
    ? 'title="Click to play card"'
    : `title="${disabledReason || 'Cannot play this card right now'}"`;

  const playableBadge = (onClickJs && isPlayable && showAssist) ? '<span class="card-playable-badge">Play</span>' : '';

  // Authentic poker chips: Lead ("L") and Winning ("W")
  const isLead = Boolean(cardOptions.isLead);
  const isWin = Boolean(cardOptions.isWin || extraClasses.includes("winning-trick-card"));
  let chipHtml = cardOptions.chipsHtml || "";
  if (!chipHtml) {
    if (isLead && isWin) {
      chipHtml = `
        <span class="poker-chip-lead dual-chip" title="Lead Card (Started Trick)">L</span>
        <span class="poker-chip-win" title="Currently Winning Card">W</span>
      `;
    } else if (isLead) {
      chipHtml = `<span class="poker-chip-lead" title="Lead Card (Started Trick)">L</span>`;
    } else if (isWin) {
      chipHtml = `<span class="poker-chip-win" title="Currently Winning Card">W</span>`;
    }
  }

  let colorRingStyle = "";
  if (isWin) {
    colorRingStyle = `box-shadow: 0 0 12px rgba(250, 204, 21, 0.95), 0 0 0 2.5px #facc15 !important; border-color: #facc15 !important;`;
  } else if (playerColor) {
    colorRingStyle = `box-shadow: 0 0 0 2.5px ${playerColor}, 0 4px 10px rgba(0,0,0,0.4) !important; border-color: ${playerColor} !important;`;
  }

  return `
    <div class="playing-card ${suitInfo.colorClass} ${cardStateClass} ${extraClasses}" style="${colorRingStyle}" ${clickAttr} ${titleAttr}>
      ${chipHtml}
      ${playableBadge}
      <div class="card-top">${displayRank}${suitInfo.symbol}</div>
      <div class="card-center">${suitInfo.symbol}</div>
      <div class="card-bottom">${displayRank}${suitInfo.symbol}</div>
    </div>
  `;
}

function renderSeatCard(p, seatIdx, turnEmail, nextTurnEmail, live, players, isSessionAdmin, proxyPlayers, seatOptions = {}) {
  const isTurn = turnEmail === p.email;
  const isNext = (nextTurnEmail === p.email && !isTurn);
  const isDealer = live.dealer === p.email;
  const currentUserEmail = (typeof state !== "undefined" && state.currentUser) ? state.currentUser.email : "";
  const isMe = p.email === currentUserEmail;
  const youTag = isMe ? '<span style="color: #38bdf8; font-size: 0.7rem; font-weight: 700; margin-left: 0.15rem;">(You)</span>' : '';
  const bidVal = (live.bids && live.bids[p.email] !== undefined) ? live.bids[p.email] : "—";
  const tricksWon = (live.tricks_won && live.tricks_won[p.email]) ?? 0;
  const cardCount = (live.hand_sizes && live.hand_sizes[p.email]) ?? (live.hands_counts && live.hands_counts[p.email]) ?? 0;

  const miniCardsHtml = `
    <div class="seat-hand-mini" title="${cardCount} card${cardCount === 1 ? '' : 's'} in hand">
      <span style="font-size: 1.05rem; line-height: 1;">🂠</span>
      <span style="font-weight: 800; font-size: 0.8rem; color: #cbd5e1; margin-left: 0.15rem;">×${cardCount}</span>
    </div>
  `;

  const npcProfile = (typeof state !== "undefined" && state.activeGame && state.activeGame.npc_players && state.activeGame.npc_players[p.email])
    || (live && live.npc_players && live.npc_players[p.email])
    || "off";
  const isBot = npcProfile !== "off";
  const botCodeMap = { easy: "E", medium: "M", hard: "H" };
  const botCode = botCodeMap[npcProfile] || "";

  let statusPill = seatOptions.statusPillHtml || "";
  if (!statusPill) {
    if (live.stage === "completed") {
      const score = (live.scores && live.scores[p.email]) ?? 0;
      const made = bidVal !== "—" && bidVal === tricksWon;
      statusPill = made
        ? `<span style="color: #4ade80; font-size: 0.72rem; font-weight: 700;">🎯 +${score}</span>`
        : `<span style="color: #f87171; font-size: 0.72rem; font-weight: 700;">❌ 0</span>`;
    } else if (isTurn) {
      const turnActionText = live.stage === "bidding" ? "Bidding" : "Playing";
      statusPill = `<span class="seat-turn-pill turn-pill-active">👉 ${turnActionText}</span>`;
    } else if (isNext && live.stage !== "completed") {
      statusPill = `<span class="seat-turn-pill turn-pill-next">⏭️ Next</span>`;
    } else if (live.stage === "bidding" && bidVal !== "—") {
      statusPill = `<span style="color: #38bdf8; font-size: 0.72rem; font-weight: 700;">Bid: ${bidVal}</span>`;
    }
  }

  let botTag = "";
  if (isBot) {
    const badgeColor = npcProfile === "easy" ? "#16a34a" : (npcProfile === "medium" ? "#d97706" : "#9333ea");
    botTag = `<span class="bot-chip" style="background: ${badgeColor};" title="Automated Bot (${npcProfile.toUpperCase()})">🤖${botCode}</span>`;
  }

  // Rotating 3D Dealer Poker Chip
  const position = seatOptions.position || "top";
  const seatAngle = seatOptions.angle ?? getSeatAngle(position, seatIdx, seatOptions.totalInPosition || 1);
  const dealerChipHtml = isDealer ? `<div class="poker-chip-dealer" style="transform: rotate(${seatAngle}deg);" title="Dealer (Bids Last)">D</div>` : "";
  let dealerChipBefore = "";
  let dealerChipAfter = "";
  if (isDealer) {
    if (position === "right") {
      dealerChipAfter = dealerChipHtml;
    } else if (position === "left") {
      dealerChipBefore = dealerChipHtml;
    } else if (position === "bottom") {
      if (seatIdx === 0) dealerChipBefore = dealerChipHtml;
      else dealerChipAfter = dealerChipHtml;
    } else {
      if (seatIdx === 0) dealerChipBefore = dealerChipHtml;
      else dealerChipAfter = dealerChipHtml;
    }
  }

  let adminActionsHtml = "";
  const isProxyForThisPlayer = (proxyPlayers || []).includes(p.email);
  if (isSessionAdmin || isProxyForThisPlayer) {
    adminActionsHtml = `
      <div class="seat-admin-actions">
        ${isSessionAdmin ? `
          <button type="button" class="btn btn-secondary btn-sm seat-admin-btn"
            onclick="adminPeekPlayer('${p.email}')" title="Inspect Player's Hand">
            👁️<span class="admin-btn-label"> Peek</span>
          </button>
        ` : ''}
        ${isTurn ? `
          <button type="button" class="btn btn-primary btn-sm seat-admin-btn" style="${isProxyForThisPlayer && !isSessionAdmin ? 'background: #059669; border-color: #10b981;' : ''}"
            onclick="adminProxyTurn('${p.email}')" title="Take Turn as this Player">
            ${isProxyForThisPlayer && !isSessionAdmin ? '🤝<span class="admin-btn-label"> Act</span>' : '⚡<span class="admin-btn-label"> Act</span>'}
          </button>
        ` : ''}
        ${isSessionAdmin ? `
          <select class="seat-bot-select"
            onchange="setPlayerNPC('${p.email}', this.value)" title="Configure Automated Bot Profile (Off / E / M / H)">
            <option value="off" ${npcProfile === 'off' ? 'selected' : ''}>Off</option>
            <option value="easy" ${npcProfile === 'easy' ? 'selected' : ''}>E</option>
            <option value="medium" ${npcProfile === 'medium' ? 'selected' : ''}>M</option>
            <option value="hard" ${npcProfile === 'hard' ? 'selected' : ''}>H</option>
          </select>
        ` : ''}
      </div>
    `;
  }

  const pColor = (typeof getPlayerColor === "function") ? getPlayerColor(p.email, players) : { bg: "#38bdf8" };
  const turnClass = isTurn ? 'turn-active' : (isNext ? 'seat-on-deck' : '');
  const displayName = p.display_name || p.email.split('@')[0];

  // Check if this player has played a card in the current/last trick so we deploy it right next to them
  let activeTrickList = [];
  let activeTrickWinner = null;
  if (live.stage === "playing") {
    activeTrickList = live.current_trick || [];
    if (live.trick_completed) {
      activeTrickWinner = live.trick_winner;
    }
  } else if (live.stage === "completed") {
    const historyList = live.tricks_history || live.trick_history || [];
    const lastTrick = historyList.length > 0 ? historyList[historyList.length - 1] : null;
    if (lastTrick) {
      activeTrickList = lastTrick.cards || [];
      activeTrickWinner = lastTrick.winner;
    }
  }
  const playIdx = activeTrickList.findIndex(t => (t.player_email || t.player) === p.email);
  const playedEntry = playIdx >= 0 ? activeTrickList[playIdx] : null;
  const isTrickWinner = Boolean(activeTrickWinner && activeTrickWinner === p.email);

  let isLeadCard = false;
  let isWinCard = false;
  if (activeTrickList.length > 0 && playedEntry) {
    if (playIdx === 0) {
      isLeadCard = true;
    }
    if (isTrickWinner) {
      isWinCard = true;
    } else if (live.stage === "playing" && !live.trick_completed) {
      const currentWinningPlayIdx = determineWinningTrickIndex(activeTrickList, live.trump_suit);
      if (currentWinningPlayIdx === playIdx) {
        isWinCard = true;
      }
    }
  }

  let seatCardSlotHtml = "";
  if (live.stage === "playing" || live.stage === "completed") {
    if (playedEntry && playedEntry.card) {
      const winClass = isTrickWinner ? "seat-mini-card winning-trick-card" : "seat-mini-card";
      seatCardSlotHtml = `
        <div class="seat-played-slot has-played-card" title="Played #${playIdx + 1} in trick">
          ${renderPlayingCard(playedEntry.card, null, false, winClass, '', pColor.bg, { isLead: isLeadCard, isWin: isWinCard })}
        </div>
      `;
    } else {
      seatCardSlotHtml = `
        <div class="seat-played-slot" title="${cardCount} card${cardCount === 1 ? '' : 's'} in hand (waiting to play)">
          <div class="seat-empty-card-slot">
            <span style="font-size: 0.78rem; line-height: 1;">🂠</span>
            <span style="font-size: 0.58rem; font-weight: 800; color: #94a3b8;">×${cardCount}</span>
          </div>
        </div>
      `;
    }
  }

  const statsHtml = seatOptions.statsHtml || `
    <span>Bid: <strong style="color: #f8fafc;">${bidVal}</strong></span>
    <span>Trk: <strong style="color: #38bdf8;">${tricksWon}</strong></span>
  `;

  return `
    <div class="seat-card ${turnClass} ${playedEntry ? 'seat-has-played' : ''} seat-station-${position}">
      <div class="seat-card-body">
        <div class="seat-station-header">
          ${dealerChipBefore}
          <div class="seat-info-col" style="border-top: 3.5px solid ${pColor.bg};">
            <div class="seat-header">
              <div class="seat-header-left">
                <span class="seat-name" title="${displayName} (${p.email})">${displayName}${youTag}</span>
              </div>
              <div class="seat-header-right">
                ${botTag}
              </div>
            </div>
            <div class="seat-stats">
              ${statsHtml}
            </div>
            <div class="seat-footer-row">
              ${live.stage === "bidding" ? miniCardsHtml : `<span style="font-size: 0.62rem; color: #94a3b8;">🂠×${cardCount}</span>`}
              ${statusPill}
            </div>
            ${adminActionsHtml}
          </div>
          ${dealerChipAfter}
        </div>
        ${seatCardSlotHtml}
      </div>
    </div>
  `;
}

if (typeof window !== "undefined") {
  window.OttomateFeltTable = {
    OTTOMATE_SUIT_MAP,
    partitionCircularSeats,
    getSeatAngle,
    determineWinningTrickIndex,
    renderPlayingCard,
    renderSeatCard,
  };
}
