/**
 * Ottomate Core People Modals (classic script, requires ottomate-header.js)
 *
 * Shared Directory + Profile & Proxy Delegation modals for all Ottomate services.
 * Markup is injected on first use and styled by css/ottomate-people.css (themeable via --otto-p-* variables).
 *
 *   Ottomate.people.init({
 *     appName: "Ottomate Lingo",
 *     hideProxies: false,
 *     onChange: () => refreshProxySelector(),
 *     onProfileUpdated: (me) => syncLocalUser(me),
 *     renderProfileExtra: (el, me) => { ... },
 *     customDirectoryActions: [{ label: "🏋️ Log", onClick: (u) => ... }],
 *     onError: (msg) => toast(msg),
 *   });
 *   Ottomate.people.openDirectory();
 *   Ottomate.people.openProfile();
 *
 * Endpoints used (all provided by ottomate_core.api.users):
 *   GET /api/me, PUT /api/me/profile, GET /api/users, POST /api/users,
 *   DELETE /api/users/{email}, PUT /api/users/{email}/role, PUT /api/users/{email}/preferences,
 *   POST /api/me/proxies, DELETE /api/me/proxies/{email},
 *   GET /api/users/{email}/proxies, POST /api/users/{email}/proxies, DELETE /api/users/{email}/proxies/{proxy}
 */
(function () {
  const root = typeof window !== "undefined" ? window : this;
  root.Ottomate = root.Ottomate || {};

  const DIRECTORY_ID = "otto-directory-modal";
  const PROFILE_ID = "otto-profile-modal";
  const PREFS_ID = "otto-prefs-modal";
  const ADMIN_PROXIES_ID = "otto-admin-proxies-modal";
  const PAGE_SIZE = 7;
  const NICKNAME_RE = /^[A-Za-z0-9]{1,59}$/;

  const opts = {
    appName: "this app",
    hideProxies: false,
    onChange: null,
    onProfileUpdated: null,
    renderProfileExtra: null,
    customDirectoryActions: null,
    onError: null,
  };
  let built = false;
  let cachedUsers = [];
  let dirSearchQuery = "";
  let dirRoleFilter = "all";
  let dirPage = 1;
  let activeAdminProxyTarget = "";

  const O = () => root.Ottomate;
  const esc = (v) => O().escapeHtml(v);

  function report(err, fallback) {
    const msg = (err && err.message) || fallback;
    if (typeof opts.onError === "function") opts.onError(msg);
    else console.error(msg);
  }

  function changed() {
    if (typeof opts.onChange === "function") opts.onChange();
  }

  function isAdmin(u) {
    return Boolean(u && (u.is_super_admin || u.is_game_admin || u.is_admin));
  }

  async function ensureCurrentUserLoaded() {
    if (O().state && O().state.currentUser) return O().state.currentUser;
    try {
      const me = await O().api("/api/me");
      if (me && me.email) {
        O().state = O().state || {};
        O().state.currentUser = me;
        return me;
      }
    } catch (_) {
      // Unauthenticated or unavailable; caller handles null
    }
    return null;
  }

  function populateDatalist(datalistEl, excludeEmail) {
    if (!datalistEl) return;
    const normExclude = (excludeEmail || "").toLowerCase();
    datalistEl.innerHTML = "";
    cachedUsers.forEach((u) => {
      if (!u.email || u.email.toLowerCase() === normExclude) return;
      const opt = document.createElement("option");
      opt.value = u.email;
      opt.label = u.display_name ? `${u.display_name} (${u.email})` : u.email;
      datalistEl.appendChild(opt);
    });
  }

  function build() {
    if (built) return;
    built = true;
    const wrap = document.createElement("div");
    wrap.innerHTML = `
      <div id="${DIRECTORY_ID}" class="otto-modal-overlay otto-hidden" role="dialog" aria-modal="true" aria-labelledby="${DIRECTORY_ID}-title">
        <div class="otto-modal-card otto-modal-wide">
          <div class="otto-modal-header">
            <h3 id="${DIRECTORY_ID}-title">\u{1F465} Directory</h3>
            <button type="button" class="otto-modal-close" data-otto-close aria-label="Close">&times;</button>
          </div>
          <p class="otto-muted" id="${DIRECTORY_ID}-desc"></p>

          <div id="${DIRECTORY_ID}-admin-add" class="otto-panel otto-panel-admin otto-hidden">
            <div class="otto-admin-onboard-bar">
              <span class="otto-admin-onboard-label">👑 Onboard New User</span>
              <form id="${DIRECTORY_ID}-add-user-form" class="otto-form-row">
                <input type="email" class="otto-input" id="${DIRECTORY_ID}-new-email" placeholder="user@example.com" required />
                <input type="text" class="otto-input" id="${DIRECTORY_ID}-new-name" placeholder="Display Name (optional)" />
                <button type="submit" class="otto-btn otto-btn-primary">+ Add User</button>
              </form>
            </div>
            <div id="${DIRECTORY_ID}-add-feedback" class="otto-feedback" style="margin-top: 0.25rem;"></div>
          </div>

          <div class="otto-dir-toolbar">
            <div class="otto-search-box">
              <span class="otto-search-icon">🔍</span>
              <input
                type="search"
                class="otto-input otto-search-input"
                id="${DIRECTORY_ID}-search"
                placeholder="Search current users by name, email, role, or proxy..."
                autocomplete="off"
              />
              <button
                type="button"
                id="${DIRECTORY_ID}-search-clear"
                class="otto-search-clear otto-hidden"
                title="Clear search"
                aria-label="Clear search"
              >&times;</button>
            </div>
            <div class="otto-role-Filter-group" id="${DIRECTORY_ID}-role-tabs" role="tablist" aria-label="Filter users by role">
              <button type="button" class="otto-role-pill active" data-role="all">All</button>
              <button type="button" class="otto-role-pill" data-role="admin">👑 Admins</button>
              <button type="button" class="otto-role-pill" data-role="player">🎮 Players</button>
            </div>
          </div>

          <div class="otto-table-wrap">
            <table class="otto-table">
              <thead>
                <tr>
                  <th>Player</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th id="${DIRECTORY_ID}-th-proxies">Proxies</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="${DIRECTORY_ID}-tbody">
                <tr><td colspan="5" class="otto-center">Loading...</td></tr>
              </tbody>
            </table>
          </div>

          <div class="otto-modal-footer">
            <div id="${DIRECTORY_ID}-count-info" class="otto-muted" style="margin: 0;">0 users</div>
            <div style="display: flex; align-items: center; gap: 0.65rem; flex-wrap: wrap;">
              <div id="${DIRECTORY_ID}-pagination" class="otto-pagination-bar otto-hidden">
                <button type="button" class="otto-btn otto-btn-sm" id="${DIRECTORY_ID}-prev">◀ Prev</button>
                <span class="otto-page-indicator" id="${DIRECTORY_ID}-page-info">Page 1 of 1</span>
                <button type="button" class="otto-btn otto-btn-sm" id="${DIRECTORY_ID}-next">Next ▶</button>
              </div>
              <button type="button" class="otto-btn" data-otto-close>Close</button>
            </div>
          </div>
        </div>
      </div>

      <div id="${PROFILE_ID}" class="otto-modal-overlay otto-hidden" role="dialog" aria-modal="true" aria-labelledby="${PROFILE_ID}-title">
        <div class="otto-modal-card">
          <div class="otto-modal-header">
            <h3 id="${PROFILE_ID}-title">\u{1F464} Profile &amp; Proxy Delegation</h3>
            <button type="button" class="otto-modal-close" data-otto-close aria-label="Close">&times;</button>
          </div>
          <div class="otto-panel otto-profile-head">
            <div id="${PROFILE_ID}-avatar" class="otto-avatar">??</div>
            <div>
              <div id="${PROFILE_ID}-name" class="otto-profile-name"></div>
              <div id="${PROFILE_ID}-email" class="otto-muted"></div>
              <div id="${PROFILE_ID}-role" class="otto-profile-role"></div>
            </div>
          </div>

          <div class="otto-panel">
            <strong>✏️ Display Nickname</strong>
            <p class="otto-muted">Alphanumeric characters only (1–59 chars), shared across all Ottomate games.</p>
            <form id="${PROFILE_ID}-nickname-form" class="otto-form-col">
              <div class="otto-form-row">
                <input
                  type="text"
                  class="otto-input"
                  id="${PROFILE_ID}-nickname"
                  placeholder="e.g. AcePlayer99"
                  maxlength="59"
                  autocomplete="nickname"
                  required
                />
                <button type="submit" class="otto-btn otto-btn-primary">Save Nickname</button>
              </div>
              <div id="${PROFILE_ID}-nick-feedback" class="otto-feedback"></div>
            </form>
          </div>

          <div id="${PROFILE_ID}-extra" class="otto-panel otto-hidden"></div>

          <div id="${PROFILE_ID}-proxy-for-panel" class="otto-panel otto-hidden">
            <strong>🎮 Playing on Behalf Of</strong>
            <p class="otto-muted">Players who have authorized you to act as their proxy.</p>
            <div id="${PROFILE_ID}-proxy-for-list" class="otto-proxy-badges"></div>
          </div>

          <div id="${PROFILE_ID}-proxies-panel" class="otto-panel">
            <strong>\u{1F91D} Your Authorized Proxies</strong>
            <p class="otto-muted">Players authorized to act on your behalf.</p>
            <div id="${PROFILE_ID}-proxies" class="otto-proxy-list"></div>
            <form id="${PROFILE_ID}-add-proxy" class="otto-form-row">
              <input type="email" class="otto-input" id="${PROFILE_ID}-proxy-email" list="${PROFILE_ID}-users-datalist" placeholder="Search or enter player@example.com" required />
              <datalist id="${PROFILE_ID}-users-datalist"></datalist>
              <button type="submit" class="otto-btn">+ Add Proxy</button>
            </form>
          </div>
          <div class="otto-modal-footer" style="justify-content: flex-end;">
            <button type="button" class="otto-btn" data-otto-close>Close</button>
          </div>
        </div>
      </div>

      <div id="${PREFS_ID}" class="otto-modal-overlay otto-hidden" role="dialog" aria-modal="true" aria-labelledby="${PREFS_ID}-title">
        <div class="otto-modal-card">
          <div class="otto-modal-header">
            <h3 id="${PREFS_ID}-title">⚙️ Cross-Service User Preferences</h3>
            <button type="button" class="otto-modal-close" data-otto-close aria-label="Close">&times;</button>
          </div>
          <p class="otto-muted">Editing shared platform preferences for <strong id="${PREFS_ID}-user">-</strong>.</p>
          <form id="${PREFS_ID}-form">
            <div style="margin-bottom: 0.8rem;">
              <label for="${PREFS_ID}-json" style="font-size:0.82rem; font-weight:600; display:block; margin-bottom:0.3rem; color:#0f172a;">Preferences JSON</label>
              <textarea id="${PREFS_ID}-json" class="otto-input" rows="7" style="font-family:monospace; font-size:0.82rem; width:100%; box-sizing:border-box;"></textarea>
              <small class="otto-muted" style="display:block; margin-top:0.25rem;">Includes default styles, split variations, and service-specific configurations.</small>
            </div>
            <div id="${PREFS_ID}-feedback" class="otto-feedback"></div>
            <div class="otto-modal-footer" style="justify-content: flex-end; gap: 0.5rem;">
              <button type="button" class="otto-btn" data-otto-close>Cancel</button>
              <button type="submit" class="otto-btn otto-btn-primary">Save Preferences</button>
            </div>
          </form>
        </div>
      </div>

      <div id="${ADMIN_PROXIES_ID}" class="otto-modal-overlay otto-hidden" role="dialog" aria-modal="true" aria-labelledby="${ADMIN_PROXIES_ID}-title">
        <div class="otto-modal-card">
          <div class="otto-modal-header">
            <h3 id="${ADMIN_PROXIES_ID}-title">🤝 Manage User Proxies</h3>
            <button type="button" class="otto-modal-close" data-otto-close aria-label="Close">&times;</button>
          </div>
          <p class="otto-muted">Managing authorized proxy delegates for <strong id="${ADMIN_PROXIES_ID}-user">-</strong>.</p>
          <div class="otto-panel">
            <strong>Authorized Proxies</strong>
            <p class="otto-muted">Players permitted to submit turns, picks, or workouts for this user.</p>
            <div id="${ADMIN_PROXIES_ID}-list" class="otto-proxy-list"></div>
            <form id="${ADMIN_PROXIES_ID}-form" class="otto-form-row">
              <input
                type="email"
                class="otto-input"
                id="${ADMIN_PROXIES_ID}-email"
                list="${ADMIN_PROXIES_ID}-datalist"
                placeholder="Search or enter proxy@example.com"
                required
              />
              <datalist id="${ADMIN_PROXIES_ID}-datalist"></datalist>
              <button type="submit" class="otto-btn otto-btn-primary">+ Add Proxy</button>
            </form>
            <div id="${ADMIN_PROXIES_ID}-feedback" class="otto-feedback" style="margin-top: 0.35rem;"></div>
          </div>
          <div id="${ADMIN_PROXIES_ID}-proxy-for-wrap" class="otto-panel otto-hidden">
            <strong>🎮 Acting as Proxy For</strong>
            <div id="${ADMIN_PROXIES_ID}-proxy-for" class="otto-proxy-badges" style="margin-top: 0.35rem;"></div>
          </div>
          <div class="otto-modal-footer" style="justify-content: flex-end;">
            <button type="button" class="otto-btn" data-otto-close>Done</button>
          </div>
        </div>
      </div>`;
    while (wrap.firstChild) document.body.appendChild(wrap.firstChild);

    [DIRECTORY_ID, PROFILE_ID, PREFS_ID, ADMIN_PROXIES_ID].forEach((id) => {
      const el = document.getElementById(id);
      el.addEventListener("click", (e) => {
        if (e.target === el || e.target.closest("[data-otto-close]")) close(id);
      });
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") close();
    });

    const searchInput = document.getElementById(`${DIRECTORY_ID}-search`);
    const searchClearBtn = document.getElementById(`${DIRECTORY_ID}-search-clear`);
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        dirSearchQuery = (e.target.value || "").trim().toLowerCase();
        dirPage = 1;
        if (searchClearBtn) {
          searchClearBtn.classList.toggle("otto-hidden", !dirSearchQuery);
        }
        renderDirectoryRows();
      });
    }
    if (searchClearBtn && searchInput) {
      searchClearBtn.addEventListener("click", () => {
        searchInput.value = "";
        dirSearchQuery = "";
        dirPage = 1;
        searchClearBtn.classList.add("otto-hidden");
        renderDirectoryRows();
        searchInput.focus();
      });
    }

    const roleTabs = document.getElementById(`${DIRECTORY_ID}-role-tabs`);
    if (roleTabs) {
      roleTabs.addEventListener("click", (e) => {
        const pill = e.target.closest(".otto-role-pill");
        if (!pill) return;
        dirRoleFilter = pill.dataset.role || "all";
        dirPage = 1;
        roleTabs.querySelectorAll(".otto-role-pill").forEach((b) => {
          b.classList.toggle("active", b === pill);
        });
        renderDirectoryRows();
      });
    }

    const prevBtn = document.getElementById(`${DIRECTORY_ID}-prev`);
    const nextBtn = document.getElementById(`${DIRECTORY_ID}-next`);
    if (prevBtn) {
      prevBtn.addEventListener("click", () => {
        if (dirPage > 1) {
          dirPage--;
          renderDirectoryRows();
        }
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener("click", () => {
        dirPage++;
        renderDirectoryRows();
      });
    }

    document.getElementById(`${DIRECTORY_ID}-add-user-form`).addEventListener("submit", onDirectoryAddUser);
    document.getElementById(`${PROFILE_ID}-nickname-form`).addEventListener("submit", onSaveNickname);
    document.getElementById(`${PROFILE_ID}-add-proxy`).addEventListener("submit", onAddProxy);
    document.getElementById(`${ADMIN_PROXIES_ID}-form`).addEventListener("submit", onAdminAddProxy);
  }

  function show(id) {
    build();
    document.getElementById(id).classList.remove("otto-hidden");
  }

  function close(id) {
    if (!built) return;
    (id ? [id] : [DIRECTORY_ID, PROFILE_ID, PREFS_ID, ADMIN_PROXIES_ID]).forEach((i) => {
      const el = document.getElementById(i);
      if (el) el.classList.add("otto-hidden");
    });
  }

  function roleLabel(u) {
    if (u.is_super_admin) return "\u{1F451} Super Admin";
    if (u.is_game_admin || u.is_admin) return "\u{1F6E1}\uFE0F Game Admin";
    return "\u{1F3AE} Player";
  }

  function roleBadgeClass(u) {
    if (u.is_super_admin) return "otto-role-badge super";
    if (u.is_game_admin || u.is_admin) return "otto-role-badge admin";
    return "otto-role-badge";
  }

  function proxyEmail(p) {
    return typeof p === "string" ? p : p.email;
  }

  function proxyLabel(p) {
    if (typeof p === "string") return p;
    return p.display_name && p.display_name !== p.email ? `${p.display_name} (${p.email})` : p.email;
  }

  function updateRoleTabCounts() {
    const roleTabs = document.getElementById(`${DIRECTORY_ID}-role-tabs`);
    if (!roleTabs) return;
    const total = cachedUsers.length;
    const adminCount = cachedUsers.filter((u) => isAdmin(u)).length;
    const playerCount = total - adminCount;

    const allBtn = roleTabs.querySelector('[data-role="all"]');
    const adminBtn = roleTabs.querySelector('[data-role="admin"]');
    const playerBtn = roleTabs.querySelector('[data-role="player"]');
    if (allBtn) allBtn.textContent = `All (${total})`;
    if (adminBtn) adminBtn.textContent = `👑 Admins (${adminCount})`;
    if (playerBtn) playerBtn.textContent = `🎮 Players (${playerCount})`;
  }

  function renderDirectoryRows() {
    const tbody = document.getElementById(`${DIRECTORY_ID}-tbody`);
    const thProxies = document.getElementById(`${DIRECTORY_ID}-th-proxies`);
    const countInfoEl = document.getElementById(`${DIRECTORY_ID}-count-info`);
    const paginationEl = document.getElementById(`${DIRECTORY_ID}-pagination`);
    const pageInfoEl = document.getElementById(`${DIRECTORY_ID}-page-info`);
    const prevBtn = document.getElementById(`${DIRECTORY_ID}-prev`);
    const nextBtn = document.getElementById(`${DIRECTORY_ID}-next`);
    if (!tbody) return;

    const hideProxies = Boolean(opts.hideProxies);
    if (thProxies) thProxies.classList.toggle("otto-hidden", hideProxies);

    const me = O().state ? O().state.currentUser : null;
    const isSuper = Boolean(me && me.is_super_admin);
    const isGame = Boolean(me && (me.is_game_admin || me.is_admin));
    const canManage = isSuper || isGame;

    const filtered = cachedUsers.filter((u) => {
      if (dirRoleFilter === "admin" && !isAdmin(u)) return false;
      if (dirRoleFilter === "player" && isAdmin(u)) return false;
      if (!dirSearchQuery) return true;
      const nameStr = (u.display_name || u.nickname || "").toLowerCase();
      const emailStr = (u.email || "").toLowerCase();
      const roleStr = roleLabel(u).toLowerCase();
      const proxiesStr = (u.proxies || []).map(proxyEmail).join(" ").toLowerCase();
      return (
        nameStr.includes(dirSearchQuery) ||
        emailStr.includes(dirSearchQuery) ||
        roleStr.includes(dirSearchQuery) ||
        proxiesStr.includes(dirSearchQuery)
      );
    });

    const totalFiltered = filtered.length;
    const totalPages = Math.max(1, Math.ceil(totalFiltered / PAGE_SIZE));
    if (dirPage > totalPages) dirPage = totalPages;
    if (dirPage < 1) dirPage = 1;

    const startIdx = (dirPage - 1) * PAGE_SIZE;
    const endIdx = Math.min(startIdx + PAGE_SIZE, totalFiltered);
    const pageSlice = filtered.slice(startIdx, endIdx);

    if (countInfoEl) {
      if (totalFiltered === 0) {
        countInfoEl.textContent = dirSearchQuery || dirRoleFilter !== "all"
          ? `0 matching users (of ${cachedUsers.length} total)`
          : "0 users registered";
      } else {
        countInfoEl.textContent = `Showing ${startIdx + 1}–${endIdx} of ${totalFiltered} ${totalFiltered === 1 ? "user" : "users"}`;
      }
    }

    if (paginationEl) {
      paginationEl.classList.toggle("otto-hidden", totalPages <= 1);
      if (pageInfoEl) {
        pageInfoEl.textContent = `Page ${dirPage} of ${totalPages}`;
      }
      if (prevBtn) prevBtn.disabled = dirPage <= 1;
      if (nextBtn) nextBtn.disabled = dirPage >= totalPages;
    }

    const colSpan = hideProxies ? 4 : 5;
    tbody.replaceChildren();
    if (pageSlice.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="${colSpan}" class="otto-center otto-muted" style="padding: 1.4rem !important;">No matching users found.</td>`;
      tbody.appendChild(tr);
      return;
    }

    const customActions = Array.isArray(opts.customDirectoryActions) ? opts.customDirectoryActions : [];

    pageSlice.forEach((u) => {
      const tr = document.createElement("tr");
      const proxies = (u.proxies || []).map(proxyEmail).join(", ") || "\u2014";
      const displayName = u.display_name || u.nickname || (u.email ? u.email.split("@")[0] : "Player");
      tr.innerHTML = `
        <td><strong>${esc(displayName)}</strong></td>
        <td class="otto-cell-email">${esc(u.email)}</td>
        <td><span class="${roleBadgeClass(u)}">${esc(roleLabel(u))}</span></td>
        <td class="otto-cell-proxies ${hideProxies ? "otto-hidden" : ""}" title="${esc(proxies)}">${esc(proxies)}</td>
        <td class="otto-actions-cell"><div class="otto-actions-group"></div></td>`;

      const actionsGroup = tr.querySelector(".otto-actions-group");

      customActions.forEach((act) => {
        if (!act || typeof act.onClick !== "function") return;
        if (typeof act.visible === "function" && !act.visible(u, me)) return;
        const cBtn = document.createElement("button");
        cBtn.type = "button";
        cBtn.className = act.className || "otto-btn otto-btn-sm";
        cBtn.textContent = act.label || "Action";
        if (act.title) {
          cBtn.title = typeof act.title === "function" ? act.title(u) : String(act.title);
        }
        cBtn.addEventListener("click", () => act.onClick(u));
        actionsGroup.appendChild(cBtn);
      });

      if (isSuper && !u.is_super_admin) {
        const makeAdmin = !(u.is_game_admin || u.is_admin);
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "otto-btn otto-btn-sm";
        btn.textContent = makeAdmin ? "Promote" : "Demote";
        btn.addEventListener("click", () => setRole(u.email, makeAdmin));
        actionsGroup.appendChild(btn);
      }

      if (canManage && !hideProxies) {
        const proxyBtn = document.createElement("button");
        proxyBtn.type = "button";
        proxyBtn.className = "otto-btn otto-btn-sm";
        proxyBtn.textContent = "🤝 Proxies";
        proxyBtn.title = `Manage proxies for ${u.email}`;
        proxyBtn.addEventListener("click", () => openAdminUserProxies(u.email));
        actionsGroup.appendChild(proxyBtn);
      }

      if (canManage) {
        const prefBtn = document.createElement("button");
        prefBtn.type = "button";
        prefBtn.className = "otto-btn otto-btn-sm";
        prefBtn.textContent = "⚙️ Prefs";
        prefBtn.title = `Edit preferences for ${u.email}`;
        prefBtn.addEventListener("click", () => openUserPrefs(u));
        actionsGroup.appendChild(prefBtn);
      }

      if (isSuper && !u.is_super_admin) {
        const rmBtn = document.createElement("button");
        rmBtn.type = "button";
        rmBtn.className = "otto-btn otto-btn-sm otto-btn-danger";
        rmBtn.textContent = "Remove";
        rmBtn.addEventListener("click", () => deleteUser(u.email));
        actionsGroup.appendChild(rmBtn);
      }

      if (!actionsGroup.hasChildNodes()) {
        actionsGroup.textContent = "\u2014";
      }

      tbody.appendChild(tr);
    });
  }

  async function openDirectory() {
    show(DIRECTORY_ID);
    document.getElementById(`${DIRECTORY_ID}-title`).textContent = `\u{1F465} ${opts.appName} Directory`;
    document.getElementById(`${DIRECTORY_ID}-desc`).textContent =
      `Platform users registered in ${opts.appName}. Search existing players below or manage roles & preferences.`;

    const searchInput = document.getElementById(`${DIRECTORY_ID}-search`);
    if (searchInput) {
      searchInput.placeholder = opts.hideProxies
        ? "Search current users by name, email, or role..."
        : "Search current users by name, email, role, or proxy...";
    }

    const me = await ensureCurrentUserLoaded();
    const isSuper = Boolean(me && me.is_super_admin);
    const isGame = Boolean(me && (me.is_game_admin || me.is_admin));
    const canManage = isSuper || isGame;

    const addBox = document.getElementById(`${DIRECTORY_ID}-admin-add`);
    if (addBox) {
      addBox.classList.toggle("otto-hidden", !canManage);
    }

    const tbody = document.getElementById(`${DIRECTORY_ID}-tbody`);
    const colSpan = opts.hideProxies ? 4 : 5;
    try {
      const res = await O().api("/api/users");
      cachedUsers = Array.isArray(res) ? res : res.users || [];
    } catch (err) {
      tbody.innerHTML = `<tr><td colspan="${colSpan}" class="otto-center otto-error">${esc(err.message)}</td></tr>`;
      return;
    }

    updateRoleTabCounts();
    renderDirectoryRows();
    changed();
  }

  async function deleteUser(email) {
    if (!confirm(`Are you sure you want to permanently remove user ${email}?`)) return;
    try {
      await O().api(`/api/users/${encodeURIComponent(email)}`, { method: "DELETE" });
      await openDirectory();
      changed();
    } catch (err) {
      report(err, "Failed to remove user.");
    }
  }

  async function openAdminUserProxies(targetEmail) {
    if (!targetEmail) return;
    activeAdminProxyTarget = targetEmail;
    show(ADMIN_PROXIES_ID);
    document.getElementById(`${ADMIN_PROXIES_ID}-user`).textContent = targetEmail;
    const fb = document.getElementById(`${ADMIN_PROXIES_ID}-feedback`);
    if (fb) fb.textContent = "";
    populateDatalist(document.getElementById(`${ADMIN_PROXIES_ID}-datalist`), targetEmail);
    await refreshAdminProxiesModal();
  }

  async function refreshAdminProxiesModal() {
    const targetEmail = activeAdminProxyTarget;
    if (!targetEmail) return;
    const listEl = document.getElementById(`${ADMIN_PROXIES_ID}-list`);
    const proxyForWrap = document.getElementById(`${ADMIN_PROXIES_ID}-proxy-for-wrap`);
    const proxyForEl = document.getElementById(`${ADMIN_PROXIES_ID}-proxy-for`);
    if (!listEl) return;

    try {
      const data = await O().api(`/api/users/${encodeURIComponent(targetEmail)}/proxies`);
      const proxies = (data && data.proxies) || [];
      const proxyFor = (data && data.proxy_for) || [];

      listEl.replaceChildren();
      if (!proxies.length) {
        listEl.innerHTML = '<span class="otto-muted">No proxies configured for this user.</span>';
      } else {
        proxies.forEach((p) => {
          const row = document.createElement("div");
          row.className = "otto-proxy-row";
          const label = document.createElement("span");
          label.textContent = proxyLabel(p);
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = "otto-btn otto-btn-sm otto-btn-danger";
          btn.textContent = "Remove";
          btn.addEventListener("click", () => onAdminRemoveProxy(targetEmail, proxyEmail(p)));
          row.append(label, btn);
          listEl.appendChild(row);
        });
      }

      if (proxyForWrap && proxyForEl) {
        proxyForEl.replaceChildren();
        if (proxyFor.length > 0) {
          proxyForWrap.classList.remove("otto-hidden");
          proxyFor.forEach((p) => {
            const badge = document.createElement("span");
            badge.className = "otto-proxy-badge";
            badge.textContent = proxyLabel(p);
            proxyForEl.appendChild(badge);
          });
        } else {
          proxyForWrap.classList.add("otto-hidden");
        }
      }
    } catch (err) {
      listEl.innerHTML = `<span class="otto-error">${esc(err.message || "Failed to load proxies.")}</span>`;
    }
  }

  async function onAdminAddProxy(event) {
    event.preventDefault();
    const targetEmail = activeAdminProxyTarget;
    const input = document.getElementById(`${ADMIN_PROXIES_ID}-email`);
    const fb = document.getElementById(`${ADMIN_PROXIES_ID}-feedback`);
    const email = (input.value || "").trim().toLowerCase();
    if (!targetEmail || !email) return;
    if (fb) fb.textContent = "";
    try {
      await O().api(`/api/users/${encodeURIComponent(targetEmail)}/proxies`, {
        method: "POST",
        body: JSON.stringify({ email }),
      });
      input.value = "";
      await refreshAdminProxiesModal();
      const usersRes = await O().api("/api/users").catch(() => null);
      if (usersRes) {
        cachedUsers = Array.isArray(usersRes) ? usersRes : usersRes.users || [];
        renderDirectoryRows();
      }
      changed();
    } catch (err) {
      if (fb) {
        fb.className = "otto-feedback otto-feedback-err";
        fb.textContent = err.message || "Failed to add proxy.";
      } else {
        report(err, "Failed to add proxy.");
      }
    }
  }

  async function onAdminRemoveProxy(targetEmail, proxyEmailAddr) {
    const fb = document.getElementById(`${ADMIN_PROXIES_ID}-feedback`);
    if (fb) fb.textContent = "";
    try {
      await O().api(
        `/api/users/${encodeURIComponent(targetEmail)}/proxies/${encodeURIComponent(proxyEmailAddr)}`,
        { method: "DELETE" }
      );
      await refreshAdminProxiesModal();
      const usersRes = await O().api("/api/users").catch(() => null);
      if (usersRes) {
        cachedUsers = Array.isArray(usersRes) ? usersRes : usersRes.users || [];
        renderDirectoryRows();
      }
      changed();
    } catch (err) {
      if (fb) {
        fb.className = "otto-feedback otto-feedback-err";
        fb.textContent = err.message || "Failed to remove proxy.";
      } else {
        report(err, "Failed to remove proxy.");
      }
    }
  }

  function openUserPrefs(u) {
    show(PREFS_ID);
    document.getElementById(`${PREFS_ID}-user`).textContent = u.email;
    const textarea = document.getElementById(`${PREFS_ID}-json`);
    const fb = document.getElementById(`${PREFS_ID}-feedback`);
    if (fb) fb.textContent = "";
    if (textarea) {
      textarea.value = JSON.stringify(u.preferences || {}, null, 2);
    }
    const form = document.getElementById(`${PREFS_ID}-form`);
    form.onsubmit = async (e) => {
      e.preventDefault();
      try {
        const parsed = JSON.parse(textarea.value);
        await O().api(`/api/users/${encodeURIComponent(u.email)}/preferences`, {
          method: "PUT",
          body: JSON.stringify(parsed),
        });
        close(PREFS_ID);
        await openDirectory();
        changed();
      } catch (err) {
        if (fb) {
          fb.className = "otto-feedback otto-feedback-err";
          fb.textContent = err.message || "Invalid JSON or failed to save.";
        } else {
          report(err, "Failed to save preferences.");
        }
      }
    };
  }

  async function onDirectoryAddUser(event) {
    event.preventDefault();
    const emailInput = document.getElementById(`${DIRECTORY_ID}-new-email`);
    const nameInput = document.getElementById(`${DIRECTORY_ID}-new-name`);
    const fb = document.getElementById(`${DIRECTORY_ID}-add-feedback`);
    const email = emailInput.value.trim().toLowerCase();
    const name = nameInput.value.trim();
    if (!email) return;
    try {
      await O().api("/api/users", {
        method: "POST",
        body: JSON.stringify({ email, display_name: name || undefined }),
      });
      emailInput.value = "";
      nameInput.value = "";
      if (fb) {
        fb.textContent = `Added ${email}!`;
        fb.className = "otto-feedback otto-feedback-ok";
        setTimeout(() => { fb.textContent = ""; }, 3000);
      }
      await openDirectory();
      changed();
    } catch (err) {
      if (fb) {
        fb.textContent = err.message || "Failed to add player.";
        fb.className = "otto-feedback otto-feedback-err";
      } else {
        report(err, "Failed to add player.");
      }
    }
  }

  async function setRole(email, makeAdmin) {
    try {
      await O().api(`/api/users/${encodeURIComponent(email)}/role`, {
        method: "PUT",
        body: JSON.stringify({ role: makeAdmin ? "game_admin" : "player" }),
      });
      await openDirectory();
    } catch (err) {
      report(err, "Failed to update game admin status.");
    }
  }

  async function onSaveNickname(event) {
    event.preventDefault();
    const nickInput = document.getElementById(`${PROFILE_ID}-nickname`);
    const fb = document.getElementById(`${PROFILE_ID}-nick-feedback`);
    const rawNick = (nickInput.value || "").trim();
    if (!NICKNAME_RE.test(rawNick)) {
      if (fb) {
        fb.className = "otto-feedback otto-feedback-err";
        fb.textContent = "Nickname must be 1–59 letters or numbers (no spaces or symbols).";
      }
      return;
    }
    try {
      const updated = await O().api("/api/me/profile", {
        method: "PUT",
        body: JSON.stringify({ display_name: rawNick }),
      });
      const merged = Object.assign({}, (O().state && O().state.currentUser) || {}, updated || {
        nickname: rawNick,
        display_name: rawNick,
      });
      merged.display_name = merged.nickname || merged.display_name || rawNick;
      O().state = O().state || {};
      O().state.currentUser = merged;

      document.getElementById(`${PROFILE_ID}-name`).textContent = merged.display_name;
      document.getElementById(`${PROFILE_ID}-avatar`).textContent = O().getInitials(merged.display_name);
      if (typeof O().updateProfilePill === "function") {
        O().updateProfilePill(merged);
      }
      if (fb) {
        fb.className = "otto-feedback otto-feedback-ok";
        fb.textContent = "Nickname saved!";
        setTimeout(() => { if (fb) fb.textContent = ""; }, 3000);
      }
      if (typeof opts.onProfileUpdated === "function") {
        opts.onProfileUpdated(merged);
      }
      changed();
    } catch (err) {
      if (fb) {
        fb.className = "otto-feedback otto-feedback-err";
        fb.textContent = err.message || "Failed to update nickname.";
      } else {
        report(err, "Failed to update nickname.");
      }
    }
  }

  async function openProfile() {
    const hasSession = Boolean(
      (O().state && O().state.currentUser) ||
      (typeof O().getStoredAuthToken === "function" && O().getStoredAuthToken())
    );
    if (!hasSession) return;

    show(PROFILE_ID);
    const titleEl = document.getElementById(`${PROFILE_ID}-title`);
    if (titleEl) {
      titleEl.textContent = opts.hideProxies ? "\u{1F464} Player Profile" : "\u{1F464} Profile & Proxy Delegation";
    }

    let me;
    try {
      me = await O().api("/api/me");
    } catch (err) {
      close(PROFILE_ID);
      report(err, "Failed to load profile.");
      return;
    }
    O().state = O().state || {};
    O().state.currentUser = me;
    const name = me.nickname || me.display_name || me.email.split("@")[0];
    document.getElementById(`${PROFILE_ID}-name`).textContent = name;
    document.getElementById(`${PROFILE_ID}-email`).textContent = me.email;
    document.getElementById(`${PROFILE_ID}-avatar`).textContent = O().getInitials(name);
    document.getElementById(`${PROFILE_ID}-role`).textContent = roleLabel(me);

    const nickInput = document.getElementById(`${PROFILE_ID}-nickname`);
    const nickFb = document.getElementById(`${PROFILE_ID}-nick-feedback`);
    if (nickInput) {
      nickInput.value = me.nickname || (NICKNAME_RE.test(name) ? name : "");
    }
    if (nickFb) nickFb.textContent = "";

    const extraEl = document.getElementById(`${PROFILE_ID}-extra`);
    if (extraEl) {
      extraEl.replaceChildren();
      if (typeof opts.renderProfileExtra === "function") {
        opts.renderProfileExtra(extraEl, me);
        extraEl.classList.toggle("otto-hidden", !extraEl.hasChildNodes());
      } else {
        extraEl.classList.add("otto-hidden");
      }
    }

    const proxiesPanel = document.getElementById(`${PROFILE_ID}-proxies-panel`);
    const proxyForPanel = document.getElementById(`${PROFILE_ID}-proxy-for-panel`);
    const proxyForList = document.getElementById(`${PROFILE_ID}-proxy-for-list`);

    if (opts.hideProxies) {
      if (proxiesPanel) proxiesPanel.classList.add("otto-hidden");
      if (proxyForPanel) proxyForPanel.classList.add("otto-hidden");
      return;
    }

    if (proxiesPanel) proxiesPanel.classList.remove("otto-hidden");

    const proxyFor = me.proxy_for || [];
    if (proxyForPanel && proxyForList) {
      proxyForList.replaceChildren();
      if (proxyFor.length > 0) {
        proxyForPanel.classList.remove("otto-hidden");
        proxyFor.forEach((p) => {
          const badge = document.createElement("span");
          badge.className = "otto-proxy-badge";
          badge.textContent = proxyLabel(p);
          proxyForList.appendChild(badge);
        });
      } else {
        proxyForPanel.classList.add("otto-hidden");
      }
    }

    // Populate proxy autocomplete datalist with current directory users
    const datalist = document.getElementById(`${PROFILE_ID}-users-datalist`);
    if (datalist) {
      O().api("/api/users")
        .then((res) => {
          const usersList = Array.isArray(res) ? res : res.users || [];
          cachedUsers = usersList;
          populateDatalist(datalist, me.email);
        })
        .catch(() => {});
    }

    const list = document.getElementById(`${PROFILE_ID}-proxies`);
    list.replaceChildren();
    const proxies = me.proxies || [];
    if (!proxies.length) {
      list.innerHTML = '<span class="otto-muted">No proxies configured.</span>';
      return;
    }
    proxies.forEach((p) => {
      const row = document.createElement("div");
      row.className = "otto-proxy-row";
      const label = document.createElement("span");
      label.textContent = proxyLabel(p);
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "otto-btn otto-btn-sm otto-btn-danger";
      btn.textContent = "Remove";
      btn.addEventListener("click", () => removeProxy(proxyEmail(p)));
      row.append(label, btn);
      list.appendChild(row);
    });
  }

  async function onAddProxy(event) {
    event.preventDefault();
    const input = document.getElementById(`${PROFILE_ID}-proxy-email`);
    const email = input.value.trim().toLowerCase();
    if (!email) return;
    try {
      await O().api("/api/me/proxies", { method: "POST", body: JSON.stringify({ email }) });
      input.value = "";
      await openProfile();
      changed();
    } catch (err) {
      report(err, "Failed to add proxy.");
    }
  }

  async function removeProxy(email) {
    try {
      await O().api(`/api/me/proxies/${encodeURIComponent(email)}`, { method: "DELETE" });
      await openProfile();
      changed();
    } catch (err) {
      report(err, "Failed to remove proxy.");
    }
  }

  root.Ottomate.people = {
    init(options = {}) {
      Object.assign(opts, options);
    },
    openDirectory,
    openProfile,
    showDirectoryModal: openDirectory,
    showProfileModal: openProfile,
    openAdminUserProxies,
    close,
  };
})();
