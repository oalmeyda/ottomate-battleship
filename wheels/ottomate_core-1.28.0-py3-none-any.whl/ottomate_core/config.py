import os

from typing import Any

USERS_COLLECTION = "users"
SERVICES_COLLECTION = "services"
PENDING_ACTIONS_COLLECTION = "pending_actions"
DEFAULT_PROJECT = os.environ.get("GOOGLE_CLOUD_PROJECT", "ottomate-gaming-platform")

_service_name: str = ""
_default_database: str | None = None
_service_metadata: dict[str, Any] | None = None


def configure_service(
    service_name: str,
    default_database: str | None = None,
    metadata: Any | None = None,
    sync_to_db: bool = True,
    cron_handler: Any | None = None,
    cron_config: Any | None = None,
) -> None:
    """Registers this process's service identity once at startup (e.g. in `app/main.py`).

    - `service_name` is used as the default for `deps.is_admin()` / `deps.resolve_acting_target()`.
    - `default_database` is the Firestore database used by `db.database()` when neither an explicit
      name nor the `FIRESTORE_DATABASE` environment variable is supplied.
    - `metadata` describes this service's card for Ottomate Hub.
    - `sync_to_db` when True persists/updates this service's card in shared (default) Firestore.
    - `cron_handler` / `cron_config` optionally registers a centralized Cloud Scheduler / UI refresh job.
    """
    global _service_name, _default_database, _service_metadata
    _service_name = service_name
    _default_database = default_database

    if cron_handler is not None or cron_config is not None:
        from ottomate_core.cron import configure_cron

        configure_cron(handler=cron_handler, config=cron_config)

    if metadata is not None:
        if hasattr(metadata, "to_dict"):
            meta_dict = metadata.to_dict()
        elif hasattr(metadata, "model_dump"):
            meta_dict = metadata.model_dump(mode="python")
        elif isinstance(metadata, dict):
            meta_dict = dict(metadata)
        else:
            meta_dict = {}

        if "service_id" not in meta_dict or not meta_dict["service_id"]:
            meta_dict["service_id"] = service_name.replace("ottomate-", "")
        if "title" not in meta_dict or not meta_dict["title"]:
            meta_dict["title"] = service_name.replace("-", " ").title()

        _service_metadata = meta_dict

        if sync_to_db:
            try:
                from ottomate_core.db import sync_service_card_to_registry

                sync_service_card_to_registry(meta_dict)
            except Exception:
                pass
    else:
        _service_metadata = None


def get_service_name() -> str:
    """Returns the service name registered through `configure_service()` (empty if unset)."""
    return _service_name


def get_default_database() -> str | None:
    """Returns the default service database registered through `configure_service()`."""
    return _default_database


def get_service_metadata() -> dict[str, Any] | None:
    """Returns the service card metadata registered through `configure_service()`."""
    return _service_metadata
